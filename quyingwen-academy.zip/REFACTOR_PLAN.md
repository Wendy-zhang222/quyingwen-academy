# 趣英文学院重构计划

## 目标
将现有项目 `quyingwen-academy` 重构为更现代化的架构，对齐线上网站 `www.quyingwen.top` 的功能。

## 新架构
```
quyingwen-academy/
├── backend/
│   ├── src/
│   │   ├── config/           # 配置（Prisma、JWT、multer）
│   │   ├── routes/           # 模块化路由（auth, courses, units, games, homework, books, listening, reading, vocab, games）
│   │   ├── middleware/       # 中间件（auth, teacher, error-handler）
│   │   ├── utils/            # 工具函数
│   │   └── prisma/           # Prisma client
│   └── prisma/
│       └── schema.prisma     # 数据库模型定义
├── frontend/
│   ├── src/
│   │   ├── components/       # shadcn/ui 组件 + 自定义组件
│   │   ├── pages/
│   │   │   ├── student/      # 学生端页面
│   │   │   │   ├── HomePage.jsx
│   │   │   │   ├── ListeningPage.jsx
│   │   │   │   ├── ReadingPage.jsx
│   │   │   │   ├── VocabPage.jsx
│   │   │   │   ├── GameHallPage.jsx
│   │   │   │   ├── ProgressPage.jsx
│   │   │   │   └── HomeworkPage.jsx
│   │   │   └── teacher/      # 教师端页面
│   │   │       └── TeacherPage.jsx
│   │   ├── hooks/            # 自定义 hooks
│   │   ├── lib/              # 工具函数（api 封装）
│   │   └── data/             # 静态数据
│   └── components/ui/        # shadcn/ui 组件
```

## 数据库 Schema（Prisma）
- 用户表、班级表、学生表
- 练习表、题目表、选项表
- 提交记录表、答案表、成绩表
- 学习进度表、错题本表
- 听力材料表、阅读文章表、词汇表

## 实施阶段
1. 初始化 Prisma ORM（后端）
2. 初始化 shadcn/ui（前端）
3. 迁移后端到 Prisma + 路由模块化
4. 重构前端：基础布局 + shadcn 主题
5. 新增功能模块：听力中心、阅读中心、词库、游戏大厅
