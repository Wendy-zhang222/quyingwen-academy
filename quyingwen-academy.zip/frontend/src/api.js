const API = import.meta.env.VITE_API_URL || '/api'

function getToken() {
  return localStorage.getItem('token')
}

function headers() {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${getToken()}`
  }
}

export async function apiPost(path, body) {
  const res = await fetch(API + path, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify(body)
  })
  return res.json()
}

export async function apiGet(path) {
  const res = await fetch(API + path, { headers: headers() })
  return res.json()
}

export async function login(email, password) {
  const res = await fetch(`${API}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  })
  return res.json()
}

export async function register(email, password, name, role) {
  const res = await fetch(`${API}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, name, role })
  })
  return res.json()
}

export async function getCourses() {
  return apiGet('/courses')
}

export async function getCourseUnits(courseId) {
  return apiGet(`/courses/${courseId}/units`)
}

export async function getUnit(unitId) {
  return apiGet(`/units/${unitId}`)
}

export async function getUnitGames(unitId) {
  return apiGet(`/units/${unitId}/games`)
}

export async function submitGame(gameId, score, answers, timeSpent) {
  return apiPost(`/games/${gameId}/submit`, { score, answers, time_spent: timeSpent })
}

export async function getProgress() {
  return apiGet('/progress')
}

export async function getLeaderboard() {
  const res = await fetch(`${API}/leaderboard`, { headers: headers() })
  return res.json()
}

export async function getTeacherStats() {
  return apiGet('/teacher/stats')
}

export async function getTeacherStudents() {
  return apiGet('/teacher/students')
}

export async function getStudentProgress(studentId) {
  return apiGet(`/teacher/student/${studentId}/progress`)
}

export async function teacherUnlock(studentId, unitId) {
  return apiPost('/teacher/unlock', { studentId, unitId })
}

// ── Book APIs ───────────────────────────────────────────────
export async function getBooks(unitId) {
  const query = unitId ? `?unitId=${unitId}` : ''
  return apiGet(`/books${query}`)
}

export async function getBook(bookId) {
  return apiGet(`/books/${bookId}`)
}

export async function createBook(title, description, unitId) {
  return apiPost('/teacher/books', { title, description, unitId })
}

export async function uploadBookPages(bookId, files) {
  const form = new FormData()
  files.forEach(f => form.append('pages', f))
  const res = await fetch(`${API}/teacher/books/${bookId}/pages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${getToken()}` },
    body: form
  })
  return res.json()
}

export async function uploadBookAudio(bookId, file, pageNumber) {
  const form = new FormData()
  form.append('audio', file)
  form.append('pageNumber', pageNumber)
  const res = await fetch(`${API}/teacher/books/${bookId}/audio`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${getToken()}` },
    body: form
  })
  return res.json()
}

export async function deleteBook(bookId) {
  const res = await fetch(`${API}/teacher/books/${bookId}`, {
    method: 'DELETE',
    headers: headers()
  })
  return res.json()
}

// ── Class Management APIs ───────────────────────────────────
export async function createClass(name) {
  return apiPost('/teacher/classes', { name })
}

export async function getClasses() {
  return apiGet('/teacher/classes')
}

export async function getClassStudents(classId) {
  return apiGet(`/teacher/classes/${classId}/students`)
}

export async function joinClass(code) {
  return apiPost('/join-class', { code })
}

export async function getMyClass() {
  return apiGet('/my-class')
}

// ── Homework APIs ───────────────────────────────────────────
export async function getHomeworks() {
  return apiGet('/homeworks')
}

export async function getHomework(id) {
  return apiGet(`/homeworks/${id}`)
}

export async function submitHomework(id, answers) {
  return apiPost(`/homeworks/${id}/submit`, { answers })
}

export async function getHomeworkResult(id) {
  return apiGet(`/homeworks/${id}/result`)
}

export async function getTeacherHomeworks() {
  return apiGet('/teacher/homeworks')
}

export async function getTeacherHomework(id) {
  return apiGet(`/teacher/homeworks/${id}`)
}

export async function createHomework(title, description, unitId, dueDate) {
  return apiPost('/teacher/homeworks', { title, description, unitId, dueDate })
}

export async function addHomeworkQuestion(homeworkId, question) {
  return apiPost(`/teacher/homeworks/${homeworkId}/questions`, question)
}

export async function updateHomeworkStatus(id, status) {
  const res = await fetch(`${API}/teacher/homeworks/${id}/status`, {
    method: 'PATCH',
    headers: headers(),
    body: JSON.stringify({ status })
  })
  return res.json()
}

export async function deleteHomework(id) {
  const res = await fetch(`${API}/teacher/homeworks/${id}`, {
    method: 'DELETE',
    headers: headers()
  })
  return res.json()
}

// ── Error Book APIs ─────────────────────────────────────────
export async function getErrorBook() {
  return apiGet('/error-book')
}

export async function getErrorBookStats() {
  return apiGet('/error-book/stats')
}

export async function masterError(id) {
  return apiPost(`/error-book/${id}/master`, {})
}

// ── Badge / Achievement APIs ────────────────────────────────
export async function getBadges() {
  return apiGet('/badges')
}

export async function getAllBadges() {
  return apiGet('/badges/all')
}
