import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom'
import { Button } from './components/ui/button.jsx'
import HomePage from './pages/student/HomePage.jsx'
import MapPage from './pages/student/MapPage.jsx'
import ListeningPage from './pages/student/ListeningPage.jsx'
import ReadingPage from './pages/student/ReadingPage.jsx'
import VocabPage from './pages/student/VocabPage.jsx'
import GameHallPage from './pages/student/GameHallPage.jsx'
import ProgressPage from './pages/student/ProgressPage.jsx'
import HomeworkPage from './pages/student/HomeworkPage.jsx'
import HomeworkTake from './pages/student/HomeworkTake.jsx'
import ErrorBookPage from './pages/student/ErrorBookPage.jsx'
import TeacherPage from './pages/teacher/TeacherPage.jsx'
import AuthPage from './pages/AuthPage.jsx'
import UnitPage from './pages/student/UnitPage.jsx'

function App() {
  const [user, setUser] = useState(null)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      fetch('/api/me', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(data => {
          if (data.id) setUser(data)
          else localStorage.removeItem('token')
        })
        .catch(() => localStorage.removeItem('token'))
    }
  }, [])

  const logout = () => {
    localStorage.removeItem('token')
    setUser(null)
    window.location.href = '/'
  }

  const isTeacher = user?.role === 'teacher' || user?.role === 'admin'

  const navLinks = [
    { to: '/map', label: '🗺️ 课程地图' },
    { to: '/listening', label: '🎧 听力中心' },
    { to: '/reading', label: '📖 阅读中心' },
    { to: '/vocab', label: '📚 词库' },
    { to: '/games', label: '🎮 游戏' },
    { to: '/homeworks', label: '✏️ 作业' },
    { to: '/error-book', label: '📝 错题本' },
    { to: '/progress', label: '📊 我的进度' },
  ]

  if (isTeacher) navLinks.push({ to: '/teacher', label: '👑 教师后台' })

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-50">
        {/* Navbar */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2 text-xl font-bold text-slate-900">
              <span className="text-2xl">🚀</span>
              <span>趣英文学院</span>
            </Link>

            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden md:flex items-center gap-2">
                  {navLinks.slice(0, 5).map(link => (
                    <Link key={link.to} to={link.to} className="text-sm font-medium text-slate-600 hover:text-slate-900 px-2 py-1 rounded-lg hover:bg-slate-100 transition">
                      {link.label}
                    </Link>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg">{user.avatar || '🎓'}</span>
                  <span className="text-sm font-semibold text-slate-700 hidden sm:inline">{user.name}</span>
                  <Button variant="ghost" size="sm" onClick={logout} className="text-slate-500 hover:text-slate-900">
                    退出
                  </Button>
                </div>
                <button className="md:hidden p-2 rounded-lg hover:bg-slate-100" onClick={() => setMobileOpen(!mobileOpen)}>
                  ☰
                </button>
              </div>
            ) : (
              <Link to="/" className="text-sm font-semibold text-slate-900 hover:underline">
                登录 / 注册
              </Link>
            )}
          </div>

          {mobileOpen && user && (
            <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2">
              {navLinks.map(link => (
                <Link key={link.to} to={link.to} className="block text-sm text-slate-600 py-1" onClick={() => setMobileOpen(false)}>
                  {link.label}
                </Link>
              ))}
            </div>
          )}
        </nav>

        <main className="pt-16">
          <Routes>
            <Route path="/" element={user ? <HomePage user={user} /> : <AuthPage setUser={setUser} />} />
            <Route path="/map" element={user ? <MapPage user={user} /> : <Navigate to="/" />} />
            <Route path="/unit/:id" element={user ? <UnitPage user={user} /> : <Navigate to="/" />} />
            <Route path="/listening" element={user ? <ListeningPage /> : <Navigate to="/" />} />
            <Route path="/reading" element={user ? <ReadingPage /> : <Navigate to="/" />} />
            <Route path="/vocab" element={user ? <VocabPage /> : <Navigate to="/" />} />
            <Route path="/games" element={user ? <GameHallPage /> : <Navigate to="/" />} />
            <Route path="/progress" element={user ? <ProgressPage user={user} /> : <Navigate to="/" />} />
            <Route path="/homeworks" element={user ? <HomeworkPage user={user} /> : <Navigate to="/" />} />
            <Route path="/homework/:id" element={user ? <HomeworkTake user={user} /> : <Navigate to="/" />} />
            <Route path="/error-book" element={user ? <ErrorBookPage /> : <Navigate to="/" />} />
            <Route path="/teacher" element={isTeacher ? <TeacherPage /> : <Navigate to="/map" />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

export default App
