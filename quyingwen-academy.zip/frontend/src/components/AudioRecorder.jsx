import { useState, useRef, useEffect } from 'react'

/**
 * AudioRecorder - 浏览器录音组件
 * 使用 MediaRecorder API 录制音频，支持预览和上传
 */
export default function AudioRecorder({ onUpload, pageNumber, onCancel }) {
  const [recording, setRecording] = useState(false)
  const [audioBlob, setAudioBlob] = useState(null)
  const [audioURL, setAudioURL] = useState(null)
  const [timer, setTimer] = useState(0)
  const [playing, setPlaying] = useState(false)
  const mediaRef = useRef(null)
  const chunksRef = useRef([])
  const timerRef = useRef(null)
  const audioRef = useRef(null)
  const [error, setError] = useState('')

  const startRecording = async () => {
    setError('')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' })
      mediaRef.current = recorder
      chunksRef.current = []

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data)
      }

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
        setAudioBlob(blob)
        setAudioURL(URL.createObjectURL(blob))
        stream.getTracks().forEach(t => t.stop())
      }

      recorder.onerror = () => {
        setError('录音出错，请重试')
        stopTimer()
        setRecording(false)
      }

      recorder.start(100)
      setRecording(true)
      setTimer(0)
      timerRef.current = setInterval(() => setTimer(t => t + 1), 1000)
    } catch (err) {
      setError('无法访问麦克风，请检查权限设置')
      console.error('录音错误:', err)
    }
  }

  const stopRecording = () => {
    if (mediaRef.current && mediaRef.current.state !== 'inactive') {
      mediaRef.current.stop()
    }
    stopTimer()
    setRecording(false)
  }

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
  }

  const togglePreview = () => {
    if (!audioRef.current) return
    if (playing) {
      audioRef.current.pause()
      setPlaying(false)
    } else {
      audioRef.current.play().then(() => setPlaying(true)).catch(() => {})
    }
  }

  const handleUpload = () => {
    if (!audioBlob) return
    const file = new File([audioBlob], `recorded-${Date.now()}.webm`, { type: 'audio/webm' })
    onUpload(file, pageNumber)
  }

  const reset = () => {
    stopRecording()
    if (audioURL) URL.revokeObjectURL(audioURL)
    setAudioBlob(null)
    setAudioURL(null)
    setTimer(0)
    setPlaying(false)
    setError('')
  }

  useEffect(() => {
    return () => {
      stopTimer()
      if (audioURL) URL.revokeObjectURL(audioURL)
    }
  }, [])

  const fmtTime = (s) => {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`
  }

  return (
    <div className="bg-white rounded-xl p-4 border border-slate-200">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-bold text-sm text-slate-700">🎙️ 录音配音 · 第 {pageNumber} 页</h4>
        <button onClick={onCancel} className="text-xs text-slate-400 hover:text-slate-600">✕</button>
      </div>

      {error && (
        <div className="mb-3 p-2 bg-danger-light text-danger rounded-lg text-xs font-bold">{error}</div>
      )}

      {/* Timer Display */}
      <div className="text-center mb-4">
        <div className={`text-4xl font-black font-mono ${recording ? 'text-danger animate-pulse' : 'text-slate-700'}`}>
          {fmtTime(timer)}
        </div>
        <div className="text-xs text-slate-400 mt-1">
          {recording ? '🔴 正在录音...' : audioBlob ? '录音完成' : '准备录音'}
        </div>
      </div>

      {/* Recording Wave Animation */}
      {recording && (
        <div className="flex justify-center gap-1 mb-4 h-8 items-end">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="w-1.5 bg-danger rounded-full animate-pulse"
              style={{
                height: `${20 + Math.random() * 60}%`,
                animationDelay: `${i * 0.1}s`,
                animationDuration: '0.5s'
              }}
            />
          ))}
        </div>
      )}

      {/* Controls */}
      <div className="flex justify-center gap-3 mb-4">
        {!recording && !audioBlob && (
          <button
            onClick={startRecording}
            className="px-6 py-2.5 bg-danger text-white rounded-xl font-bold text-sm hover:bg-red-600 transition flex items-center gap-2"
          >
            <span className="w-3 h-3 rounded-full bg-white animate-pulse" />
            开始录音
          </button>
        )}

        {recording && (
          <button
            onClick={stopRecording}
            className="px-6 py-2.5 bg-slate-700 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition flex items-center gap-2"
          >
            ⏹ 停止录音
          </button>
        )}

        {audioBlob && (
          <>
            <button
              onClick={togglePreview}
              className="px-4 py-2.5 bg-primary text-white rounded-xl font-bold text-sm hover:bg-blue-600 transition flex items-center gap-1"
            >
              {playing ? '⏸ 暂停' : '▶ 试听'}
            </button>
            <button
              onClick={reset}
              className="px-4 py-2.5 bg-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-300 transition"
            >
              🔄 重录
            </button>
          </>
        )}
      </div>

      {/* Hidden Audio Element for Preview */}
      {audioURL && (
        <audio
          ref={audioRef}
          src={audioURL}
          onEnded={() => setPlaying(false)}
          className="hidden"
        />
      )}

      {/* Upload Button */}
      {audioBlob && (
        <button
          onClick={handleUpload}
          className="w-full py-3 bg-secondary text-white rounded-xl font-bold text-sm hover:bg-orange-600 transition"
        >
          📤 上传录音到第 {pageNumber} 页
        </button>
      )}

      <p className="text-[10px] text-slate-400 text-center mt-2">
        需要麦克风权限 · 录音格式：WebM Opus
      </p>
    </div>
  )
}
