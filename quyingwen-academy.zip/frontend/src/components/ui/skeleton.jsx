import * as React from "react";
import { cn } from "../../lib/utils.js";

const Skeleton = React.forwardRef(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("animate-pulse rounded-md bg-slate-200", className)}
    {...props}
  />
));
Skeleton.displayName = "Skeleton";

export { Skeleton };
