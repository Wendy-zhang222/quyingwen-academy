import { useState, useEffect } from 'react'

export default function LetterSpell({ data, onComplete }) {
  const [words] = useState(() => {
    const raw = data.words || []
    const hints = data.hints || []
    return raw.map((w, i) => ({
      word: w.toUpperCase(),
      hint: hints[i] ? hints[i].toUpperCase() : w.replace(/[AEIOU]/g, '_').toUpperCase()
    }))
  })
  const [current, setCurrent] = useState(0)
  const [input, setInput] = useState('')
  const [results, setResults] = useState([])
  const [showResult, setShowResult] = useState(false)
  const [startTime] = useState(Date.now())
  const [shake, setShake] = useState(false)

  const q = words[current]

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(text)
      utter.lang = 'en-US'
      utter.rate = 0.8
      speechSynthesis.speak(utter)
    }
  }

  const handleSubmit = () => {
    if (!input.trim()) return
    const correct = input.trim().toUpperCase() === q.word
    setResults(prev => [...prev, { word: q.word, correct, answer: input.trim().toUpperCase() }])
    setShowResult(true)

    if (!correct) {
      setShake(true)
      setTimeout(() => setShake(false), 500)
    }

    setTimeout(() => {
      if (current < words.length - 1) {
        setCurrent(c => c + 1)
        setInput('')
        setShowResult(false)
      } else {
        const correctCount = [...results, { correct }].filter(r => r.correct).length
        const score = Math.round((correctCount / words.length) * 100)
        const timeSpent = Math.round((Date.now() - startTime) / 1000)
        onComplete(score, [...results, { correct }], timeSpent)
      }
    }, 2000)
  }

  useEffect(() => {
    if (q) {
      setTimeout(() => speak(q.word), 300)
    }
  }, [current])

  if (!q) return null

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <div className="text-center mb-4">
        <div className="text-sm font-bold text-slate-400 mb-1">
          {current + 1} / {words.length}
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${((current + 1) / words.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="text-center mb-6">
        <button
          onClick={() => speak(q.word)}
          className="w-16 h-16 rounded-full bg-white text-primary shadow-lg flex items-center justify-center text-2xl mx-auto hover:scale-110 transition mb-3"
        >
          🔊
        </button>
        <p className="text-sm text-slate-500">听音后拼写单词</p>
      </div>

      <div className={`text-center mb-4 ${shake ? 'animate-shake' : ''}`}>
        <div className="text-2xl font-black text-slate-800 mb-4 tracking-widest">
          {q.hint.split('').map((ch, i) => (
            <span
              key={i}
              className={`inline-block mx-0.5 px-2 py-1 rounded-lg
                ${ch === '_' ? 'bg-primary-light text-primary border-b-4 border-primary' : 'bg-white text-slate-400'}
              `}
            >
              {ch === '_' ? '?' : ch}
            </span>
          ))}
        </div>

        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          placeholder="输入单词..."
          className="w-full max-w-xs mx-auto block px-4 py-3 text-center text-xl font-bold tracking-widest rounded-xl border-2 border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition uppercase"
          autoFocus
        />
      </div>

      <button
        onClick={handleSubmit}
        className="w-full py-3 bg-primary text-white rounded-xl font-bold hover:bg-blue-600 transition"
      >
        ✅ 提交
      </button>

      {showResult && (
        <div className={`mt-4 text-center font-bold text-lg animate-bounce-in
          ${results[results.length - 1]?.correct ? 'text-success' : 'text-danger'}
        `}>
          {results[results.length - 1]?.correct
            ? '✅ 拼写正确！'
            : `❌ 正确答案是 ${q.word}`
          }
        </div>
      )}
    </div>
  )
}
