import { useState } from 'react'

export default function TrueFalse({ data, onComplete }) {
  const questions = data.questions || []
  const [current, setCurrent] = useState(0)
  const [results, setResults] = useState([])
  const [showResult, setShowResult] = useState(false)
  const [startTime] = useState(Date.now())

  const q = questions[current]

  const handleAnswer = (answer) => {
    const correct = answer === q.a
    setResults(prev => [...prev, { correct, answer }])
    setShowResult(true)

    setTimeout(() => {
      if (current < questions.length - 1) {
        setCurrent(c => c + 1)
        setShowResult(false)
      } else {
        const correctCount = [...results, { correct }].filter(r => r.correct).length
        const score = Math.round((correctCount / questions.length) * 100)
        const timeSpent = Math.round((Date.now() - startTime) / 1000)
        onComplete(score, [...results, { correct }], timeSpent)
      }
    }, 1500)
  }

  if (!q) return null

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <div className="text-center mb-4">
        <div className="text-sm font-bold text-slate-400 mb-1">
          {current + 1} / {questions.length}
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${((current + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 mb-4 shadow-sm border border-slate-200">
        <p className="text-lg font-bold text-slate-800 text-center">{q.q}</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => handleAnswer(true)}
          disabled={showResult}
          className={`py-4 rounded-xl font-bold text-lg transition-all
            ${showResult
              ? q.a === true
                ? 'bg-success text-white border-2 border-success'
                : 'bg-slate-100 text-slate-400 border-2 border-slate-200'
              : 'bg-success-light text-success border-2 border-success hover:bg-success hover:text-white'
            }
          `}
        >
          ✅ 正确
        </button>
        <button
          onClick={() => handleAnswer(false)}
          disabled={showResult}
          className={`py-4 rounded-xl font-bold text-lg transition-all
            ${showResult
              ? q.a === false
                ? 'bg-success text-white border-2 border-success'
                : 'bg-slate-100 text-slate-400 border-2 border-slate-200'
              : 'bg-danger-light text-danger border-2 border-danger hover:bg-danger hover:text-white'
            }
          `}
        >
          ❌ 错误
        </button>
      </div>

      {showResult && (
        <div className={`mt-4 text-center font-bold text-lg animate-bounce-in
          ${results[results.length - 1]?.correct ? 'text-success' : 'text-danger'}
        `}>
          {results[results.length - 1]?.correct ? '✅ 正确！' : '❌ 答错了'}
        </div>
      )}
    </div>
  )
}
