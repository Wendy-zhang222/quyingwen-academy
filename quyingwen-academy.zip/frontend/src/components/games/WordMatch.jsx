import { useState, useEffect } from 'react'

export default function WordMatch({ data, onComplete }) {
  const [pairs] = useState(() => {
    const raw = data.pairs || data
    return raw.map((p, i) => ({
      id: i,
      left: Array.isArray(p) ? p[0] : p.word,
      right: Array.isArray(p) ? p[1] : p.meaning,
      matched: false
    }))
  })
  const [leftSelected, setLeftSelected] = useState(null)
  const [rightSelected, setRightSelected] = useState(null)
  const [matchedIds, setMatchedIds] = useState([])
  const [wrongPairs, setWrongPairs] = useState([])
  const [startTime] = useState(Date.now())

  const shuffledLeft = pairs.map((p, i) => ({ ...p, displayId: i })).sort(() => Math.random() - 0.5)
  const shuffledRight = pairs.map((p, i) => ({ ...p, displayId: i + 100 })).sort(() => Math.random() - 0.5)

  const handleLeft = (item) => {
    if (matchedIds.includes(item.id)) return
    setLeftSelected(item.id)
    setWrongPairs([])
  }

  const handleRight = (item) => {
    if (matchedIds.includes(item.id)) return
    setRightSelected(item.id)
    if (leftSelected !== null) {
      if (leftSelected === item.id) {
        // Correct!
        setMatchedIds(prev => [...prev, item.id])
        setLeftSelected(null)
        setRightSelected(null)
        setWrongPairs([])

        // Check complete
        if (matchedIds.length + 1 === pairs.length) {
          const timeSpent = Math.round((Date.now() - startTime) / 1000)
          onComplete(100, pairs.map(p => ({ id: p.id, correct: true })), timeSpent)
        }
      } else {
        // Wrong!
        setWrongPairs([leftSelected, item.id])
        setLeftSelected(null)
        setRightSelected(null)
      }
    }
  }

  const isWrong = (item) => wrongPairs.includes(item.id)

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <div className="text-center mb-4">
        <div className="text-sm font-bold text-slate-400">
          配对进度: {matchedIds.length} / {pairs.length}
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full mt-2">
          <div
            className="h-full bg-success rounded-full transition-all"
            style={{ width: `${(matchedIds.length / pairs.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <h4 className="text-sm font-bold text-slate-500 text-center mb-2">英文</h4>
          {shuffledLeft.map(item => (
            <button
              key={item.displayId}
              onClick={() => handleLeft(item)}
              disabled={matchedIds.includes(item.id)}
              className={`w-full p-3 rounded-xl font-bold text-sm transition-all
                ${matchedIds.includes(item.id)
                  ? 'bg-success/20 text-success border-2 border-success'
                  : leftSelected === item.id
                    ? 'bg-primary text-white border-2 border-primary shadow-lg'
                    : isWrong(item)
                      ? 'bg-danger/20 text-danger border-2 border-danger animate-shake'
                      : 'bg-white border-2 border-slate-200 hover:border-primary text-slate-700'
                }
              `}
            >
              {item.left} {matchedIds.includes(item.id) && '✓'}
            </button>
          ))}
        </div>
        <div className="space-y-2">
          <h4 className="text-sm font-bold text-slate-500 text-center mb-2">中文/含义</h4>
          {shuffledRight.map(item => (
            <button
              key={item.displayId}
              onClick={() => handleRight(item)}
              disabled={matchedIds.includes(item.id)}
              className={`w-full p-3 rounded-xl font-bold text-sm transition-all
                ${matchedIds.includes(item.id)
                  ? 'bg-success/20 text-success border-2 border-success'
                  : isWrong(item)
                    ? 'bg-danger/20 text-danger border-2 border-danger animate-shake'
                    : 'bg-white border-2 border-slate-200 hover:border-primary text-slate-700'
                }
              `}
            >
              {item.right} {matchedIds.includes(item.id) && '✓'}
            </button>
          ))}
        </div>
      </div>

      {matchedIds.length === pairs.length && (
        <div className="text-center mt-4 text-success font-bold text-lg animate-bounce-in">
          🎉 全部配对成功！
        </div>
      )}
    </div>
  )
}
