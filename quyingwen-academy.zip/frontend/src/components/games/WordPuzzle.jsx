import { useState, useEffect } from 'react'

export default function WordPuzzle({ data, onComplete }) {
  const [words] = useState(() => {
    const raw = data.words || []
    return raw.map(w => w.toUpperCase())
  })
  const [current, setCurrent] = useState(0)
  const [letters, setLetters] = useState([])
  const [placed, setPlaced] = useState([])
  const [results, setResults] = useState([])
  const [showResult, setShowResult] = useState(false)
  const [startTime] = useState(Date.now())

  const word = words[current]

  useEffect(() => {
    const shuffled = word.split('').sort(() => Math.random() - 0.5)
    setLetters(shuffled.map((l, i) => ({ id: i, letter: l, used: false })))
    setPlaced([])
    setShowResult(false)
  }, [current])

  const handleLetter = (idx) => {
    if (letters[idx].used) return
    const newLetters = [...letters]
    newLetters[idx].used = true
    setLetters(newLetters)
    setPlaced([...placed, { letter: letters[idx].letter, fromIdx: idx }])
  }

  const handleBack = () => {
    if (placed.length === 0) return
    const last = placed[placed.length - 1]
    const newLetters = [...letters]
    newLetters[last.fromIdx].used = false
    setLetters(newLetters)
    setPlaced(placed.slice(0, -1))
  }

  const handleSubmit = () => {
    const answer = placed.map(p => p.letter).join('')
    const correct = answer === word
    setResults(prev => [...prev, { correct, answer }])
    setShowResult(true)

    setTimeout(() => {
      if (current < words.length - 1) {
        setCurrent(c => c + 1)
      } else {
        const correctCount = [...results, { correct }].filter(r => r.correct).length
        const score = Math.round((correctCount / words.length) * 100)
        const timeSpent = Math.round((Date.now() - startTime) / 1000)
        onComplete(score, [...results, { correct }], timeSpent)
      }
    }, 1500)
  }

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(text)
      utter.lang = 'en-US'
      utter.rate = 0.8
      speechSynthesis.speak(utter)
    }
  }

  useEffect(() => {
    if (word) {
      setTimeout(() => speak(word), 300)
    }
  }, [current])

  if (!word) return null

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <div className="text-center mb-4">
        <div className="text-sm font-bold text-slate-400 mb-1">
          {current + 1} / {words.length}
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${((current + 1) / words.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="text-center mb-6">
        <button
          onClick={() => speak(word)}
          className="w-14 h-14 rounded-full bg-white text-primary shadow-lg flex items-center justify-center text-xl mx-auto hover:scale-110 transition mb-2"
        >
          🔊
        </button>
        <p className="text-sm text-slate-500">点击字母拼出听到的单词</p>
      </div>

      {/* Answer slots */}
      <div className="flex justify-center gap-2 mb-6">
        {word.split('').map((_, i) => (
          <div
            key={i}
            className={`w-12 h-14 rounded-xl flex items-center justify-center text-xl font-black border-2
              ${i < placed.length
                ? 'bg-primary text-white border-primary'
                : 'bg-white border-slate-200 text-slate-300'
              }
            `}
          >
            {i < placed.length ? placed[i].letter : '?'}
          </div>
        ))}
      </div>

      {/* Letter pool */}
      <div className="flex justify-center gap-2 flex-wrap mb-4">
        {letters.map((l, i) => (
          <button
            key={i}
            onClick={() => handleLetter(i)}
            disabled={l.used}
            className={`w-12 h-12 rounded-xl font-bold text-xl transition-all
              ${l.used
                ? 'bg-slate-200 text-slate-300 cursor-default'
                : 'bg-white border-2 border-slate-200 hover:border-primary hover:text-primary text-slate-800 shadow-sm'
              }
            `}
          >
            {l.letter}
          </button>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          onClick={handleBack}
          disabled={placed.length === 0}
          className="flex-1 py-3 bg-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-300 transition disabled:opacity-40"
        >
          ← 撤销
        </button>
        <button
          onClick={handleSubmit}
          disabled={placed.length !== word.length}
          className="flex-1 py-3 bg-primary text-white rounded-xl font-bold hover:bg-blue-600 transition disabled:opacity-40"
        >
          ✅ 确认
        </button>
      </div>

      {showResult && (
        <div className={`mt-4 text-center font-bold text-lg animate-bounce-in
          ${results[results.length - 1]?.correct ? 'text-success' : 'text-danger'}
        `}>
          {results[results.length - 1]?.correct
            ? '✅ 正确！'
            : `❌ 正确答案是 ${word}`
          }
        </div>
      )}
    </div>
  )
}
