import { useState, useEffect } from 'react'

export default function ListenChoose({ data, onComplete }) {
  const [current, setCurrent] = useState(0)
  const [selected, setSelected] = useState(null)
  const [results, setResults] = useState([])
  const [showResult, setShowResult] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [startTime] = useState(Date.now())

  const questions = Array.isArray(data) ? data : [data]
  const q = questions[current]

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      setSpeaking(true)
      const utter = new SpeechSynthesisUtterance(text)
      utter.lang = 'en-US'
      utter.rate = 0.8
      utter.onend = () => setSpeaking(false)
      speechSynthesis.speak(utter)
    }
  }

  const handleSelect = (option) => {
    if (showResult) return
    setSelected(option)
    setShowResult(true)

    const correct = option === q.correct
    setResults(prev => [...prev, { question: current, correct, selected: option }])

    setTimeout(() => {
      if (current < questions.length - 1) {
        setCurrent(c => c + 1)
        setSelected(null)
        setShowResult(false)
      } else {
        // All done
        const correctCount = [...results, { correct }].filter(r => r.correct).length
        const score = Math.round((correctCount / questions.length) * 100)
        const timeSpent = Math.round((Date.now() - startTime) / 1000)
        onComplete(score, [...results, { correct }], timeSpent)
      }
    }, 1500)
  }

  useEffect(() => {
    if (q?.correct) {
      setTimeout(() => speak(q.correct), 500)
    }
  }, [current])

  if (!q) return null

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <div className="text-center mb-6">
        <div className="text-sm font-bold text-slate-400 mb-2">
          {current + 1} / {questions.length}
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full mb-4">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${((current + 1) / questions.length) * 100}%` }}
          />
        </div>

        <button
          onClick={() => speak(q.correct)}
          className={`w-20 h-20 rounded-full flex items-center justify-center text-3xl mx-auto transition-all
            ${speaking ? 'bg-primary text-white animate-pulse' : 'bg-white text-primary shadow-lg hover:scale-110'}
          `}
        >
          🔊
        </button>
        <p className="text-xs text-slate-500 mt-2">点击听音，然后选择正确答案</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {q.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleSelect(opt)}
            disabled={showResult}
            className={`p-4 rounded-xl font-bold text-lg transition-all
              ${showResult
                ? opt === q.correct
                  ? 'bg-success text-white border-2 border-success'
                  : selected === opt
                    ? 'bg-danger text-white border-2 border-danger'
                    : 'bg-white border-2 border-slate-200 text-slate-400'
                : 'bg-white border-2 border-slate-200 hover:border-primary hover:text-primary text-slate-700'
              }
            `}
          >
            {opt}
          </button>
        ))}
      </div>

      {showResult && (
        <div className={`mt-4 text-center font-bold text-lg animate-bounce-in
          ${selected === q.correct ? 'text-success' : 'text-danger'}
        `}>
          {selected === q.correct ? '✅ 正确！' : `❌ 正确答案是 ${q.correct}`}
        </div>
      )}
    </div>
  )
}
