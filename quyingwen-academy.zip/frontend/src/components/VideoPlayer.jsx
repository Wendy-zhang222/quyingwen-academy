import { useState, useRef, useEffect } from 'react'

export default function VideoPlayer({ src, title }) {
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [speed, setSpeed] = useState(1)
  const videoRef = useRef(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const onTime = () => setProgress(video.currentTime)
    const onLoaded = () => setDuration(video.duration)
    const onEnded = () => setPlaying(false)

    video.addEventListener('timeupdate', onTime)
    video.addEventListener('loadedmetadata', onLoaded)
    video.addEventListener('ended', onEnded)
    return () => {
      video.removeEventListener('timeupdate', onTime)
      video.removeEventListener('loadedmetadata', onLoaded)
      video.removeEventListener('ended', onEnded)
    }
  }, [src])

  const toggle = () => {
    if (!videoRef.current) return
    if (playing) {
      videoRef.current.pause()
      setPlaying(false)
    } else {
      videoRef.current.play()
      setPlaying(true)
    }
  }

  const seek = (e) => {
    if (!videoRef.current) return
    const pct = e.target.value / 100
    videoRef.current.currentTime = pct * duration
    setProgress(videoRef.current.currentTime)
  }

  const fmt = (s) => {
    if (!s || isNaN(s)) return '00:00'
    const m = Math.floor(s / 60)
    const sec = Math.floor(s % 60)
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
      <div className="relative bg-black aspect-video">
        <video
          ref={videoRef}
          src={src}
          className="w-full h-full"
          preload="metadata"
          onClick={toggle}
        />
        {!playing && (
          <div className="absolute inset-0 flex items-center justify-center cursor-pointer" onClick={toggle}>
            <div className="w-20 h-20 rounded-full bg-white/90 flex items-center justify-center shadow-lg hover:scale-110 transition">
              <span className="text-3xl">▶️</span>
            </div>
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-3 text-slate-800">{title}</h3>
        <div className="flex items-center gap-3 mb-3">
          <span className="text-sm font-mono text-slate-500 w-12">{fmt(progress)}</span>
          <input
            type="range"
            min={0}
            max={100}
            value={duration ? (progress / duration) * 100 : 0}
            onChange={seek}
            className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
          />
          <span className="text-sm font-mono text-slate-500 w-12">{fmt(duration)}</span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={toggle}
              className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center hover:bg-blue-600 transition"
            >
              {playing ? '⏸' : '▶'}
            </button>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">倍速</span>
              <select
                value={speed}
                onChange={e => {
                  setSpeed(Number(e.target.value))
                  if (videoRef.current) videoRef.current.playbackRate = Number(e.target.value)
                }}
                className="text-sm border border-slate-200 rounded-lg px-2 py-1 outline-none"
              >
                <option value={0.5}>0.5x</option>
                <option value={0.75}>0.75x</option>
                <option value={1}>1.0x</option>
                <option value={1.25}>1.25x</option>
                <option value={1.5}>1.5x</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs">🔊</span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={volume}
                onChange={e => {
                  setVolume(Number(e.target.value))
                  if (videoRef.current) videoRef.current.volume = Number(e.target.value)
                }}
                className="w-20 h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
