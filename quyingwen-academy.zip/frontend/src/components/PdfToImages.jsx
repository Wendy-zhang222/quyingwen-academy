import { useState, useRef } from 'react'

/**
 * PdfToImages - PDF 自动拆页组件
 * 使用 pdf.js 在浏览器端将 PDF 转成图片，然后上传
 */
export default function PdfToImages({ onUpload, bookId, onCancel }) {
  const [processing, setProcessing] = useState(false)
  const [progress, setProgress] = useState({ current: 0, total: 0 })
  const [blobs, setBlobs] = useState([])
  const [error, setError] = useState('')
  const canvasRef = useRef(null)

  const handleFile = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.includes('pdf')) {
      setError('请选择 PDF 文件')
      return
    }

    setError('')
    setProcessing(true)
    setBlobs([])

    try {
      const arrayBuffer = await file.arrayBuffer()
      const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise
      const totalPages = pdf.numPages
      setProgress({ current: 0, total: totalPages })

      const imageBlobs = []
      const canvas = canvasRef.current
      const ctx = canvas.getContext('2d')

      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        const page = await pdf.getPage(pageNum)
        // 设置较高的缩放比例以获得清晰图片
        const scale = 2.0
        const viewport = page.getViewport({ scale })

        canvas.width = viewport.width
        canvas.height = viewport.height

        await page.render({ canvasContext: ctx, viewport }).promise

        // 导出为 PNG Blob
        const blob = await new Promise(resolve => {
          canvas.toBlob(resolve, 'image/png', 0.9)
        })

        if (blob) {
          imageBlobs.push({
            blob,
            name: `page-${pageNum.toString().padStart(3, '0')}.png`,
            pageNum
          })
        }

        setProgress({ current: pageNum, total: totalPages })
      }

      setBlobs(imageBlobs)
    } catch (err) {
      console.error('PDF 处理错误:', err)
      setError('PDF 处理失败：' + (err.message || '未知错误'))
    } finally {
      setProcessing(false)
    }
  }

  const handleUpload = () => {
    if (blobs.length === 0) return
    const files = blobs.map(b => new File([b.blob], b.name, { type: 'image/png' }))
    onUpload(files)
  }

  const reset = () => {
    setBlobs([])
    setProgress({ current: 0, total: 0 })
    setError('')
    setProcessing(false)
  }

  return (
    <div className="bg-white rounded-xl p-4 border border-slate-200">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-bold text-sm text-slate-700">📄 PDF 自动拆页</h4>
        <button onClick={onCancel} className="text-xs text-slate-400 hover:text-slate-600">✕</button>
      </div>

      {error && (
        <div className="mb-3 p-2 bg-danger-light text-danger rounded-lg text-xs font-bold">{error}</div>
      )}

      {/* Hidden canvas for rendering */}
      <canvas ref={canvasRef} className="hidden" />

      {!processing && blobs.length === 0 && (
        <div className="text-center">
          <input
            type="file"
            accept=".pdf"
            onChange={handleFile}
            className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:font-bold hover:file:bg-blue-600"
          />
          <p className="text-xs text-slate-400 mt-2">
            选择 PDF 文件，自动将每页转为图片
          </p>
        </div>
      )}

      {processing && (
        <div className="text-center py-4">
          <div className="text-3xl mb-2 animate-spin">📄</div>
          <div className="text-sm font-bold text-primary mb-2">
            正在处理第 {progress.current} / {progress.total} 页...
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all"
              style={{ width: `${progress.total ? (progress.current / progress.total) * 100 : 0}%` }}
            />
          </div>
        </div>
      )}

      {!processing && blobs.length > 0 && (
        <div>
          <div className="text-center mb-3">
            <div className="text-2xl mb-1">✅</div>
            <p className="text-sm font-bold text-slate-700">已拆分为 {blobs.length} 页</p>
          </div>

          {/* Preview thumbnails */}
          <div className="grid grid-cols-5 gap-2 mb-4 max-h-40 overflow-y-auto">
            {blobs.map((b, i) => (
              <div key={i} className="relative aspect-[3/4] rounded-lg overflow-hidden border border-slate-200">
                <img
                  src={URL.createObjectURL(b.blob)}
                  alt={`页 ${b.pageNum}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-center text-[10px] py-0.5">
                  P{b.pageNum}
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <button
              onClick={reset}
              className="flex-1 py-2 bg-slate-200 text-slate-700 rounded-lg font-bold text-sm hover:bg-slate-300 transition"
            >
              🔄 重新选择
            </button>
            <button
              onClick={handleUpload}
              className="flex-1 py-2 bg-primary text-white rounded-lg font-bold text-sm hover:bg-blue-600 transition"
            >
              📤 上传 {blobs.length} 页图片
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
