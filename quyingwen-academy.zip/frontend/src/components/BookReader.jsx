import { useState, useRef, useEffect, useCallback } from 'react'

/**
 * BookReader - 有声绘本同步阅读器
 * 支持图片翻页 + 音频同步播放
 * 每页可独立配置音频，播完自动翻页
 */
export default function BookReader({ book, onClose }) {
  const { title, pages = [], audios = [] } = book
  const [currentPage, setCurrentPage] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [playbackRate, setPlaybackRate] = useState(1)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [showControls, setShowControls] = useState(true)
  const [autoPlay, setAutoPlay] = useState(true)
  const audioRef = useRef(null)

  const totalPages = pages.length
  const currentPageData = pages[currentPage]
  const currentAudio = audios.find(a => a.page_number === currentPageData?.page_number)

  const goNext = useCallback(() => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(p => p + 1)
    }
  }, [currentPage, totalPages])

  const goPrev = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage(p => p - 1)
    }
  }, [currentPage])

  const goToPage = (idx) => {
    setCurrentPage(idx)
    setIsPlaying(false)
    setProgress(0)
  }

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const onTimeUpdate = () => setProgress(audio.currentTime)
    const onLoadedMeta = () => setDuration(audio.duration)
    const onEnded = () => {
      setIsPlaying(false)
      setProgress(0)
      if (autoPlay && currentPage < totalPages - 1) {
        // Auto advance to next page after a short delay
        setTimeout(() => goNext(), 500)
      }
    }
    const onError = () => {
      setIsPlaying(false)
      // If no audio, just show page
    }

    audio.addEventListener('timeupdate', onTimeUpdate)
    audio.addEventListener('loadedmetadata', onLoadedMeta)
    audio.addEventListener('ended', onEnded)
    audio.addEventListener('error', onError)

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate)
      audio.removeEventListener('loadedmetadata', onLoadedMeta)
      audio.removeEventListener('ended', onEnded)
      audio.removeEventListener('error', onError)
    }
  }, [currentPage, totalPages, autoPlay, goNext])

  // Reset audio when page changes
  useEffect(() => {
    setProgress(0)
    setDuration(0)
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
      audioRef.current.playbackRate = playbackRate
      if (autoPlay && currentAudio) {
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false))
      } else {
        setIsPlaying(false)
      }
    }
  }, [currentPage, currentAudio, autoPlay, playbackRate])

  const togglePlay = () => {
    if (!audioRef.current || !currentAudio) return
    if (isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {})
    }
  }

  const seek = (e) => {
    if (!audioRef.current || !duration) return
    const time = Number(e.target.value)
    audioRef.current.currentTime = time
    setProgress(time)
  }

  const fmt = (s) => {
    if (!s || isNaN(s)) return '00:00'
    const m = Math.floor(s / 60)
    const sec = Math.floor(s % 60)
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`
  }

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault()
        if (isPlaying) togglePlay()
        else goNext()
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault()
        goPrev()
      }
      if (e.key === 'p' || e.key === 'P') {
        togglePlay()
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [goNext, goPrev, isPlaying, togglePlay])

  if (!totalPages) {
    return (
      <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="text-5xl mb-4">📖</div>
          <p className="text-lg">本书暂无内容</p>
          <button onClick={onClose} className="mt-6 px-6 py-2 bg-white/20 rounded-xl text-white hover:bg-white/30 transition">关闭</button>
        </div>
      </div>
    )
  }

  const baseUrl = window.location.origin.replace(':5173', ':3001')
  const imageUrl = currentPageData ? `${baseUrl}${currentPageData.image_path}` : ''
  const audioUrl = currentAudio ? `${baseUrl}${currentAudio.audio_path}` : ''

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Hidden audio element */}
      {audioUrl && (
        <audio
          ref={audioRef}
          src={audioUrl}
          preload="auto"
        />
      )}

      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/80 text-white">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-lg transition">
            ✕
          </button>
          <div>
            <h2 className="font-bold text-sm">{title}</h2>
            <p className="text-xs text-white/60">第 {currentPage + 1} / {totalPages} 页</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoPlay(!autoPlay)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${autoPlay ? 'bg-primary text-white' : 'bg-white/10 text-white/60'}`}
          >
            {autoPlay ? '🔁 自动翻页' : '⏸ 手动翻页'}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {/* Left Page Button */}
        <button
          onClick={goPrev}
          disabled={currentPage === 0}
          className="absolute left-4 z-10 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-xl transition disabled:opacity-30 disabled:cursor-not-allowed"
        >
          ‹
        </button>

        {/* Image Display */}
        <div className="max-w-full max-h-full p-4 flex items-center justify-center">
          <img
            src={imageUrl}
            alt={`第 ${currentPage + 1} 页`}
            className="max-w-full max-h-[calc(100vh-180px)] object-contain rounded-xl shadow-2xl"
            onError={(e) => { e.target.style.display = 'none' }}
          />
        </div>

        {/* Right Page Button */}
        <button
          onClick={goNext}
          disabled={currentPage === totalPages - 1}
          className="absolute right-4 z-10 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-xl transition disabled:opacity-30 disabled:cursor-not-allowed"
        >
          ›
        </button>
      </div>

      {/* Page Thumbnails Strip */}
      <div className="bg-black/80 px-4 py-2 flex gap-2 overflow-x-auto">
        {pages.map((page, idx) => (
          <button
            key={page.id}
            onClick={() => goToPage(idx)}
            className={`flex-shrink-0 w-16 h-20 rounded-lg overflow-hidden border-2 transition relative
              ${idx === currentPage ? 'border-primary' : 'border-transparent hover:border-white/30'}
            `}
          >
            <img
              src={`${baseUrl}${page.image_path}`}
              alt={`页 ${idx + 1}`}
              className="w-full h-full object-cover"
            />
            {audios.find(a => a.page_number === page.page_number) && (
              <div className="absolute top-0.5 right-0.5 w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                <span className="text-[8px]">🔊</span>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Audio Controls Bar */}
      <div className="bg-black/90 px-4 py-3 border-t border-white/10">
        <div className="max-w-2xl mx-auto">
          {/* Progress Bar */}
          <div className="flex items-center gap-3 mb-2">
            <span className="text-xs font-mono text-white/60 w-10 text-right">{fmt(progress)}</span>
            <input
              type="range"
              min={0}
              max={duration || 0}
              step={0.1}
              value={progress}
              onChange={seek}
              className="flex-1 h-1.5 bg-white/20 rounded-full appearance-none cursor-pointer accent-primary"
              disabled={!currentAudio}
            />
            <span className="text-xs font-mono text-white/60 w-10">{fmt(duration)}</span>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={goPrev}
              disabled={currentPage === 0}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm transition disabled:opacity-30"
            >
              ⏮
            </button>

            <button
              onClick={togglePlay}
              disabled={!currentAudio}
              className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition
                ${currentAudio ? 'bg-primary hover:bg-blue-600 text-white' : 'bg-white/10 text-white/30 cursor-not-allowed'}
              `}
            >
              {isPlaying ? '⏸' : '▶'}
            </button>

            <button
              onClick={goNext}
              disabled={currentPage === totalPages - 1}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm transition disabled:opacity-30"
            >
              ⏭
            </button>

            <div className="w-px h-6 bg-white/20 mx-2" />

            {/* Playback Speed */}
            <select
              value={playbackRate}
              onChange={e => {
                const rate = Number(e.target.value)
                setPlaybackRate(rate)
                if (audioRef.current) audioRef.current.playbackRate = rate
              }}
              className="bg-white/10 text-white text-xs px-2 py-1.5 rounded-lg border border-white/20 outline-none"
            >
              <option value={0.5} className="text-black">0.5x</option>
              <option value={0.75} className="text-black">0.75x</option>
              <option value={1} className="text-black">1.0x</option>
              <option value={1.25} className="text-black">1.25x</option>
              <option value={1.5} className="text-black">1.5x</option>
            </select>

            {!currentAudio && (
              <span className="text-xs text-white/40">本页无音频</span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
