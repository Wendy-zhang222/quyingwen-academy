import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

export default function Navbar({ user, setUser }) {
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  const logout = () => {
    localStorage.removeItem('token')
    setUser(null)
    navigate('/')
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/map" className="flex items-center gap-2 text-xl font-bold text-primary">
          <span className="text-2xl">🚀</span>
          <span>趣英文学院</span>
        </Link>

        {user ? (
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 bg-primary-light px-3 py-1.5 rounded-full">
              <span className="text-primary font-bold">{user.avatar || '🎓'}</span>
              <span className="text-sm font-semibold text-slate-700">{user.name}</span>
            </div>
            <Link to="/homeworks" className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-primary transition">
              📚 作业
            </Link>
            <Link to="/error-book" className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-primary transition">
              📝 错题
            </Link>
            {(user.role === 'teacher' || user.role === 'admin') && (
              <Link to="/teacher" className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-primary transition">
                👑 后台
              </Link>
            )}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-slate-100"
            >
              ☰
            </button>
            <button
              onClick={logout}
              className="text-sm font-medium text-slate-500 hover:text-danger transition"
            >
              退出
            </button>
          </div>
        ) : (
          <Link to="/" className="text-sm font-semibold text-primary hover:underline">
            登录 / 注册
          </Link>
        )}
      </div>

      {menuOpen && user && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2">
          <Link to="/homeworks" className="block text-sm text-slate-600" onClick={() => setMenuOpen(false)}>📚 作业大厅</Link>
          <Link to="/error-book" className="block text-sm text-slate-600" onClick={() => setMenuOpen(false)}>📝 错题本</Link>
          <Link to="/progress" className="block text-sm text-slate-600" onClick={() => setMenuOpen(false)}>📊 学习进度</Link>
          {(user.role === 'teacher' || user.role === 'admin') && (
            <Link to="/teacher" className="block text-sm text-slate-600" onClick={() => setMenuOpen(false)}>👑 教师后台</Link>
          )}
        </div>
      )}
    </nav>
  )
}
