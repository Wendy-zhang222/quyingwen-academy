import React, { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getHomework, submitHomework, getHomeworkResult } from "../../api.js";

/*
  学生作业作答页面
  路由：/homework/:id

  支持的题型：
  - multiple_choice  — 单选
  - multiple_answer  — 多选
  - fill_blank       — 填空
  - true_false       — 判断
  - short_answer     — 简答（教师手动批改，允许留空）
*/

/* 徽章庆祝弹窗 */
function BadgeCelebration({ badges, onClose }) {
  if (!badges || badges.length === 0) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="relative mx-4 w-full max-w-md rounded-2xl bg-white p-8 text-center shadow-2xl animate-bounceIn">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-2xl text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="关闭"
        >
          ×
        </button>

        <div className="mb-4 text-6xl">🎉</div>
        <h2 className="mb-2 text-2xl font-bold text-gray-800">
          恭喜获得新徽章！
        </h2>
        <div className="mt-6 flex flex-wrap justify-center gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id || badge.name}
              className="flex flex-col items-center rounded-xl bg-gradient-to-br from-yellow-100 to-orange-100 px-5 py-4 shadow-md border border-yellow-300"
            >
              <span className="mb-1 text-4xl">{badge.icon || "🏅"}</span>
              <span className="text-sm font-semibold text-gray-700">
                {badge.name}
              </span>
            </div>
          ))}
        </div>
        <button
          onClick={onClose}
          className="mt-8 w-full rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 px-6 py-3 font-semibold text-white shadow-lg hover:from-blue-600 hover:to-indigo-700 transition-transform hover:scale-[1.02]"
        >
          继续查看结果
        </button>
      </div>
    </div>
  );
}

/* 单选 */
function SingleChoice({ question, answer, onChange }) {
  return (
    <div className="space-y-3">
      {question.data.options.map((opt) => {
        const isSelected = answer === opt.label;
        return (
          <button
            key={opt.label}
            onClick={() => onChange(opt.label)}
            className={`flex w-full items-center rounded-xl border-2 px-5 py-4 text-left transition-all hover:shadow-md ${
              isSelected
                ? "border-blue-500 bg-blue-50 text-blue-900 shadow-sm"
                : "border-gray-200 bg-white text-gray-700 hover:border-blue-300"
            }`}
          >
            <span
              className={`mr-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 text-sm font-bold ${
                isSelected
                  ? "border-blue-500 bg-blue-500 text-white"
                  : "border-gray-300 text-gray-400"
              }`}
            >
              {isSelected ? "✓" : ""}
            </span>
            <span className="font-medium">
              {opt.label}. {opt.text}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* 多选 */
function MultiChoice({ question, answer, onChange }) {
  const selected = answer ? answer.split(",") : [];

  const toggle = (label) => {
    const set = new Set(selected);
    if (set.has(label)) {
      set.delete(label);
    } else {
      set.add(label);
    }
    onChange(Array.from(set).sort().join(","));
  };

  return (
    <div className="space-y-3">
      {question.data.options.map((opt) => {
        const isSelected = selected.includes(opt.label);
        return (
          <button
            key={opt.label}
            onClick={() => toggle(opt.label)}
            className={`flex w-full items-center rounded-xl border-2 px-5 py-4 text-left transition-all hover:shadow-md ${
              isSelected
                ? "border-blue-500 bg-blue-50 text-blue-900 shadow-sm"
                : "border-gray-200 bg-white text-gray-700 hover:border-blue-300"
            }`}
          >
            <span
              className={`mr-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 text-sm font-bold ${
                isSelected
                  ? "border-blue-500 bg-blue-500 text-white"
                  : "border-gray-300 text-gray-400"
              }`}
            >
              {isSelected ? "✓" : ""}
            </span>
            <span className="font-medium">
              {opt.label}. {opt.text}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* 填空 */
function FillBlank({ question, answer, onChange }) {
  return (
    <div>
      <input
        type="text"
        value={answer || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={question.data.hint || "请输入答案"}
        className="w-full rounded-xl border-2 border-gray-200 bg-white px-5 py-4 text-gray-800 placeholder-gray-400 outline-none transition-colors focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
      />
    </div>
  );
}

/* 判断 */
function TrueFalse({ question, answer, onChange }) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <button
        onClick={() => onChange("true")}
        className={`rounded-xl border-2 px-6 py-5 text-lg font-bold transition-all hover:shadow-md ${
          answer === "true"
            ? "border-green-500 bg-green-50 text-green-700 shadow-sm"
            : "border-gray-200 bg-white text-gray-600 hover:border-green-300"
        }`}
      >
        ✅ 正确
      </button>
      <button
        onClick={() => onChange("false")}
        className={`rounded-xl border-2 px-6 py-5 text-lg font-bold transition-all hover:shadow-md ${
          answer === "false"
            ? "border-red-500 bg-red-50 text-red-700 shadow-sm"
            : "border-gray-200 bg-white text-gray-600 hover:border-red-300"
        }`}
      >
        ❌ 错误
      </button>
    </div>
  );
}

/* 简答 */
function ShortAnswer({ question, answer, onChange }) {
  return (
    <div>
      <textarea
        value={answer || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder="请输入你的答案…"
        rows={6}
        className="w-full resize-y rounded-xl border-2 border-gray-200 bg-white px-5 py-4 text-gray-800 placeholder-gray-400 outline-none transition-colors focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
      />
      <p className="mt-2 text-sm text-gray-500">
        简答题需要教师手动批改，可以留空。
      </p>
    </div>
  );
}

/* 题目渲染分发 */
function QuestionInput({ question, answer, onChange }) {
  switch (question.type) {
    case "multiple_choice":
      return <SingleChoice question={question} answer={answer} onChange={onChange} />;
    case "multiple_answer":
      return <MultiChoice question={question} answer={answer} onChange={onChange} />;
    case "fill_blank":
      return <FillBlank question={question} answer={answer} onChange={onChange} />;
    case "true_false":
      return <TrueFalse question={question} answer={answer} onChange={onChange} />;
    case "short_answer":
      return <ShortAnswer question={question} answer={answer} onChange={onChange} />;
    default:
      return (
        <p className="text-red-500">不支持的题型：{question.type}</p>
      );
  }
}

/* 结果页中的题目展示 */
function QuestionResult({ question, userAnswer, resultItem }) {
  const isCorrect = resultItem?.isCorrect;
  const correctAnswer = resultItem?.correctAnswer;
  const explanation = resultItem?.explanation;
  const isShortAnswer = question.type === "short_answer";

  const borderColor = isShortAnswer
    ? "border-gray-200"
    : isCorrect
    ? "border-green-400"
    : "border-red-400";

  const bgColor = isShortAnswer
    ? "bg-gray-50"
    : isCorrect
    ? "bg-green-50"
    : "bg-red-50";

  const statusIcon = isShortAnswer ? "📝" : isCorrect ? "✅" : "❌";
  const statusText = isShortAnswer
    ? "待批改"
    : isCorrect
    ? "回答正确"
    : "回答错误";

  return (
    <div
      className={`rounded-2xl border-2 ${borderColor} ${bgColor} p-6 shadow-sm transition-shadow hover:shadow-md`}
    >
      <div className="mb-4 flex items-center justify-between">
        <span className="rounded-full bg-white px-3 py-1 text-sm font-semibold text-gray-600 shadow-sm border border-gray-100">
          第 {question.question_order} 题
        </span>
        <span className="flex items-center gap-2 text-sm font-bold">
          <span className="text-lg">{statusIcon}</span>
          <span className={isCorrect ? "text-green-700" : isShortAnswer ? "text-gray-600" : "text-red-700"}>
            {statusText}
          </span>
        </span>
      </div>

      <div className="mb-5 text-lg font-semibold text-gray-800 leading-relaxed">
        {question.data.question}
      </div>

      {/* 用户作答 */}
      <div className="mb-3 rounded-lg bg-white/80 px-4 py-3">
        <span className="text-sm font-semibold text-gray-500">你的答案：</span>
        <span className="ml-2 font-medium text-gray-800">
          {userAnswer || "（未作答）"}
        </span>
      </div>

      {/* 正确答案（非简答） */}
      {!isShortAnswer && (
        <div className="mb-3 rounded-lg bg-white/80 px-4 py-3">
          <span className="text-sm font-semibold text-gray-500">正确答案：</span>
          <span className="ml-2 font-medium text-green-700">
            {correctAnswer || "—"}
          </span>
        </div>
      )}

      {/* 解析 */}
      {explanation && (
        <div className="mt-4 rounded-xl bg-gray-100 px-5 py-4 text-gray-700 leading-relaxed">
          <span className="mb-1 block text-sm font-semibold text-gray-500">
            解析
          </span>
          {explanation}
        </div>
      )}
    </div>
  );
}

/* 主页面 */
export default function HomeworkTake() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [homework, setHomework] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [showBadges, setShowBadges] = useState(false);

  /* 加载作业 */
  const loadHomework = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getHomework(id);
      setHomework(data);
      // 如果已有结果，直接展示
      if (data.hasResult) {
        const res = await getHomeworkResult(id);
        setResult(res);
      }
    } catch (err) {
      setError(err?.message || "加载作业失败，请稍后重试");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadHomework();
  }, [loadHomework]);

  /* 更新答案 */
  const handleAnswerChange = (questionId, value) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  /* 检查是否所有必填题都已作答 */
  const canSubmit = () => {
    if (!homework || !homework.questions) return false;
    return homework.questions.every((q) => {
      if (q.type === "short_answer") return true; // 简答可留空
      const ans = answers[q.id];
      return ans !== undefined && ans !== null && String(ans).trim() !== "";
    });
  };

  /* 提交 */
  const handleSubmit = async () => {
    if (!canSubmit()) return;
    try {
      setSubmitting(true);
      setError(null);
      const res = await submitHomework(id, answers);
      setResult(res);
      if (res.earnedBadges && res.earnedBadges.length > 0) {
        setShowBadges(true);
      }
    } catch (err) {
      setError(err?.message || "提交失败，请稍后重试");
    } finally {
      setSubmitting(false);
    }
  };

  /* 重新作答 */
  const handleRetry = () => {
    setAnswers({});
    setResult(null);
    setShowBadges(false);
  };

  /* 加载中 */
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-gray-200 border-t-blue-500"></div>
          <p className="text-gray-600">正在加载作业…</p>
        </div>
      </div>
    );
  }

  /* 错误 */
  if (error && !homework) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 text-center shadow-lg">
          <div className="mb-4 text-5xl">⚠️</div>
          <h2 className="mb-2 text-xl font-bold text-gray-800">出错了</h2>
          <p className="mb-6 text-gray-600">{error}</p>
          <button
            onClick={loadHomework}
            className="rounded-xl bg-blue-500 px-6 py-3 font-semibold text-white shadow hover:bg-blue-600 transition-colors"
          >
            重新加载
          </button>
        </div>
      </div>
    );
  }

  /* 结果页 */
  if (result) {
    const score = result.score ?? 0;
    const total = result.totalScore ?? homework.questions?.length ?? 0;
    const percentage = total > 0 ? Math.round((score / total) * 100) : 0;
    const earnedBadges = result.earnedBadges || [];

    // 为每题找到对应的结果
    const questionResultMap = {};
    (result.details || []).forEach((d) => {
      questionResultMap[d.questionId] = d;
    });

    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* 顶部得分栏 */}
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 py-12 text-center text-white shadow-lg">
          <h1 className="mb-2 text-3xl font-bold">{homework.title || "作业结果"}</h1>
          <div className="mt-6 inline-flex flex-col items-center rounded-2xl bg-white/20 px-8 py-5 backdrop-blur-sm">
            <span className="text-5xl font-extrabold">{score}</span>
            <span className="mt-1 text-lg opacity-90">/ {total} 分</span>
          </div>
          <div className="mt-4 text-lg opacity-90">
            正确率 {percentage}%
          </div>
          {earnedBadges.length > 0 && (
            <div className="mt-4 flex justify-center gap-2">
              {earnedBadges.map((b) => (
                <span
                  key={b.id || b.name}
                  className="rounded-full bg-yellow-300 px-3 py-1 text-sm font-bold text-yellow-900 shadow"
                >
                  {b.icon || "🏅"} {b.name}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="mx-auto mt-8 max-w-3xl px-4">
          {/* 操作按钮 */}
          <div className="mb-8 flex gap-4">
            <button
              onClick={handleRetry}
              className="rounded-xl bg-blue-500 px-6 py-3 font-semibold text-white shadow hover:bg-blue-600 transition-colors"
            >
              重新作答
            </button>
            <button
              onClick={() => navigate("/progress")}
              className="rounded-xl bg-gray-200 px-6 py-3 font-semibold text-gray-700 shadow hover:bg-gray-300 transition-colors"
            >
              返回进度
            </button>
          </div>

          {/* 每题结果 */}
          <div className="space-y-6">
            {(homework.questions || [])
              .sort((a, b) => a.question_order - b.question_order)
              .map((q) => (
                <QuestionResult
                  key={q.id}
                  question={q}
                  userAnswer={answers[q.id]}
                  resultItem={questionResultMap[q.id]}
                />
              ))}
          </div>
        </div>

        {/* 徽章弹窗 */}
        <BadgeCelebration
          badges={earnedBadges}
          onClose={() => setShowBadges(false)}
        />
      </div>
    );
  }

  /* 作答页 */
  const questions = (homework?.questions || []).sort(
    (a, b) => a.question_order - b.question_order
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* 头部 */}
      <div className="bg-white shadow-sm">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-5">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">
              {homework?.title || "作业作答"}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              共 {questions.length} 题 · 请认真作答
            </p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 transition-colors"
          >
            返回
          </button>
        </div>
      </div>

      {/* 题目列表 */}
      <div className="mx-auto mt-6 max-w-3xl px-4 space-y-6">
        {questions.map((q) => {
          const answered =
            q.type === "short_answer"
              ? true
              : answers[q.id] !== undefined &&
                answers[q.id] !== null &&
                String(answers[q.id]).trim() !== "";

          return (
            <div
              key={q.id}
              className="rounded-2xl bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
            >
              <div className="mb-4 flex items-center justify-between">
                <span className="rounded-full bg-gray-100 px-3 py-1 text-sm font-semibold text-gray-600">
                  第 {q.question_order} 题
                </span>
                <span className="text-xs font-medium text-gray-400">
                  {q.type === "multiple_choice" && "单选题"}
                  {q.type === "multiple_answer" && "多选题"}
                  {q.type === "fill_blank" && "填空题"}
                  {q.type === "true_false" && "判断题"}
                  {q.type === "short_answer" && "简答题"}
                </span>
              </div>

              <div className="mb-5 text-lg font-semibold text-gray-800 leading-relaxed">
                {q.data.question}
              </div>

              <QuestionInput
                question={q}
                answer={answers[q.id]}
                onChange={(val) => handleAnswerChange(q.id, val)}
              />

              {/* 作答状态指示 */}
              <div className="mt-4 flex items-center gap-2">
                <span
                  className={`h-2 w-2 rounded-full ${
                    answered ? "bg-green-500" : "bg-gray-300"
                  }`}
                />
                <span className="text-xs text-gray-500">
                  {answered ? "已作答" : "未作答"}
                  {q.type === "short_answer" && "（可留空）"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 底部提交栏 */}
      <div className="fixed bottom-0 left-0 right-0 border-t border-gray-200 bg-white/90 backdrop-blur-md px-4 py-4 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
        <div className="mx-auto flex max-w-3xl items-center justify-between">
          <div className="text-sm text-gray-600">
            已作答{" "}
            <span className="font-bold text-blue-600">
              {
                questions.filter((q) => {
                  if (q.type === "short_answer") return true;
                  const a = answers[q.id];
                  return a !== undefined && a !== null && String(a).trim() !== "";
                }).length
              }
            </span>{" "}
            / {questions.length} 题
          </div>
          <button
            onClick={handleSubmit}
            disabled={!canSubmit() || submitting}
            className={`rounded-xl px-8 py-3 font-bold text-white shadow-lg transition-all ${
              canSubmit() && !submitting
                ? "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 hover:scale-[1.02]"
                : "cursor-not-allowed bg-gray-300"
            }`}
          >
            {submitting ? (
              <span className="flex items-center gap-2">
                <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                提交中…
              </span>
            ) : (
              "提交作业"
            )}
          </button>
        </div>
      </div>

      {/* 错误提示 */}
      {error && (
        <div className="mx-auto mt-4 max-w-3xl px-4">
          <div className="rounded-xl bg-red-50 px-5 py-4 text-red-700 border border-red-200 shadow-sm">
            {error}
          </div>
        </div>
      )}
    </div>
  );
}
