import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card.jsx'
import { Badge } from '../../components/ui/badge.jsx'
import { Skeleton } from '../../components/ui/skeleton.jsx'
import { Button } from '../../components/ui/button.jsx'

export default function ListeningPage() {
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    fetch('/api/listening')
      .then(r => r.json())
      .then(data => { setMaterials(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const difficulties = {
    beginner: { label: '初级', variant: 'success' },
    intermediate: { label: '中级', variant: 'warning' },
    advanced: { label: '高级', variant: 'destructive' },
  }

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">🎧 听力中心</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32" />)}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">🎧 听力中心</h1>
      <p className="text-slate-500 mb-6">听音、点读、听写、测验真题 — 全面提升听力能力</p>

      {selected ? (
        <div className="space-y-4">
          <Button variant="outline" onClick={() => setSelected(null)}>← 返回列表</Button>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{selected.title}</h2>
              <div className="bg-slate-100 rounded-lg p-4 mb-4">
                <audio controls src={selected.audioUrl} className="w-full" />
              </div>
              {selected.transcript && (
                <div className="text-sm text-slate-600 whitespace-pre-wrap">{selected.transcript}</div>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {materials.map(m => (
            <Card key={m.id} className="cursor-pointer hover:shadow-lg transition" onClick={() => setSelected(m)}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold text-slate-900">{m.title}</h3>
                  <Badge variant={difficulties[m.difficulty]?.variant || 'default'}>
                    {difficulties[m.difficulty]?.label || m.difficulty}
                  </Badge>
                </div>
                <p className="text-sm text-slate-500">{m.description}</p>
              </CardContent>
            </Card>
          ))}
          {materials.length === 0 && (
            <div className="col-span-2 text-center py-12 text-slate-400">
              <div className="text-4xl mb-2">🎧</div>
              <p>暂无听力材料，请教师上传</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
