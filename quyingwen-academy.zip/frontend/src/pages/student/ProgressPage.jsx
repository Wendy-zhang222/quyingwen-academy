import { useState, useEffect } from 'react'
import { getProgress, getLeaderboard, getMyClass, joinClass, getBadges, getAllBadges } from '../../api.js'

export default function ProgressPage({ user }) {
  const [progress, setProgress] = useState([])
  const [totalXP, setTotalXP] = useState(0)
  const [level, setLevel] = useState(1)
  const [leaderboard, setLeaderboard] = useState([])
  const [loading, setLoading] = useState(true)
  const [myClass, setMyClass] = useState(null)
  const [badges, setBadges] = useState([])
  const [allBadges, setAllBadges] = useState([])
  const [classCode, setClassCode] = useState('')
  const [classMsg, setClassMsg] = useState('')
  const [showJoinClass, setShowJoinClass] = useState(false)

  useEffect(() => {
    async function load() {
      try {
        const [pData, lData, cData, bData, abData] = await Promise.all([
          getProgress(),
          getLeaderboard(),
          getMyClass(),
          getBadges(),
          getAllBadges()
        ])
        setProgress(pData.progress || [])
        setTotalXP(pData.totalXP || 0)
        setLevel(pData.level || 1)
        setLeaderboard(lData || [])
        setMyClass(cData)
        setBadges(bData || [])
        setAllBadges(abData || [])
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const handleJoinClass = async (e) => {
    e.preventDefault()
    if (!classCode.trim()) return
    setClassMsg('')
    const res = await joinClass(classCode.trim().toUpperCase())
    if (res.success) {
      setClassMsg('✅ 成功加入班级：' + res.className)
      setShowJoinClass(false)
      setClassCode('')
      const cData = await getMyClass()
      setMyClass(cData)
    } else {
      setClassMsg(res.error || '加入失败')
    }
    setTimeout(() => setClassMsg(''), 3000)
  }

  const completed = progress.filter(p => p.status === 'completed')
  const totalStars = completed.reduce((s, p) => s + (p.stars || 0), 0)
  const nextLevelXP = level * 500
  const xpPct = Math.min(100, Math.round((totalXP / nextLevelXP) * 100))

  const earnedCount = badges.length
  const totalBadgeCount = allBadges.length
  const badgePct = totalBadgeCount > 0 ? Math.round((earnedCount / totalBadgeCount) * 100) : 0

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">📊</div>
          <p className="text-slate-500 font-medium">正在加载学习数据...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black text-slate-800 mb-8">📊 我的学习档案</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-primary">{level}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">当前等级</div>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-secondary">{totalXP}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">总 XP</div>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-success">{completed.length}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">已完成单元</div>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-amber-500">{totalStars}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">获得星星</div>
        </div>
      </div>

      {/* Badges */}
      <div className="bg-white rounded-2xl p-5 shadow-md mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-lg text-slate-800">🏅 我的成就</h2>
          <div className="text-sm font-bold text-slate-500">
            {earnedCount} / {totalBadgeCount}
          </div>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full mb-4">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-yellow-500 rounded-full transition-all"
            style={{ width: `${badgePct}%` }}
          />
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-3">
          {allBadges.map(badge => {
            const earned = badge.earned
            return (
              <div
                key={badge.type}
                className={`flex flex-col items-center p-3 rounded-xl transition
                  ${earned
                    ? 'bg-amber-50 border-2 border-amber-300 shadow-sm'
                    : 'bg-slate-50 border-2 border-slate-200 opacity-50'
                  }
                `}
                title={`${badge.title}${earned ? ' ✅' : '（未获得）'}\n${badge.description}\n条件：${badge.condition}`}
              >
                <div className="text-3xl mb-1">{badge.icon}</div>
                <div className={`text-[10px] font-bold text-center leading-tight ${earned ? 'text-amber-700' : 'text-slate-400'}`}>
                  {badge.title}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Class Info Card */}
      <div className="bg-white rounded-2xl p-5 shadow-md mb-8">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-lg text-slate-800">🏫 我的班级</h2>
          {!myClass && (
            <button
              onClick={() => setShowJoinClass(!showJoinClass)}
              className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
            >
              {showJoinClass ? '取消' : '加入班级'}
            </button>
          )}
        </div>

        {classMsg && (
          <div className={`mb-3 p-2 rounded-lg text-xs font-bold ${classMsg.startsWith('✅') ? 'bg-success-light text-success' : 'bg-danger-light text-danger'}`}>
            {classMsg}
          </div>
        )}

        {myClass ? (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary-light flex items-center justify-center text-xl">
              🏫
            </div>
            <div>
              <div className="font-bold text-slate-800">{myClass.name}</div>
              <div className="text-xs text-slate-500">班级码：<span className="font-mono font-bold text-primary">{myClass.code}</span></div>
            </div>
          </div>
        ) : (
          <div>
            <p className="text-sm text-slate-500 mb-2">还没有加入任何班级</p>
            {showJoinClass && (
              <form onSubmit={handleJoinClass} className="flex gap-2">
                <input
                  type="text"
                  value={classCode}
                  onChange={e => setClassCode(e.target.value.toUpperCase())}
                  placeholder="输入6位班级码"
                  maxLength={6}
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-sm uppercase font-mono outline-none focus:border-primary"
                />
                <button
                  type="submit"
                  disabled={classCode.length !== 6}
                  className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-blue-600 transition disabled:opacity-40"
                >
                  确认加入
                </button>
              </form>
            )}
          </div>
        )}
      </div>

      {/* Level Progress */}
      <div className="bg-white rounded-2xl p-6 shadow-md mb-8">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-lg text-slate-800">升级进度</h2>
          <span className="text-sm font-bold text-primary">{totalXP} / {nextLevelXP} XP</span>
        </div>
        <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-blue-400 rounded-full transition-all"
            style={{ width: `${xpPct}%` }}
          />
        </div>
        <p className="text-sm text-slate-500 mt-2">
          还需 {nextLevelXP - totalXP} XP 升级到 Level {level + 1}
        </p>
      </div>

      {/* Progress List */}
      <div className="bg-white rounded-2xl p-6 shadow-md mb-8">
        <h2 className="font-bold text-lg text-slate-800 mb-4">📖 单元学习记录</h2>
        {progress.length === 0 ? (
          <p className="text-slate-500 text-center py-8">还没有学习记录，快去课程地图开始你的冒险吧！🚀</p>
        ) : (
          <div className="space-y-3">
            {progress.sort((a, b) => (b.completed_at || '').localeCompare(a.completed_at || '')).map(p => (
              <div key={p.id} className="flex items-center gap-4 p-3 bg-slate-50 rounded-xl">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm
                  ${p.status === 'completed' ? 'bg-success text-white' : p.status === 'in_progress' ? 'bg-primary text-white' : 'bg-slate-200 text-slate-500'}
                `}>
                  {p.status === 'completed' ? '✓' : p.status === 'in_progress' ? '⏳' : '🔒'}
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-800">{p.course_name} · {p.unit_name}</div>
                  <div className="text-xs text-slate-500">
                    {p.status === 'completed' ? '已完成' : p.status === 'in_progress' ? '进行中' : '已解锁'} · 得分 {p.score}%
                  </div>
                </div>
                <div className="flex gap-1">
                  {[1, 2, 3].map(i => (
                    <span key={i} className={`text-lg ${i <= p.stars ? 'text-amber-400' : 'text-slate-200'}`}>⭐</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Leaderboard */}
      <div className="bg-white rounded-2xl p-6 shadow-md">
        <h2 className="font-bold text-lg text-slate-800 mb-4">🏆 排行榜</h2>
        <div className="space-y-2">
          {leaderboard.map((entry, i) => (
            <div key={entry.id} className={`flex items-center gap-3 p-3 rounded-xl
              ${entry.name === user?.name ? 'bg-primary-light border border-primary' : 'bg-slate-50'}
            `}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm
                ${i === 0 ? 'bg-amber-100 text-amber-600' : i === 1 ? 'bg-slate-200 text-slate-600' : i === 2 ? 'bg-orange-100 text-orange-600' : 'bg-slate-100 text-slate-500'}
              `}>
                {i + 1}
              </div>
              <div className="text-xl">{entry.avatar || '🎓'}</div>
              <div className="flex-1 font-bold text-slate-800">{entry.name}</div>
              <div className="font-bold text-secondary">{entry.xp} XP</div>
            </div>
          ))}
          {leaderboard.length === 0 && (
            <p className="text-slate-500 text-center py-4">暂无排行榜数据</p>
          )}
        </div>
      </div>
    </div>
  )
}
