import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getUnit, getUnitGames, getBooks, submitGame } from '../../api.js'
import VideoPlayer from '../../components/VideoPlayer.jsx'
import BookReader from '../../components/BookReader.jsx'
import ListenChoose from '../../components/games/ListenChoose.jsx'
import WordMatch from '../../components/games/WordMatch.jsx'
import LetterSpell from '../../components/games/LetterSpell.jsx'
import TrueFalse from '../../components/games/TrueFalse.jsx'
import WordPuzzle from '../../components/games/WordPuzzle.jsx'

const GAME_COMPONENTS = {
  listen_choose: ListenChoose,
  word_match: WordMatch,
  letter_spell: LetterSpell,
  true_false: TrueFalse,
  word_puzzle: WordPuzzle
}

export default function UnitPage({ user }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [unit, setUnit] = useState(null)
  const [games, setGames] = useState([])
  const [books, setBooks] = useState([])
  const [tab, setTab] = useState('video') // video | explain | games | books
  const [activeGame, setActiveGame] = useState(null)
  const [gameResults, setGameResults] = useState({})
  const [loading, setLoading] = useState(true)
  const [showComplete, setShowComplete] = useState(false)
  const [readingBook, setReadingBook] = useState(null)

  useEffect(() => {
    async function load() {
      setLoading(true)
      const [uData, gData, bData] = await Promise.all([
        getUnit(id),
        getUnitGames(id),
        getBooks(id)
      ])
      setUnit(uData)
      setGames(gData)
      setBooks(bData)
      setLoading(false)
    }
    load()
  }, [id])

  const handleGameComplete = async (gameId, score, answers, timeSpent) => {
    setGameResults(prev => ({ ...prev, [gameId]: { score, completed: true } }))
    await submitGame(gameId, score, answers, timeSpent)

    // Check if all games completed
    const allCompleted = games.every(g => g.id === gameId || gameResults[g.id]?.completed)
    if (allCompleted) {
      setShowComplete(true)
    }
  }

  const completedCount = games.filter(g => gameResults[g.id]?.completed).length
  const totalGames = games.length
  const progressPct = totalGames ? Math.round((completedCount / totalGames) * 100) : 0

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">📖</div>
          <p className="text-slate-500 font-medium">正在加载单元内容...</p>
        </div>
      </div>
    )
  }

  if (!unit) return null

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate('/map')}
          className="text-sm font-bold text-slate-500 hover:text-primary transition"
        >
          ← 返回地图
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-black text-slate-800">{unit.name}</h1>
          <p className="text-sm text-slate-500">{unit.content}</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white rounded-xl p-4 shadow-md mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-bold text-slate-600">单元进度</span>
          <span className="text-sm font-bold text-primary">{progressPct}%</span>
        </div>
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-blue-400 rounded-full transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>
        <div className="flex gap-2 mt-3 flex-wrap">
          {games.map(g => (
            <div
              key={g.id}
              className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold transition
                ${gameResults[g.id]?.completed ? 'bg-success text-white' : 'bg-slate-100 text-slate-400'}
              `}
            >
              {gameResults[g.id]?.completed ? '✓' : g.game_order}
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {[
          { key: 'video', label: '📺 视频学习' },
          { key: 'explain', label: '🎙️ 老师讲解' },
          { key: 'games', label: '🎮 练习游戏' },
          { key: 'books', label: `📚 有声绘本${books.length > 0 ? ` (${books.length})` : ''}` }
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-5 py-3 rounded-xl font-bold text-sm whitespace-nowrap transition-all
              ${tab === t.key
                ? 'bg-primary text-white shadow-lg shadow-primary/25'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }
            `}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Video Tab */}
      {tab === 'video' && (
        <div className="animate-fade-in">
          {unit.intro_video ? (
            <VideoPlayer src={unit.intro_video} title={`📺 ${unit.name} - 视频学习`} />
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
              <div className="text-5xl mb-4">🎬</div>
              <p className="text-slate-500 font-medium">本单元视频内容正在制作中</p>
              <p className="text-sm text-slate-400 mt-2">先去看看讲解视频或练习游戏吧！</p>
            </div>
          )}
        </div>
      )}

      {/* Explain Tab */}
      {tab === 'explain' && (
        <div className="animate-fade-in">
          {unit.explain_video ? (
            <VideoPlayer src={unit.explain_video} title={`🎙️ ${unit.name} - 曲老师讲解`} />
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
              <div className="text-5xl mb-4">🎙️</div>
              <p className="text-slate-500 font-medium">讲解视频即将上线</p>
              <p className="text-sm text-slate-400 mt-2">曲老师正在录制精彩内容...</p>
            </div>
          )}
        </div>
      )}

      {/* Games Tab */}
      {tab === 'games' && (
        <div className="animate-fade-in space-y-4">
          {games.map((game, idx) => {
            const isCompleted = gameResults[game.id]?.completed
            const GameComp = GAME_COMPONENTS[game.type] || WordMatch

            return (
              <div
                key={game.id}
                className={`bg-white rounded-2xl p-6 shadow-md transition-all
                  ${isCompleted ? 'border-2 border-success' : 'border border-slate-200'}
                  ${activeGame === game.id ? 'ring-2 ring-primary' : ''}
                `}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold
                      ${isCompleted ? 'bg-success text-white' : 'bg-primary-light text-primary'}
                    `}>
                      {isCompleted ? '✓' : idx + 1}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">{game.title}</h3>
                      <p className="text-xs text-slate-500">
                        {game.points} 分 · {game.type === 'listen_choose' ? '听音选择' : game.type === 'word_match' ? '配对游戏' : game.type === 'letter_spell' ? '拼写挑战' : game.type === 'true_false' ? '判断对错' : '单词拼图'}
                      </p>
                    </div>
                  </div>
                  {isCompleted && (
                    <div className="text-success font-bold text-sm">✅ 已完成</div>
                  )}
                </div>

                {activeGame === game.id ? (
                  <div className="animate-fade-in">
                    <GameComp
                      data={game.data}
                      onComplete={(score, answers, timeSpent) => handleGameComplete(game.id, score, answers, timeSpent)}
                    />
                    <button
                      onClick={() => setActiveGame(null)}
                      className="mt-4 text-sm text-slate-500 hover:text-slate-700 font-medium"
                    >
                      ← 收起游戏
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setActiveGame(game.id)}
                    className={`w-full py-3 rounded-xl font-bold transition
                      ${isCompleted
                        ? 'bg-success-light text-success border border-success hover:bg-success hover:text-white'
                        : 'bg-primary text-white hover:bg-blue-600'
                      }
                    `}
                  >
                    {isCompleted ? '🔁 再玩一次' : '▶️ 开始游戏'}
                  </button>
                )}
              </div>
            )
          })}

          {games.length === 0 && (
            <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
              <div className="text-5xl mb-4">🎮</div>
              <p className="text-slate-500 font-medium">本单元练习游戏正在制作中</p>
            </div>
          )}
        </div>
      )}

      {/* Books Tab */}
      {tab === 'books' && (
        <div className="animate-fade-in">
          {books.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
              <div className="text-5xl mb-4">📚</div>
              <p className="text-slate-500 font-medium">本单元暂无有声绘本</p>
              <p className="text-sm text-slate-400 mt-2">曲老师正在准备精彩绘本...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {books.map(book => (
                <div
                  key={book.id}
                  onClick={() => setReadingBook(book)}
                  className="bg-white rounded-2xl p-5 shadow-md cursor-pointer hover:shadow-lg transition border-2 border-transparent hover:border-primary"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-20 bg-gradient-to-br from-primary to-blue-400 rounded-xl flex items-center justify-center text-3xl flex-shrink-0">
                      📖
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-slate-800 truncate">{book.title}</h3>
                      <p className="text-sm text-slate-500 mt-1 line-clamp-2">{book.description || '点击开始阅读'}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs px-2 py-0.5 bg-primary-light text-primary rounded-full font-bold">有声绘本</span>
                        <span className="text-xs text-slate-400">{new Date(book.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Book Reader Overlay */}
      {readingBook && (
        <BookReader
          book={readingBook}
          onClose={() => setReadingBook(null)}
        />
      )}

      {/* Complete Modal */}
      {showComplete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full text-center animate-bounce-in shadow-2xl">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-2xl font-black text-slate-800 mb-2">单元完成！</h2>
            <p className="text-slate-500 mb-6">太棒了！你完成了「{unit.name}」的所有练习！</p>
            <div className="flex justify-center gap-2 mb-6">
              {[1, 2, 3].map(i => (
                <span key={i} className="text-3xl animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}>⭐</span>
              ))}
            </div>
            <div className="bg-primary-light rounded-xl p-4 mb-6">
              <div className="text-sm text-slate-500">获得 XP</div>
              <div className="text-3xl font-black text-primary">+{games.reduce((s, g) => s + g.points, 0)}</div>
            </div>
            <button
              onClick={() => {
                setShowComplete(false)
                navigate('/map')
              }}
              className="w-full py-3 bg-primary text-white rounded-xl font-bold hover:bg-blue-600 transition"
            >
              🚀 继续下一关
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
