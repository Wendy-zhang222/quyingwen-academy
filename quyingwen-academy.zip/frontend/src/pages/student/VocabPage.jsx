import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card.jsx'
import { Button } from '../../components/ui/button.jsx'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../components/ui/tabs.jsx'
import { Skeleton } from '../../components/ui/skeleton.jsx'

export default function VocabPage() {
  const [books, setBooks] = useState([])
  const [entries, setEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('books')
  const [selectedBook, setSelectedBook] = useState(null)

  const token = localStorage.getItem('token')

  useEffect(() => {
    Promise.all([
      fetch('/api/vocab/books').then(r => r.json()),
      token ? fetch('/api/vocab/my-entries', { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()) : Promise.resolve([])
    ]).then(([b, e]) => {
      setBooks(b); setEntries(e); setLoading(false)
    }).catch(() => setLoading(false))
  }, [token])

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">📚 词库管理</h1>
        <Skeleton className="h-96" />
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">📚 词库管理</h1>
      <p className="text-slate-500 mb-6">掌握你的多层级词汇系统，艾宾浩斯智能排期</p>

      <Tabs>
        <TabsList className="mb-4">
          <TabsTrigger active={activeTab === 'books'} onClick={() => setActiveTab('books')}>词书</TabsTrigger>
          <TabsTrigger active={activeTab === 'review'} onClick={() => setActiveTab('review')}>智能背单词</TabsTrigger>
        </TabsList>

        <TabsContent hidden={activeTab !== 'books'}>
          {selectedBook ? (
            <div className="space-y-4">
              <Button variant="outline" onClick={() => setSelectedBook(null)}>← 返回词书列表</Button>
              <h2 className="text-xl font-bold">{selectedBook.title}</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {selectedBook.units?.map(u => (
                  <Card key={u.id} className="cursor-pointer hover:shadow-md transition">
                    <CardContent className="p-4">
                      <h3 className="font-bold">{u.name}</h3>
                      <p className="text-sm text-slate-500">{u.word_count || 0} 词</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {books.map(b => (
                <Card key={b.id} className="cursor-pointer hover:shadow-lg transition" onClick={() => setSelectedBook(b)}>
                  <CardContent className="p-5">
                    <h3 className="font-bold text-slate-900">{b.title}</h3>
                    <p className="text-sm text-slate-500 mt-1">{b.description}</p>
                    <p className="text-sm text-slate-400 mt-2">{b.unit_count || 0} 单元</p>
                  </CardContent>
                </Card>
              ))}
              {books.length === 0 && (
                <div className="col-span-3 text-center py-12 text-slate-400">
                  <div className="text-4xl mb-2">📚</div>
                  <p>暂无词书，请教师创建</p>
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent hidden={activeTab !== 'review'}>
          <div className="text-center py-8">
            <div className="text-4xl mb-4">🧠</div>
            <h3 className="text-lg font-bold text-slate-900">智能背单词</h3>
            <p className="text-slate-500 mt-2">根据艾宾浩斯遗忘曲线，在 12h, 24h, 3天, 7天, 14天 时刻安排复习</p>
            <div className="mt-6 grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-black text-primary">{entries.length}</div>
                  <div className="text-xs text-slate-400">学习总词汇</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-black text-amber-500">{entries.filter(e => e.status === 'mastered').length}</div>
                  <div className="text-xs text-slate-400">已掌握</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-black text-green-500">{entries.filter(e => e.status === 'new').length}</div>
                  <div className="text-xs text-slate-400">新词</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
