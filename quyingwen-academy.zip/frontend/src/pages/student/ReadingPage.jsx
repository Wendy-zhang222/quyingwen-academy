import { useState, useEffect } from 'react'
import { Card, CardContent } from '../../components/ui/card.jsx'
import { Button } from '../../components/ui/button.jsx'
import { Skeleton } from '../../components/ui/skeleton.jsx'

export default function ReadingPage() {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    fetch('/api/reading')
      .then(r => r.json())
      .then(data => { setArticles(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">📖 阅读中心</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32" />)}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">📖 阅读中心</h1>
      <p className="text-slate-500 mb-6">智能阅读器 & 个人图书馆 — 沉浸式阅读体验</p>

      {selected ? (
        <div className="space-y-4">
          <Button variant="outline" onClick={() => setSelected(null)}>← 返回列表</Button>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-2">{selected.title}</h2>
              {selected.author && <p className="text-sm text-slate-500 mb-4">作者: {selected.author}</p>}
              <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">{selected.content}</div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {articles.map(a => (
            <Card key={a.id} className="cursor-pointer hover:shadow-lg transition" onClick={() => setSelected(a)}>
              <CardContent className="p-5">
                <h3 className="font-bold text-slate-900 mb-1">{a.title}</h3>
                <div className="flex items-center gap-3 text-sm text-slate-400">
                  <span>{a.author || '未知作者'}</span>
                  <span>·</span>
                  <span>{a.wordCount} 词</span>
                  <span>·</span>
                  <span className="capitalize">{a.difficulty}</span>
                </div>
              </CardContent>
            </Card>
          ))}
          {articles.length === 0 && (
            <div className="col-span-2 text-center py-12 text-slate-400">
              <div className="text-4xl mb-2">📖</div>
              <p>暂无阅读文章，请教师上传</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
