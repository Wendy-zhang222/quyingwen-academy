import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card.jsx'
import { Button } from '../../components/ui/button.jsx'

export default function HomePage({ user }) {
  const [stats, setStats] = useState({ level: 1, xp: 0, completed: 0, badges: 0 })
  const navigate = useNavigate()

  useEffect(() => {
    fetch('/api/progress', { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
      .then(r => r.json())
      .then(data => {
        setStats({
          level: data.level || 1,
          xp: data.totalXP || 0,
          completed: (data.progress || []).filter(p => p.status === 'completed').length,
          badges: 0
        })
      })
  }, [])

  const features = [
    { icon: '🎧', title: '听力中心', desc: '智能音频播放器 + 精听训练', color: '#3B82F6', path: '/listening' },
    { icon: '📖', title: '阅读中心', desc: '智能阅读器 & 个人图书馆', color: '#10B981', path: '/reading' },
    { icon: '📚', title: '词库管理', desc: '艾宾浩斯智能背单词', color: '#F59E0B', path: '/vocab' },
    { icon: '🎮', title: '单词游戏', desc: '16款趣味闯关游戏', color: '#8B5CF6', path: '/games' },
    { icon: '🗺️', title: '课程地图', desc: '6大阶段成长之路', color: '#EF4444', path: '/map' },
    { icon: '✏️', title: '作业大厅', desc: '完成老师布置的作业', color: '#EC4899', path: '/homeworks' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Hero */}
      <div className="text-center mb-10">
        <h1 className="text-3xl font-black text-slate-900 mb-2">
          👋 你好，{user?.name}！
        </h1>
        <p className="text-slate-500">准备好开始今天的英语学习了吗？</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {[
          { label: '等级', value: stats.level, icon: '⭐' },
          { label: 'XP', value: stats.xp, icon: '💎' },
          { label: '已完成单元', value: stats.completed, icon: '✅' },
          { label: '徽章', value: stats.badges, icon: '🏅' },
        ].map(s => (
          <Card key={s.label} className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl mb-1">{s.icon}</div>
              <div className="text-2xl font-black text-slate-900">{s.value}</div>
              <div className="text-xs font-medium text-slate-400">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Feature Grid */}
      <h2 className="text-xl font-bold text-slate-900 mb-4">Choose Your Journey</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map(f => (
          <Card
            key={f.title}
            className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            onClick={() => navigate(f.path)}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ backgroundColor: f.color + '20' }}>
                  {f.icon}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">{f.title}</h3>
                  <p className="text-sm text-slate-500 mt-1">{f.desc}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
