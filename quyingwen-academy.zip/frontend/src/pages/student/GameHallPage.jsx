import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card, CardContent } from '../../components/ui/card.jsx'
import { Button } from '../../components/ui/button.jsx'

export default function GameHallPage() {
  const navigate = useNavigate()
  const [gameSource, setGameSource] = useState('wordbank')
  const [selectedGame, setSelectedGame] = useState(null)

  const battleGames = [
    { id: 'race', icon: '🐎', title: '赛马冲刺', desc: '红蓝轮流答，限时比分' },
    { id: 'tug', icon: '⚔️', title: '单词拔河', desc: '双人抢答，拉拽绳子' },
    { id: 'territory', icon: '🗺️', title: '阵地抢夺', desc: '答对占地，三连获胜' },
    { id: 'bomb', icon: '💣', title: '炸弹传花', desc: '答对传炸弹，超时淘汰' },
  ]

  const soloGames = [
    { id: 'match', icon: '🧩', title: '连连看', desc: '消除相同卡片' },
    { id: 'memory', icon: '🎴', title: '翻牌记忆', desc: '翻牌匹配中英' },
    { id: 'flashcard', icon: '🃏', title: '闪卡', desc: '基础单词记忆' },
    { id: 'speedread', icon: '⚡', title: '极速闪读', desc: '快速四选一' },
    { id: 'scramble', icon: '🔀', title: '字母重排', desc: '打乱重新拼写' },
    { id: 'hangman', icon: '🔤', title: '经典猜词', desc: '根据字母猜词' },
    { id: 'chain', icon: '🔗', title: '单词接龙', desc: '首尾字母接力' },
    { id: 'typing', icon: '⌨️', title: '打字防守', desc: '打字消灭单词' },
    { id: 'whack', icon: '🔨', title: '打地鼠', desc: '听音寻找地鼠' },
    { id: 'balloon', icon: '🎈', title: '气球爆破', desc: '点破正确气球' },
    { id: 'wheel', icon: '🎡', title: '幸运转盘', desc: '随机抽取单词' },
    { id: 'blindbox', icon: '🎁', title: '盲盒', desc: '打开盲盒复习' },
    { id: 'quiz', icon: '🎯', title: '测验', desc: '经典单项选择' },
    { id: 'judge', icon: '⚖️', title: '判断对错', desc: '判断释义真伪' },
    { id: 'fill', icon: '📝', title: '填空', desc: '根据英文选词' },
    { id: 'blindlisten', icon: '🎧', title: '盲听', desc: '纯听音辨意' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">🎮 游戏大厅</h1>
      <p className="text-slate-500 mb-6">16款 Wordwall 风格游戏 — 寓教于乐</p>

      {/* Battle Games */}
      <h2 className="text-lg font-bold text-slate-800 mb-4">⚔️ 课堂对战游戏 (双人/团队 PK)</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {battleGames.map(g => (
          <Card key={g.id} className="cursor-pointer hover:shadow-lg transition hover:-translate-y-1">
            <CardContent className="p-4">
              <div className="text-3xl mb-2">{g.icon}</div>
              <h3 className="font-bold text-slate-900">{g.title}</h3>
              <p className="text-sm text-slate-500">{g.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Solo Games */}
      <h2 className="text-lg font-bold text-slate-800 mb-4">🎮 经典单机练习 (个人闯关)</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {soloGames.map(g => (
          <Card key={g.id} className="cursor-pointer hover:shadow-lg transition hover:-translate-y-1">
            <CardContent className="p-4">
              <div className="text-3xl mb-2">{g.icon}</div>
              <h3 className="font-bold text-slate-900">{g.title}</h3>
              <p className="text-sm text-slate-500">{g.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
