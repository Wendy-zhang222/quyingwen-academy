import { useState, useEffect } from 'react'
import { getErrorBook, getErrorBookStats, masterError } from '../../api.js'

export default function ErrorBookPage({ user }) {
  const [errors, setErrors] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('pending')
  const [masteringId, setMasteringId] = useState(null)

  useEffect(() => {
    async function load() {
      try {
        const [eData, sData] = await Promise.all([
          getErrorBook(),
          getErrorBookStats()
        ])
        setErrors(eData || [])
        setStats(sData || {})
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const handleMaster = async (id) => {
    setMasteringId(id)
    try {
      const res = await masterError(id)
      if (res.success) {
        setErrors(prev => prev.map(err =>
          err.id === id ? { ...err, is_mastered: true } : err
        ))
        setStats(prev => prev ? {
          ...prev,
          mastered: (prev.mastered || 0) + 1,
          pending: Math.max(0, (prev.pending || 0) - 1)
        } : null)
      }
    } catch (e) {
      console.error(e)
    } finally {
      setMasteringId(null)
    }
  }

  const pendingErrors = errors.filter(e => !e.is_mastered)
  const masteredErrors = errors.filter(e => e.is_mastered)

  const totalErrors = errors.length
  const masteredCount = masteredErrors.length
  const pendingCount = pendingErrors.length

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">📝</div>
          <p className="text-slate-500 font-medium">正在加载错题本...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in">
      <h1 className="text-3xl font-black text-slate-800 mb-8">📝 我的错题本</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-slate-700">{totalErrors}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">总错题数</div>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-green-500">{masteredCount}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">已掌握</div>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-md text-center">
          <div className="text-3xl font-black text-red-500">{pendingCount}</div>
          <div className="text-xs font-bold text-slate-400 mt-1">待攻克</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
            activeTab === 'pending'
              ? 'bg-red-500 text-white shadow-md'
              : 'bg-white text-slate-500 hover:bg-slate-50 shadow-sm'
          }`}
        >
          ⚔️ 待攻克 ({pendingCount})
        </button>
        <button
          onClick={() => setActiveTab('mastered')}
          className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
            activeTab === 'mastered'
              ? 'bg-green-500 text-white shadow-md'
              : 'bg-white text-slate-500 hover:bg-slate-50 shadow-sm'
          }`}
        >
          ✅ 已掌握 ({masteredCount})
        </button>
      </div>

      {/* Error List */}
      {activeTab === 'pending' && (
        <div className="space-y-4">
          {pendingErrors.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 shadow-md text-center">
              <div className="text-4xl mb-3">🎉</div>
              <p className="text-slate-600 font-bold text-lg">暂无错题，太棒了！</p>
              <p className="text-slate-400 text-sm mt-1">继续保持，你已经很棒了！</p>
            </div>
          ) : (
            pendingErrors.map(err => (
              <ErrorCard
                key={err.id}
                err={err}
                onMaster={() => handleMaster(err.id)}
                mastering={masteringId === err.id}
              />
            ))
          )}
        </div>
      )}

      {activeTab === 'mastered' && (
        <div className="space-y-4">
          {masteredErrors.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 shadow-md text-center">
              <div className="text-4xl mb-3">📭</div>
              <p className="text-slate-500 font-medium">还没有已掌握的错题</p>
              <p className="text-slate-400 text-sm mt-1">快去攻克错题，标记为已掌握吧！</p>
            </div>
          ) : (
            masteredErrors.map(err => (
              <ErrorCard
                key={err.id}
                err={err}
                onMaster={() => handleMaster(err.id)}
                mastering={masteringId === err.id}
                mastered
              />
            ))
          )}
        </div>
      )}
    </div>
  )
}

function ErrorCard({ err, onMaster, mastering, mastered }) {
  let questionText = ''
  try {
    const qData = typeof err.question_data === 'string'
      ? JSON.parse(err.question_data)
      : err.question_data
    questionText = qData?.question || qData?.text || '（题目内容）'
  } catch {
    questionText = err.question_data || '（题目内容）'
  }

  const formatDate = (str) => {
    if (!str) return '—'
    const d = new Date(str)
    if (isNaN(d)) return str
    return d.toLocaleString('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className={`rounded-2xl p-6 shadow-md transition ${
      mastered ? 'bg-slate-50 opacity-80' : 'bg-white'
    }`}>
      {/* Question */}
      <div className="mb-4">
        <div className="text-xs font-bold text-slate-400 mb-1.5">题目</div>
        <div className="text-slate-800 font-medium leading-relaxed">{questionText}</div>
      </div>

      {/* Answers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <div className="bg-red-50 rounded-xl p-3">
          <div className="text-xs font-bold text-red-400 mb-1">❌ 你的答案</div>
          <div className="text-red-500 font-bold">{err.student_answer || err.wrong_answer || '—'}</div>
        </div>
        <div className="bg-green-50 rounded-xl p-3">
          <div className="text-xs font-bold text-green-400 mb-1">✅ 正确答案</div>
          <div className="text-green-600 font-bold">{err.correct_answer || '—'}</div>
        </div>
      </div>

      {/* Explanation */}
      {err.explanation && (
        <div className="bg-blue-50 rounded-xl p-3 mb-4">
          <div className="text-xs font-bold text-blue-400 mb-1">💡 解析</div>
          <div className="text-blue-700 text-sm leading-relaxed">{err.explanation}</div>
        </div>
      )}

      {/* Meta */}
      <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-slate-500">
        <div className="flex items-center gap-1">
          <span className="font-bold">{err.times_wrong || 1}</span>
          <span>次错误</span>
        </div>
        <div className="flex items-center gap-1">
          <span>上次错误：</span>
          <span className="font-mono font-medium">{formatDate(err.last_wrong_at || err.created_at)}</span>
        </div>
      </div>

      {/* Actions */}
      {!mastered && (
        <button
          onClick={onMaster}
          disabled={mastering}
          className="w-full md:w-auto px-5 py-2.5 bg-green-500 text-white rounded-xl text-sm font-bold 
            hover:bg-green-600 transition disabled:opacity-50 disabled:cursor-not-allowed
            flex items-center justify-center gap-2"
        >
          {mastering ? (
            <>
              <span className="animate-spin inline-block">⏳</span>
              标记中...
            </>
          ) : (
            <>
              ✅ 标记已掌握
            </>
          )}
        </button>
      )}

      {mastered && (
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-600 rounded-xl text-sm font-bold">
          ✅ 已掌握
        </div>
      )}
    </div>
  )
}
