import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getHomeworks } from '../api.js'

export default function HomeworkPage({ user }) {
  const [homeworks, setHomeworks] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    async function load() {
      try {
        const data = await getHomeworks()
        setHomeworks(Array.isArray(data) ? data : data.homeworks || [])
      } catch (e) {
        console.error('加载作业失败:', e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  function formatDate(dateStr) {
    if (!dateStr) return '未设置'
    const d = new Date(dateStr)
    if (isNaN(d.getTime())) return dateStr
    return d.toLocaleString('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  function getDueStyle(dueDate, status) {
    if (!dueDate || status === 'submitted') return { text: 'text-slate-500', label: '' }
    const now = new Date().getTime()
    const due = new Date(dueDate).getTime()
    if (isNaN(due)) return { text: 'text-slate-500', label: '' }

    if (due < now) {
      return { text: 'text-danger', label: '已逾期' }
    }
    if (due - now < 24 * 60 * 60 * 1000) {
      return { text: 'text-warning', label: '快到期' }
    }
    return { text: 'text-slate-500', label: '' }
  }

  const statusConfig = {
    pending: { label: '未开始', className: 'bg-primary-light text-primary' },
    submitted: { label: '已提交', className: 'bg-success-light text-success' },
    overdue: { label: '已逾期', className: 'bg-danger-light text-danger' }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">📚</div>
          <p className="text-slate-500 font-medium">正在加载作业列表...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black text-slate-800 mb-8">📚 作业大厅</h1>

      {homeworks.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 shadow-md text-center">
          <div className="text-5xl mb-4">🚀</div>
          <p className="text-slate-500 font-medium text-lg">
            暂无作业，先去课程地图学习吧！
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {homeworks.map((hw, idx) => {
            const status = hw.status || 'pending'
            const cfg = statusConfig[status] || statusConfig.pending
            const dueStyle = getDueStyle(hw.dueDate, status)

            return (
              <div
                key={hw.id || idx}
                onClick={() => navigate(`/homework/${hw.id}`)}
                className="bg-white rounded-2xl p-5 shadow-md cursor-pointer hover:shadow-lg transition-all hover:-translate-y-0.5 animate-fade-in"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="font-bold text-slate-800 text-lg truncate">
                        {hw.title || '未命名作业'}
                      </h3>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${cfg.className}`}>
                        {cfg.label}
                      </span>
                    </div>

                    <p className="text-sm text-slate-500 truncate mb-2">
                      {hw.description || '暂无描述'}
                    </p>

                    <div className="flex items-center gap-3 flex-wrap text-xs">
                      {hw.unitName && (
                        <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded-lg font-medium">
                          📖 {hw.unitName}
                        </span>
                      )}

                      <span className={`font-medium ${dueStyle.text}`}>
                        ⏰ 截止：{formatDate(hw.dueDate)}
                        {dueStyle.label && (
                          <span className="ml-1 font-bold">({dueStyle.label})</span>
                        )}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1 shrink-0">
                    {status === 'submitted' && typeof hw.score === 'number' && (
                      <div className="text-2xl font-black text-success">
                        {hw.score}<span className="text-sm font-bold text-slate-400">分</span>
                      </div>
                    )}
                    {status === 'submitted' && typeof hw.score !== 'number' && (
                      <span className="text-xs font-bold text-slate-400">待批改</span>
                    )}
                    <span className="text-slate-400 text-lg">›</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
