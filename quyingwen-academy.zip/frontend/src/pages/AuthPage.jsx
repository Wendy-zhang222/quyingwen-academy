import { useState } from 'react'
import { login, register } from '../api.js'

export default function AuthPage({ setUser }) {
  const [tab, setTab] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [role, setRole] = useState('student')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      let res
      if (tab === 'login') {
        res = await login(email, password)
      } else {
        res = await register(email, password, name, role)
      }
      if (res.error) {
        setError(res.error)
      } else {
        localStorage.setItem('token', res.token)
        setUser(res.user)
      }
    } catch (err) {
      setError('网络错误，请重试')
    } finally {
      setLoading(false)
    }
  }

  const demoLogin = async () => {
    setLoading(true)
    const res = await login('student@demo.com', 'demo123')
    if (res.token) {
      localStorage.setItem('token', res.token)
      setUser(res.user)
    } else {
      // If demo account doesn't exist, create it first or show error
      setError('演示账号不存在，请先注册')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🚀</div>
          <h1 className="text-3xl font-black text-slate-800 mb-2">趣英文学院</h1>
          <p className="text-slate-500">成长式英语阅读，从零到精通</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex mb-6 bg-slate-100 rounded-xl p-1">
            <button
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition ${tab === 'login' ? 'bg-white shadow text-primary' : 'text-slate-500'}`}
              onClick={() => setTab('login')}
            >
              登录
            </button>
            <button
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition ${tab === 'register' ? 'bg-white shadow text-primary' : 'text-slate-500'}`}
              onClick={() => setTab('register')}
            >
              注册
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-danger-light text-danger rounded-lg text-sm font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {tab === 'register' && (
              <>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">昵称</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition"
                    placeholder="请输入你的昵称"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">角色</label>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setRole('student')}
                      className={`flex-1 py-2.5 rounded-xl border-2 text-sm font-bold transition ${role === 'student' ? 'border-primary bg-primary-light text-primary' : 'border-slate-200 text-slate-500'}`}
                    >
                      👨‍🎓 学生
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('teacher')}
                      className={`flex-1 py-2.5 rounded-xl border-2 text-sm font-bold transition ${role === 'teacher' ? 'border-primary bg-primary-light text-primary' : 'border-slate-200 text-slate-500'}`}
                    >
                      👨‍🏫 教师
                    </button>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">邮箱</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition"
                placeholder="your@email.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">密码</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition"
                placeholder="至少6位密码"
                required
                minLength={6}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-primary text-white rounded-xl font-bold text-lg hover:bg-blue-600 transition disabled:opacity-50"
            >
              {loading ? '⏳ 处理中...' : tab === 'login' ? '🔐 立即登录' : '✨ 注册账号'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-slate-100">
            <button
              onClick={demoLogin}
              disabled={loading}
              className="w-full py-3 bg-secondary-light text-secondary border-2 border-secondary rounded-xl font-bold hover:bg-secondary hover:text-white transition disabled:opacity-50"
            >
              🚀 演示体验 (免注册)
            </button>
            <p className="text-center text-xs text-slate-400 mt-2">
              教师账号: teacher@quyingwen.top / teacher123
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
