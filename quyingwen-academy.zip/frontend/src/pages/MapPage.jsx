import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getCourses, getCourseUnits, getProgress } from '../api.js'

export default function MapPage({ user }) {
  const [courses, setCourses] = useState([])
  const [unitsMap, setUnitsMap] = useState({})
  const [progress, setProgress] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    async function load() {
      try {
        const [cData, pData] = await Promise.all([getCourses(), getProgress()])
        setCourses(cData)
        setProgress(pData.progress || [])

        const units = {}
        for (const c of cData) {
          const uData = await getCourseUnits(c.id)
          units[c.id] = uData
        }
        setUnitsMap(units)
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const getUnitStatus = (unitId) => {
    const p = progress.find(p => p.unit_id === unitId)
    if (p) return p.status
    // Check if it's the first unit of first course
    const firstCourse = courses[0]
    if (firstCourse && unitsMap[firstCourse.id]) {
      const firstUnit = unitsMap[firstCourse.id][0]
      if (firstUnit && firstUnit.id === unitId) return 'unlocked'
    }
    return 'locked'
  }

  const getUnitProgress = (unitId) => {
    return progress.find(p => p.unit_id === unitId)
  }

  const isUnitAvailable = (courseIdx, unitIdx, unitId) => {
    const status = getUnitStatus(unitId)
    if (status !== 'locked') return true
    // First unit of first course is always available
    if (courseIdx === 0 && unitIdx === 0) return true
    // A unit is available if previous unit in same course is completed
    const prevUnit = unitsMap[courses[courseIdx]?.id]?.[unitIdx - 1]
    if (prevUnit) {
      const prevStatus = getUnitStatus(prevUnit.id)
      return prevStatus === 'completed' || prevStatus === 'unlocked'
    }
    // Or if last unit of previous course is completed
    if (courseIdx > 0) {
      const prevCourseUnits = unitsMap[courses[courseIdx - 1]?.id]
      if (prevCourseUnits?.length) {
        const lastPrev = prevCourseUnits[prevCourseUnits.length - 1]
        const lastStatus = getUnitStatus(lastPrev.id)
        return lastStatus === 'completed'
      }
    }
    return false
  }

  const getCourseProgress = (courseId) => {
    const units = unitsMap[courseId] || []
    if (!units.length) return 0
    const completed = units.filter(u => getUnitStatus(u.id) === 'completed').length
    return Math.round((completed / units.length) * 100)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">📚</div>
          <p className="text-slate-500 font-medium">正在加载课程地图...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-black text-slate-800 mb-2">
          🗺️ 你的成长之路
        </h1>
        <p className="text-slate-500">
          从字母到自由阅读，每个脚印都是成长！
        </p>
      </div>

      {/* XP & Level Badge */}
      <div className="flex justify-center mb-10">
        <div className="bg-white rounded-2xl shadow-lg px-6 py-4 flex items-center gap-6">
          <div className="text-center">
            <div className="text-3xl font-black text-primary">{user?.level || 1}</div>
            <div className="text-xs font-bold text-slate-400">LEVEL</div>
          </div>
          <div className="w-px h-10 bg-slate-200" />
          <div className="text-center">
            <div className="text-2xl font-black text-secondary">
              {user?.totalXP || 0}
            </div>
            <div className="text-xs font-bold text-slate-400">XP 成长值</div>
          </div>
        </div>
      </div>

      {/* Course Map */}
      <div className="space-y-12">
        {courses.map((course, courseIdx) => {
          const units = unitsMap[course.id] || []
          const coursePct = getCourseProgress(course.id)
          const isCurrentCourse = units.some(u => {
            const s = getUnitStatus(u.id)
            return s === 'in_progress' || s === 'unlocked'
          }) || (courseIdx === 0 && units.every(u => getUnitStatus(u.id) === 'locked'))

          return (
            <div key={course.id} className="animate-fade-in">
              {/* Course Header */}
              <div className="flex items-center gap-4 mb-6">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-lg"
                  style={{ backgroundColor: course.color + '20', color: course.color }}
                >
                  {course.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-slate-800">{course.name}</h2>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">
                      Lv.{course.level}
                    </span>
                  </div>
                  <p className="text-sm text-slate-500">{course.description}</p>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-slate-700">{coursePct}%</div>
                  <div className="w-24 h-2 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${coursePct}%`, backgroundColor: course.color }}
                    />
                  </div>
                </div>
              </div>

              {/* Units Path */}
              <div className="relative pl-8 md:pl-0">
                {/* Path line */}
                <div
                  className="absolute left-7 md:left-1/2 top-0 bottom-0 w-1 -translate-x-1/2 rounded-full"
                  style={{
                    background: `linear-gradient(to bottom, ${course.color}40, ${course.color}20)`
                  }}
                />

                <div className="space-y-6">
                  {units.map((unit, unitIdx) => {
                    const status = getUnitStatus(unit.id)
                    const p = getUnitProgress(unit.id)
                    const available = isUnitAvailable(courseIdx, unitIdx, unit.id)
                    const isLeft = unitIdx % 2 === 0

                    const nodeClasses = `
                      relative flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 cursor-pointer
                      ${status === 'completed'
                        ? 'bg-gradient-to-r from-amber-50 to-yellow-50 border-2 border-amber-300 shadow-md hover:shadow-lg'
                        : status === 'in_progress' || (available && status === 'unlocked')
                          ? 'bg-white border-2 border-primary shadow-lg hover:shadow-xl animate-pulse-glow'
                          : 'bg-slate-100 border-2 border-slate-200 opacity-60 cursor-not-allowed'
                      }
                    `

                    return (
                      <div
                        key={unit.id}
                        className={`flex ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'} items-center gap-4`}
                        onClick={() => {
                          if (available || status !== 'locked') {
                            navigate(`/unit/${unit.id}`)
                          }
                        }}
                      >
                        {/* Node circle */}
                        <div className="relative z-10 flex-shrink-0">
                          <div
                            className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-black shadow-lg transition-all
                              ${status === 'completed'
                                ? 'bg-gradient-to-br from-amber-400 to-yellow-500 text-white'
                                : status === 'in_progress' || (available && status === 'unlocked')
                                  ? 'bg-gradient-to-br from-primary to-blue-600 text-white'
                                  : 'bg-slate-300 text-slate-500'
                              }
                            `}
                          >
                            {status === 'completed' ? '⭐' : unitIdx + 1}
                          </div>
                        </div>

                        {/* Unit Card */}
                        <div className={`flex-1 ${isLeft ? 'md:text-left' : 'md:text-right'}`}>
                          <div className={nodeClasses}>
                            <div className="flex-1">
                              <h3 className="font-bold text-slate-800">{unit.name}</h3>
                              <p className="text-xs text-slate-500 mt-1">{unit.content}</p>
                              {p?.stars > 0 && (
                                <div className="flex gap-1 mt-2">
                                  {[1, 2, 3].map(i => (
                                    <span key={i} className={`text-lg ${i <= p.stars ? 'text-amber-400' : 'text-slate-200'}`}>
                                      ⭐
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                            {status === 'completed' && (
                              <div className="text-success font-bold text-sm">✅ 已完成</div>
                            )}
                            {status === 'in_progress' && (
                              <div className="text-primary font-bold text-sm">🔄 进行中</div>
                            )}
                            {!available && status === 'locked' && (
                              <div className="text-slate-400 text-sm">🔒</div>
                            )}
                          </div>
                        </div>

                        {/* Spacer for alternating layout */}
                        <div className="hidden md:block w-14 flex-shrink-0" />
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Level Lock Info */}
      {courses.some(c => {
        const units = unitsMap[c.id] || []
        return units.length > 0 && getUnitStatus(units[0]?.id) === 'locked'
      }) && (
        <div className="mt-12 text-center p-6 bg-white rounded-2xl shadow-lg">
          <div className="text-3xl mb-2">🎯</div>
          <p className="text-slate-600 font-medium">
            完成前面的课程，解锁更多精彩世界！
          </p>
        </div>
      )}
    </div>
  )
}
