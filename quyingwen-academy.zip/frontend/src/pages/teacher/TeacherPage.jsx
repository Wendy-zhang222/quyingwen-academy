import { useState, useEffect } from 'react'
import { getTeacherStats, getTeacherStudents, getStudentProgress, teacherUnlock, getBooks, getBook, createBook, uploadBookPages, uploadBookAudio, deleteBook, createClass, getClasses, getClassStudents, getTeacherHomeworks, getTeacherHomework, createHomework, addHomeworkQuestion, updateHomeworkStatus, deleteHomework, getCourses } from '../../api.js'
import AudioRecorder from '../../components/AudioRecorder.jsx'
import PdfToImages from '../../components/PdfToImages.jsx'

export default function TeacherPage() {
  const [stats, setStats] = useState({})
  const [students, setStudents] = useState([])
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [studentProgress, setStudentProgress] = useState([])
  const [loading, setLoading] = useState(true)
  const [unlockMsg, setUnlockMsg] = useState('')
  const [tab, setTab] = useState('students') // students | books | classes | homework

  // Books state
  const [books, setBooks] = useState([])
  const [showNewBook, setShowNewBook] = useState(false)

  // Classes state
  const [classes, setClasses] = useState([])
  const [showNewClass, setShowNewClass] = useState(false)
  const [newClassName, setNewClassName] = useState('')
  const [selectedClass, setSelectedClass] = useState(null)
  const [classStudents, setClassStudents] = useState([])
  const [classMsg, setClassMsg] = useState('')
  // Books state (continued)
  const [newBookTitle, setNewBookTitle] = useState('')
  const [newBookDesc, setNewBookDesc] = useState('')
  const [selectedBook, setSelectedBook] = useState(null)
  const [pageFiles, setPageFiles] = useState([])
  const [audioFile, setAudioFile] = useState(null)
  const [audioPageNum, setAudioPageNum] = useState(1)
  const [bookMsg, setBookMsg] = useState('')
  const [showRecorder, setShowRecorder] = useState(false)
  const [showPdfUploader, setShowPdfUploader] = useState(false)

  // Homework state
  const [homeworks, setHomeworks] = useState([])
  const [selectedHomework, setSelectedHomework] = useState(null)
  const [showNewHomework, setShowNewHomework] = useState(false)
  const [newHomeworkTitle, setNewHomeworkTitle] = useState('')
  const [newHomeworkDesc, setNewHomeworkDesc] = useState('')
  const [newHomeworkUnitId, setNewHomeworkUnitId] = useState('')
  const [newHomeworkDueDate, setNewHomeworkDueDate] = useState('')
  const [showNewQuestion, setShowNewQuestion] = useState(false)
  const [newQuestionType, setNewQuestionType] = useState('multiple_choice')
  const [newQuestionData, setNewQuestionData] = useState('{}')
  const [newQuestionAnswer, setNewQuestionAnswer] = useState('')
  const [newQuestionExplanation, setNewQuestionExplanation] = useState('')
  const [newQuestionPoints, setNewQuestionPoints] = useState(1)
  const [homeworkMsg, setHomeworkMsg] = useState('')
  const [courses, setCourses] = useState([])

  useEffect(() => {
    async function load() {
      try {
        const [sData, stData, bData, cData, hData, coData] = await Promise.all([
          getTeacherStats(),
          getTeacherStudents(),
          getBooks(),
          getClasses(),
          getTeacherHomeworks(),
          getCourses()
        ])
        setStats(sData)
        setStudents(stData)
        setBooks(bData)
        setClasses(cData)
        setHomeworks(hData)
        setCourses(coData)
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const viewStudent = async (student) => {
    setSelectedStudent(student)
    const data = await getStudentProgress(student.id)
    setStudentProgress(data)
  }

  const handleUnlock = async (studentId, unitId) => {
    const res = await teacherUnlock(studentId, unitId)
    if (res.success) {
      setUnlockMsg('✅ 已解锁单元')
      setTimeout(() => setUnlockMsg(''), 2000)
      if (selectedStudent) viewStudent(selectedStudent)
    }
  }

  const handleCreateBook = async (e) => {
    e.preventDefault()
    if (!newBookTitle.trim()) return
    const res = await createBook(newBookTitle, newBookDesc)
    if (res.success) {
      setBookMsg('✅ 图书创建成功')
      setNewBookTitle('')
      setNewBookDesc('')
      setShowNewBook(false)
      const bData = await getBooks()
      setBooks(bData)
      setSelectedBook(bData.find(b => b.id === res.id))
    } else {
      setBookMsg(res.error || '创建失败')
    }
    setTimeout(() => setBookMsg(''), 3000)
  }

  const handleUploadPages = async (e) => {
    e.preventDefault()
    if (!selectedBook || pageFiles.length === 0) return
    setBookMsg('⏳ 正在上传图片...')
    const res = await uploadBookPages(selectedBook.id, pageFiles)
    if (res.success) {
      setBookMsg(`✅ 已上传 ${res.inserted} 页`)
      setPageFiles([])
      const bData = await getBooks()
      setBooks(bData)
      // Refresh selected book
      const updated = bData.find(b => b.id === selectedBook.id)
      if (updated) setSelectedBook(updated)
    } else {
      setBookMsg(res.error || '上传失败')
    }
    setTimeout(() => setBookMsg(''), 3000)
  }

  const handleUploadAudio = async (e) => {
    e.preventDefault()
    if (!selectedBook || !audioFile) return
    setBookMsg('⏳ 正在上传音频...')
    const res = await uploadBookAudio(selectedBook.id, audioFile, audioPageNum)
    if (res.success) {
      setBookMsg('✅ 音频上传成功')
      setAudioFile(null)
      const bData = await getBooks()
      setBooks(bData)
      const updated = bData.find(b => b.id === selectedBook.id)
      if (updated) setSelectedBook(updated)
    } else {
      setBookMsg(res.error || '上传失败')
    }
    setTimeout(() => setBookMsg(''), 3000)
  }

  const handleDeleteBook = async (bookId) => {
    if (!confirm('确定删除这本图书？所有页面和音频将一并删除。')) return
    const res = await deleteBook(bookId)
    if (res.success) {
      setBookMsg('✅ 已删除')
      setSelectedBook(null)
      const bData = await getBooks()
      setBooks(bData)
    }
    setTimeout(() => setBookMsg(''), 3000)
  }

  const selectBook = async (book) => {
    if (selectedBook?.id === book.id) {
      setSelectedBook(null)
      return
    }
    const fullBook = await getBook(book.id)
    setSelectedBook(fullBook)
  }

  // ── Class Management ───────────────────────────────────
  const handleCreateClass = async (e) => {
    e.preventDefault()
    if (!newClassName.trim()) return
    const res = await createClass(newClassName.trim())
    if (res.success) {
      setClassMsg('✅ 班级创建成功，班级码：' + res.code)
      setNewClassName('')
      setShowNewClass(false)
      const cData = await getClasses()
      setClasses(cData)
    } else {
      setClassMsg(res.error || '创建失败')
    }
    setTimeout(() => setClassMsg(''), 3000)
  }

  const viewClass = async (cls) => {
    if (selectedClass?.id === cls.id) {
      setSelectedClass(null)
      setClassStudents([])
      return
    }
    const data = await getClassStudents(cls.id)
    setSelectedClass(data.class)
    setClassStudents(data.students)
  }

  // ── Homework Management ───────────────────────────────────
  const loadHomeworks = async () => {
    const data = await getTeacherHomeworks()
    setHomeworks(data)
  }

  const selectHomework = async (hw) => {
    if (selectedHomework?.id === hw.id) {
      setSelectedHomework(null)
      return
    }
    const data = await getTeacherHomework(hw.id)
    setSelectedHomework(data)
  }

  const handleCreateHomework = async (e) => {
    e.preventDefault()
    if (!newHomeworkTitle.trim() || !newHomeworkUnitId) return
    const res = await createHomework(newHomeworkTitle, newHomeworkDesc, newHomeworkUnitId, newHomeworkDueDate)
    if (res.success) {
      setHomeworkMsg('✅ 作业创建成功')
      setNewHomeworkTitle('')
      setNewHomeworkDesc('')
      setNewHomeworkUnitId('')
      setNewHomeworkDueDate('')
      setShowNewHomework(false)
      await loadHomeworks()
    } else {
      setHomeworkMsg(res.error || '创建失败')
    }
    setTimeout(() => setHomeworkMsg(''), 3000)
  }

  const handleAddQuestion = async (e) => {
    e.preventDefault()
    if (!selectedHomework) return
    let questionData
    try {
      questionData = JSON.parse(newQuestionData)
    } catch {
      setHomeworkMsg('❌ 题目内容 JSON 格式错误')
      setTimeout(() => setHomeworkMsg(''), 3000)
      return
    }
    const res = await addHomeworkQuestion(selectedHomework.id, newQuestionType, questionData, newQuestionAnswer, newQuestionExplanation, Number(newQuestionPoints))
    if (res.success) {
      setHomeworkMsg('✅ 题目添加成功')
      setNewQuestionData('{}')
      setNewQuestionAnswer('')
      setNewQuestionExplanation('')
      setNewQuestionPoints(1)
      setShowNewQuestion(false)
      const data = await getTeacherHomework(selectedHomework.id)
      setSelectedHomework(data)
      await loadHomeworks()
    } else {
      setHomeworkMsg(res.error || '添加失败')
    }
    setTimeout(() => setHomeworkMsg(''), 3000)
  }

  const handleToggleHomeworkStatus = async () => {
    if (!selectedHomework) return
    const newStatus = selectedHomework.status === 'published' ? 'draft' : 'published'
    const res = await updateHomeworkStatus(selectedHomework.id, newStatus)
    if (res.success) {
      setHomeworkMsg(`✅ 已${newStatus === 'published' ? '发布' : '设为草稿'}`)
      const data = await getTeacherHomework(selectedHomework.id)
      setSelectedHomework(data)
      await loadHomeworks()
    } else {
      setHomeworkMsg(res.error || '操作失败')
    }
    setTimeout(() => setHomeworkMsg(''), 3000)
  }

  const handleDeleteHomework = async (hwId) => {
    if (!confirm('确定删除这份作业？所有题目和提交记录将一并删除。')) return
    const res = await deleteHomework(hwId)
    if (res.success) {
      setHomeworkMsg('✅ 已删除')
      setSelectedHomework(null)
      await loadHomeworks()
    } else {
      setHomeworkMsg(res.error || '删除失败')
    }
    setTimeout(() => setHomeworkMsg(''), 3000)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">👑</div>
          <p className="text-slate-500 font-medium">正在加载后台数据...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-black text-slate-800 mb-2">👑 教师控制台</h1>
      <p className="text-slate-500 mb-8">查看学生学习进度，管理课程内容</p>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-gradient-to-br from-primary to-blue-600 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl font-black">{stats.totalStudents || 0}</div>
          <div className="text-sm opacity-80">注册学生</div>
        </div>
        <div className="bg-gradient-to-br from-success to-emerald-600 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl font-black">{stats.totalCourses || 0}</div>
          <div className="text-sm opacity-80">课程总数</div>
        </div>
        <div className="bg-gradient-to-br from-secondary to-orange-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl font-black">{stats.totalCompleted || 0}</div>
          <div className="text-sm opacity-80">完成记录</div>
        </div>
      </div>

      {/* Tab Switch */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setTab('students')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition ${tab === 'students' ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          👥 学生管理
        </button>
        <button
          onClick={() => setTab('books')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition ${tab === 'books' ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          📚 图书管理
        </button>
        <button
          onClick={() => setTab('classes')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition ${tab === 'classes' ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          🏫 班级管理
        </button>
        <button
          onClick={() => setTab('homework')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition ${tab === 'homework' ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          📝 作业管理
        </button>
      </div>

      {bookMsg && (
        <div className={`mb-4 p-3 rounded-lg font-bold text-sm ${bookMsg.startsWith('✅') ? 'bg-success-light text-success' : 'bg-secondary-light text-secondary'}`}>
          {bookMsg}
        </div>
      )}

      {tab === 'students' && (
        <>
          {/* Students Table */}
          <div className="bg-white rounded-2xl p-6 shadow-md mb-8">
            <h2 className="font-bold text-lg text-slate-800 mb-4">👥 学生列表</h2>
            {students.length === 0 ? (
              <p className="text-slate-500 text-center py-8">暂无学生注册</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-slate-600">
                      <th className="text-left p-3 rounded-l-lg">学生</th>
                      <th className="text-left p-3">邮箱</th>
                      <th className="text-center p-3">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map(s => (
                      <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{s.avatar || '🎓'}</span>
                            <span className="font-bold">{s.name}</span>
                          </div>
                        </td>
                        <td className="p-3 text-slate-500">{s.email}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => viewStudent(s)}
                            className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                          >
                            查看进度
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Student Detail */}
          {selectedStudent && (
            <div className="bg-white rounded-2xl p-6 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{selectedStudent.avatar || '🎓'}</span>
                  <div>
                    <h2 className="font-bold text-xl text-slate-800">{selectedStudent.name}</h2>
                    <p className="text-sm text-slate-500">{selectedStudent.email}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedStudent(null)} className="text-sm text-slate-400 hover:text-slate-600">✕ 关闭</button>
              </div>

              {unlockMsg && (
                <div className="mb-4 p-3 bg-success-light text-success rounded-lg font-bold text-sm">{unlockMsg}</div>
              )}

              {studentProgress.length === 0 ? (
                <p className="text-slate-500 text-center py-8">该学生暂无学习记录</p>
              ) : (
                <div className="space-y-3">
                  {studentProgress.map(p => (
                    <div key={p.id} className="flex items-center gap-4 p-3 bg-slate-50 rounded-xl">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm
                        ${p.status === 'completed' ? 'bg-success text-white' : p.status === 'in_progress' ? 'bg-primary text-white' : 'bg-slate-200 text-slate-500'}`}>
                        {p.status === 'completed' ? '✓' : p.status === 'in_progress' ? '⏳' : '🔒'}
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-slate-800">{p.course_name} · {p.unit_name}</div>
                        <div className="text-xs text-slate-500">
                          {p.status === 'completed' ? '已完成' : p.status === 'in_progress' ? '进行中' : '已解锁'} · 得分 {p.score}%
                        </div>
                      </div>
                      <div className="flex gap-1">
                        {[1, 2, 3].map(i => (
                          <span key={i} className={`text-lg ${i <= p.stars ? 'text-amber-400' : 'text-slate-200'}`}>⭐</span>
                        ))}
                      </div>
                      {p.status === 'locked' && (
                        <button
                          onClick={() => handleUnlock(selectedStudent.id, p.unit_id)}
                          className="px-3 py-1.5 bg-secondary text-white rounded-lg text-xs font-bold hover:bg-orange-600 transition"
                        >
                          解锁
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {tab === 'books' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Book List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-lg text-slate-800">📚 图书列表</h2>
                <button
                  onClick={() => setShowNewBook(!showNewBook)}
                  className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                >
                  {showNewBook ? '取消' : '+ 新建'}
                </button>
              </div>

              {showNewBook && (
                <form onSubmit={handleCreateBook} className="mb-4 p-4 bg-slate-50 rounded-xl space-y-3">
                  <input
                    type="text"
                    value={newBookTitle}
                    onChange={e => setNewBookTitle(e.target.value)}
                    placeholder="图书标题"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                    required
                  />
                  <textarea
                    value={newBookDesc}
                    onChange={e => setNewBookDesc(e.target.value)}
                    placeholder="简介（可选）"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary h-20"
                  />
                  <button type="submit" className="w-full py-2 bg-primary text-white rounded-lg font-bold text-sm hover:bg-blue-600 transition">
                    ✨ 创建图书
                  </button>
                </form>
              )}

              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {books.length === 0 ? (
                  <p className="text-slate-500 text-center py-6 text-sm">暂无图书，点击「新建」创建</p>
                ) : (
                  books.map(book => (
                    <div
                      key={book.id}
                      onClick={() => selectBook(book)}
                      className={`p-3 rounded-xl cursor-pointer transition border-2
                        ${selectedBook?.id === book.id ? 'border-primary bg-primary-light' : 'border-transparent bg-slate-50 hover:bg-slate-100'}
                      `}
                    >
                      <div className="font-bold text-slate-800 text-sm">{book.title}</div>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-1">{book.description || '暂无简介'}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-[10px] text-slate-400">{new Date(book.created_at).toLocaleDateString()}</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteBook(book.id) }}
                          className="text-xs text-danger hover:bg-danger-light px-2 py-1 rounded transition"
                        >
                          删除
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Book Editor */}
          <div className="lg:col-span-2">
            {selectedBook ? (
              <div className="bg-white rounded-2xl p-5 shadow-md space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="font-bold text-xl text-slate-800">{selectedBook.title}</h2>
                    <p className="text-sm text-slate-500">ID: {selectedBook.id}</p>
                  </div>
                </div>

                {/* Upload Pages */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <h3 className="font-bold text-sm text-slate-700 mb-3">📄 上传图片页面（支持多选，按顺序排列）</h3>
                  <form onSubmit={handleUploadPages} className="space-y-3">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={e => setPageFiles(Array.from(e.target.files))}
                      className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:font-bold hover:file:bg-blue-600"
                    />
                    {pageFiles.length > 0 && (
                      <p className="text-xs text-slate-500">已选择 {pageFiles.length} 张图片</p>
                    )}
                    <button
                      type="submit"
                      disabled={pageFiles.length === 0}
                      className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-blue-600 transition disabled:opacity-40"
                    >
                      📤 上传页面
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowPdfUploader(!showPdfUploader)}
                      className={`w-full py-2 rounded-lg text-sm font-bold transition mt-2
                        ${showPdfUploader ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-primary-light text-primary border border-primary hover:bg-primary hover:text-white'}
                      `}
                    >
                      {showPdfUploader ? '✕ 关闭 PDF 上传' : '📄 从 PDF 导入页面'}
                    </button>
                  </form>

                  {/* PDF Uploader */}
                  {showPdfUploader && selectedBook && (
                    <div className="mt-4">
                      <PdfToImages
                        onUpload={async (files) => {
                          setBookMsg('⏳ 正在上传 PDF 页面...')
                          const res = await uploadBookPages(selectedBook.id, files)
                          if (res.success) {
                            setBookMsg(`✅ 已上传 ${res.inserted} 页`)
                            setShowPdfUploader(false)
                            setPageFiles([])
                            const bData = await getBooks()
                            setBooks(bData)
                            const updated = bData.find(b => b.id === selectedBook.id)
                            if (updated) setSelectedBook(updated)
                          } else {
                            setBookMsg(res.error || '上传失败')
                          }
                          setTimeout(() => setBookMsg(''), 3000)
                        }}
                        onCancel={() => setShowPdfUploader(false)}
                      />
                    </div>
                  )}
                </div>

                {/* Upload Audio */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <h3 className="font-bold text-sm text-slate-700 mb-3">🔊 上传页面音频（为每页单独配音）</h3>
                  <form onSubmit={handleUploadAudio} className="space-y-3">
                    <div className="flex gap-3">
                      <input
                        type="file"
                        accept="audio/*"
                        onChange={e => setAudioFile(e.target.files?.[0] || null)}
                        className="flex-1 text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-secondary file:text-white file:font-bold hover:file:bg-orange-600"
                      />
                      <input
                        type="number"
                        min={1}
                        value={audioPageNum}
                        onChange={e => setAudioPageNum(Number(e.target.value))}
                        className="w-20 px-3 py-2 rounded-lg border border-slate-200 text-sm text-center"
                        placeholder="页号"
                      />
                    </div>
                    {audioFile && (
                      <p className="text-xs text-slate-500">{audioFile.name} → 第 {audioPageNum} 页</p>
                    )}
                    <button
                      type="submit"
                      disabled={!audioFile}
                      className="px-4 py-2 bg-secondary text-white rounded-lg text-sm font-bold hover:bg-orange-600 transition disabled:opacity-40"
                    >
                      🔊 上传音频
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowRecorder(!showRecorder)}
                      className={`w-full py-2 rounded-lg text-sm font-bold transition mt-2
                        ${showRecorder ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-danger-light text-danger border border-danger hover:bg-danger hover:text-white'}
                      `}
                    >
                      {showRecorder ? '✕ 关闭录音' : '🎙️ 直接录制音频'}
                    </button>
                  </form>

                  {/* Browser Recorder */}
                  {showRecorder && selectedBook && (
                    <div className="mt-4">
                      <AudioRecorder
                        pageNumber={audioPageNum}
                        onUpload={async (file, page) => {
                          setBookMsg('⏳ 正在上传录音...')
                          const res = await uploadBookAudio(selectedBook.id, file, page)
                          if (res.success) {
                            setBookMsg('✅ 录音上传成功')
                            setShowRecorder(false)
                            const bData = await getBooks()
                            setBooks(bData)
                            const updated = bData.find(b => b.id === selectedBook.id)
                            if (updated) setSelectedBook(updated)
                          } else {
                            setBookMsg(res.error || '上传失败')
                          }
                          setTimeout(() => setBookMsg(''), 3000)
                        }}
                        onCancel={() => setShowRecorder(false)}
                      />
                    </div>
                  )}
                </div>

                {/* Preview */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <h3 className="font-bold text-sm text-slate-700 mb-3">👁️ 预览</h3>
                  <p className="text-xs text-slate-500 mb-2">在单元页面中，学生会看到这本图书并可以阅读</p>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                    {selectedBook.pages?.map((page, i) => (
                      <div key={page.id} className="relative aspect-[3/4] rounded-lg overflow-hidden border border-slate-200">
                        <img
                          src={`http://localhost:3001${page.image_path}`}
                          alt={`页 ${page.page_number}`}
                          className="w-full h-full object-cover"
                        />
                        {selectedBook.audios?.find(a => a.page_number === page.page_number) && (
                          <div className="absolute top-1 right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                            <span className="text-[8px] text-white">🔊</span>
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-center text-[10px] py-0.5">
                          P{page.page_number}
                        </div>
                      </div>
                    )) || <p className="text-xs text-slate-400 col-span-full text-center py-4">暂无页面</p>}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-12 shadow-md text-center">
                <div className="text-5xl mb-3">📚</div>
                <p className="text-slate-500 font-medium">选择左侧图书进行管理</p>
                <p className="text-sm text-slate-400 mt-1">或点击「新建」创建一本新图书</p>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'classes' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Class List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-lg text-slate-800">🏫 我的班级</h2>
                <button
                  onClick={() => setShowNewClass(!showNewClass)}
                  className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                >
                  {showNewClass ? '取消' : '+ 创建'}
                </button>
              </div>

              {showNewClass && (
                <form onSubmit={handleCreateClass} className="mb-4 p-4 bg-slate-50 rounded-xl space-y-3">
                  <input
                    type="text"
                    value={newClassName}
                    onChange={e => setNewClassName(e.target.value)}
                    placeholder="班级名称（例如：三年级一班）"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                    required
                  />
                  <button type="submit" className="w-full py-2 bg-primary text-white rounded-lg font-bold text-sm hover:bg-blue-600 transition">
                    ✨ 创建班级
                  </button>
                </form>
              )}

              {classMsg && (
                <div className={`mb-4 p-3 rounded-lg font-bold text-sm ${classMsg.startsWith('✅') ? 'bg-success-light text-success' : 'bg-danger-light text-danger'}`}>
                  {classMsg}
                </div>
              )}

              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {classes.length === 0 ? (
                  <p className="text-slate-500 text-center py-6 text-sm">暂无班级，点击「创建」新建</p>
                ) : (
                  classes.map(cls => (
                    <div
                      key={cls.id}
                      onClick={() => viewClass(cls)}
                      className={`p-3 rounded-xl cursor-pointer transition border-2
                        ${selectedClass?.id === cls.id ? 'border-primary bg-primary-light' : 'border-transparent bg-slate-50 hover:bg-slate-100'}
                      `}
                    >
                      <div className="font-bold text-slate-800 text-sm">{cls.name}</div>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs font-mono bg-slate-200 px-2 py-0.5 rounded text-slate-600">{cls.code}</span>
                        <span className="text-xs text-slate-400">{cls.student_count} 人</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Class Detail */}
          <div className="lg:col-span-2">
            {selectedClass ? (
              <div className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="font-bold text-xl text-slate-800">{selectedClass.name}</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs font-mono bg-primary-light text-primary px-2 py-0.5 rounded font-bold">班级码: {selectedClass.code}</span>
                      <span className="text-xs text-slate-400">创建于 {new Date(selectedClass.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => { setSelectedClass(null); setClassStudents([]) }}
                    className="text-sm text-slate-400 hover:text-slate-600"
                  >
                    ✕ 关闭
                  </button>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
                  <p className="text-xs text-amber-700 font-medium">
                    💡 将班级码 <span className="font-mono font-bold bg-white px-1 rounded">{selectedClass.code}</span> 分享给学生，学生在注册或设置中输入即可加入班级。
                  </p>
                </div>

                <h3 className="font-bold text-sm text-slate-700 mb-3">👥 班级学生 ({classStudents.length})</h3>
                {classStudents.length === 0 ? (
                  <p className="text-slate-500 text-center py-8">暂无学生加入此班级</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-slate-50 text-slate-600">
                          <th className="text-left p-2 rounded-l-lg">学生</th>
                          <th className="text-left p-2">邮箱</th>
                          <th className="text-center p-2">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {classStudents.map(s => (
                          <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="p-2">
                              <div className="flex items-center gap-2">
                                <span className="text-xl">{s.avatar || '🎓'}</span>
                                <span className="font-bold">{s.name}</span>
                              </div>
                            </td>
                            <td className="p-2 text-slate-500">{s.email}</td>
                            <td className="p-2 text-center">
                              <button
                                onClick={() => viewStudent(s)}
                                className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                              >
                                查看进度
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-12 shadow-md text-center">
                <div className="text-5xl mb-3">🏫</div>
                <p className="text-slate-500 font-medium">选择左侧班级查看详情</p>
                <p className="text-sm text-slate-400 mt-1">或点击「创建」新建班级</p>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'homework' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Homework List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-lg text-slate-800">📝 作业列表</h2>
                <button
                  onClick={() => setShowNewHomework(!showNewHomework)}
                  className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                >
                  {showNewHomework ? '取消' : '+ 新建'}
                </button>
              </div>

              {showNewHomework && (
                <form onSubmit={handleCreateHomework} className="mb-4 p-4 bg-slate-50 rounded-xl space-y-3">
                  <input
                    type="text"
                    value={newHomeworkTitle}
                    onChange={e => setNewHomeworkTitle(e.target.value)}
                    placeholder="作业标题"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                    required
                  />
                  <textarea
                    value={newHomeworkDesc}
                    onChange={e => setNewHomeworkDesc(e.target.value)}
                    placeholder="作业描述（可选）"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary h-20"
                  />
                  <select
                    value={newHomeworkUnitId}
                    onChange={e => setNewHomeworkUnitId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary bg-white"
                    required
                  >
                    <option value="">选择单元</option>
                    {courses.map(course => (
                      <optgroup key={course.id} label={course.name}>
                        {course.units?.map(unit => (
                          <option key={unit.id} value={unit.id}>{unit.name}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                  <input
                    type="datetime-local"
                    value={newHomeworkDueDate}
                    onChange={e => setNewHomeworkDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                  />
                  <button type="submit" className="w-full py-2 bg-primary text-white rounded-lg font-bold text-sm hover:bg-blue-600 transition">
                    ✨ 创建作业
                  </button>
                </form>
              )}

              {homeworkMsg && (
                <div className={`mb-4 p-3 rounded-lg font-bold text-sm ${homeworkMsg.startsWith('✅') ? 'bg-success-light text-success' : 'bg-danger-light text-danger'}`}>
                  {homeworkMsg}
                </div>
              )}

              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {homeworks.length === 0 ? (
                  <p className="text-slate-500 text-center py-6 text-sm">暂无作业，点击「新建」创建</p>
                ) : (
                  homeworks.map(hw => (
                    <div
                      key={hw.id}
                      onClick={() => selectHomework(hw)}
                      className={`p-3 rounded-xl cursor-pointer transition border-2
                        ${selectedHomework?.id === hw.id ? 'border-primary bg-primary-light' : 'border-transparent bg-slate-50 hover:bg-slate-100'}
                      `}
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-slate-800 text-sm">{hw.title}</div>
                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${hw.status === 'published' ? 'bg-success-light text-success' : 'bg-slate-200 text-slate-600'}`}>
                          {hw.status === 'published' ? '已发布' : '草稿'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-slate-500">截止: {hw.due_date ? new Date(hw.due_date).toLocaleString() : '未设置'}</span>
                        <span className="text-xs text-slate-400">{hw.questions?.length || 0} 题</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-slate-400">{hw.submission_count || 0} 人提交</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteHomework(hw.id) }}
                          className="text-xs text-danger hover:bg-danger-light px-2 py-1 rounded transition"
                        >
                          删除
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Homework Detail */}
          <div className="lg:col-span-2">
            {selectedHomework ? (
              <div className="bg-white rounded-2xl p-5 shadow-md space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="font-bold text-xl text-slate-800">{selectedHomework.title}</h2>
                    <p className="text-sm text-slate-500">ID: {selectedHomework.id}</p>
                  </div>
                  <button
                    onClick={handleToggleHomeworkStatus}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition ${selectedHomework.status === 'published' ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-success text-white hover:bg-emerald-600'}`}
                  >
                    {selectedHomework.status === 'published' ? '设为草稿' : '发布作业'}
                  </button>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl space-y-3">
                  <h3 className="font-bold text-sm text-slate-700">📋 基本信息</h3>
                  <p className="text-sm text-slate-600">{selectedHomework.description || '暂无描述'}</p>
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500">
                    <span className="bg-white px-2 py-1 rounded border border-slate-200">单元: {selectedHomework.unit_name || selectedHomework.unit_id}</span>
                    <span className="bg-white px-2 py-1 rounded border border-slate-200">截止: {selectedHomework.due_date ? new Date(selectedHomework.due_date).toLocaleString() : '未设置'}</span>
                    <span className="bg-white px-2 py-1 rounded border border-slate-200">状态: {selectedHomework.status === 'published' ? '已发布' : '草稿'}</span>
                  </div>
                </div>

                {/* Questions List */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <h3 className="font-bold text-sm text-slate-700 mb-3">❓ 题目列表 ({selectedHomework.questions?.length || 0})</h3>
                  {selectedHomework.questions?.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-4">暂无题目</p>
                  ) : (
                    <div className="space-y-2">
                      {selectedHomework.questions.map((q, i) => (
                        <div key={q.id} className="bg-white p-3 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-primary">第 {i + 1} 题</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                              {q.type === 'multiple_choice' ? '单选' : q.type === 'multiple_answer' ? '多选' : q.type === 'fill_blank' ? '填空' : q.type === 'true_false' ? '判断' : '简答'}
                            </span>
                            <span className="text-xs text-slate-400">{q.points} 分</span>
                          </div>
                          <p className="text-sm text-slate-700 font-medium">{JSON.stringify(q.data)}</p>
                          <p className="text-xs text-slate-500 mt-1">答案: {q.answer}</p>
                          {q.explanation && <p className="text-xs text-slate-400 mt-0.5">解析: {q.explanation}</p>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Add Question */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-sm text-slate-700">➕ 添加题目</h3>
                    <button
                      onClick={() => setShowNewQuestion(!showNewQuestion)}
                      className="px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold hover:bg-blue-600 transition"
                    >
                      {showNewQuestion ? '取消' : '添加题目'}
                    </button>
                  </div>

                  {showNewQuestion && (
                    <form onSubmit={handleAddQuestion} className="space-y-3">
                      <select
                        value={newQuestionType}
                        onChange={e => setNewQuestionType(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary bg-white"
                      >
                        <option value="multiple_choice">单选题</option>
                        <option value="multiple_answer">多选题</option>
                        <option value="fill_blank">填空题</option>
                        <option value="true_false">判断题</option>
                        <option value="short_answer">简答题</option>
                      </select>
                      <textarea
                        value={newQuestionData}
                        onChange={e => setNewQuestionData(e.target.value)}
                        placeholder='题目内容（JSON 格式，例如：{"question":"...","options":["A","B"]}）'
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary h-24 font-mono"
                        required
                      />
                      <input
                        type="text"
                        value={newQuestionAnswer}
                        onChange={e => setNewQuestionAnswer(e.target.value)}
                        placeholder="答案"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                        required
                      />
                      <textarea
                        value={newQuestionExplanation}
                        onChange={e => setNewQuestionExplanation(e.target.value)}
                        placeholder="解析（可选）"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary h-16"
                      />
                      <input
                        type="number"
                        min={1}
                        value={newQuestionPoints}
                        onChange={e => setNewQuestionPoints(e.target.value)}
                        placeholder="分值"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-primary"
                        required
                      />
                      <button type="submit" className="w-full py-2 bg-primary text-white rounded-lg font-bold text-sm hover:bg-blue-600 transition">
                        ✨ 添加题目
                      </button>
                    </form>
                  )}
                </div>

                {/* Submissions */}
                <div className="p-4 bg-slate-50 rounded-xl">
                  <h3 className="font-bold text-sm text-slate-700 mb-3">📊 提交统计 ({selectedHomework.submissions?.length || 0})</h3>
                  {selectedHomework.submissions?.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-4">暂无学生提交</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-slate-100 text-slate-600">
                            <th className="text-left p-2 rounded-l-lg">学生</th>
                            <th className="text-center p-2">状态</th>
                            <th className="text-center p-2">得分</th>
                            <th className="text-right p-2 rounded-r-lg">提交时间</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedHomework.submissions.map(sub => (
                            <tr key={sub.id} className="border-b border-slate-100 hover:bg-white">
                              <td className="p-2">
                                <div className="flex items-center gap-2">
                                  <span className="text-lg">{sub.student_avatar || '🎓'}</span>
                                  <span className="font-bold">{sub.student_name}</span>
                                </div>
                              </td>
                              <td className="p-2 text-center">
                                <span className={`text-xs px-2 py-0.5 rounded font-bold ${sub.status === 'submitted' ? 'bg-success-light text-success' : sub.status === 'graded' ? 'bg-primary-light text-primary' : 'bg-slate-200 text-slate-600'}`}>
                                  {sub.status === 'submitted' ? '已提交' : sub.status === 'graded' ? '已批改' : '进行中'}
                                </span>
                              </td>
                              <td className="p-2 text-center font-bold">{sub.score ?? '-'}</td>
                              <td className="p-2 text-right text-xs text-slate-500">{sub.submitted_at ? new Date(sub.submitted_at).toLocaleString() : '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-12 shadow-md text-center">
                <div className="text-5xl mb-3">📝</div>
                <p className="text-slate-500 font-medium">选择左侧作业进行管理</p>
                <p className="text-sm text-slate-400 mt-1">或点击「新建」创建新作业</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
