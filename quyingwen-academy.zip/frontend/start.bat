@echo off
chcp 65001 >nul
cls
echo ======================================
echo  趣英文学院 - 前端启动脚本
echo ======================================
echo.

set "NODE_PATH=C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
set "PATH=%PATH%;%NODE_PATH%"
set "NPM=%NODE_PATH%\npm.cmd"

echo 正在启动前端开发服务器...
echo 访问地址：http://localhost:5173
echo 按 Ctrl+C 关闭服务器
echo.

"%NPM%" run dev

echo.
echo 服务器已关闭。
pause
