@echo off
chcp 65001 >nul
cls
echo ======================================
echo  趣英文学院 - 前端一键安装脚本
echo ======================================
echo.

set "NODE_PATH=C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
set "PATH=%PATH%;%NODE_PATH%"
set "NPM=%NODE_PATH%\npm.cmd"

echo [1/2] 正在配置 npm 镜像...
"%NPM%" config set registry https://registry.npmmirror.com
echo.

echo [2/2] 正在安装依赖（大约需要 1-2 分钟）...
if exist node_modules (
    rmdir /s /q node_modules
    echo   - 已删除旧 node_modules
)
if exist package-lock.json (
    del package-lock.json
    echo   - 已删除旧 package-lock.json
)

"%NPM%" install
if errorlevel 1 (
    echo.
    echo ❌ 安装失败！请检查网络连接。
    pause
    exit /b 1
)

echo.
echo ======================================
echo  ✅ 前端安装完成！
echo ======================================
echo.
echo 现在可以启动前端了：
echo    双击 frontend\start.bat  或运行 npm run dev
echo.
pause
