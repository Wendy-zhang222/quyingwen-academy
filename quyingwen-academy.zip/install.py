#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""趣英文学院 - 后端一键安装脚本"""

import os
import sys
import subprocess
import shutil
import time

# 获取项目路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), "backend")
FRONTEND_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), "frontend")
NODE_PATH = r"C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
NPM = os.path.join(NODE_PATH, "npm.cmd")
NPX = os.path.join(NODE_PATH, "npx.cmd")
NODE = os.path.join(NODE_PATH, "node.exe")

def run(cmd, cwd=None, timeout=300):
    """运行命令并实时输出"""
    print(f"\n>>> {cmd}")
    process = subprocess.Popen(
        cmd,
        cwd=cwd or BACKEND_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        shell=True,
        encoding="utf-8",
        errors="replace"
    )
    for line in process.stdout:
        print(line.rstrip())
    process.wait()
    if process.returncode != 0:
        print(f"\n❌ 命令失败: {cmd}")
        return False
    return True

def backend_install():
    """安装后端"""
    os.chdir(BACKEND_DIR)
    print("=" * 50)
    print("  趣英文学院 - 后端安装")
    print("=" * 50)
    print(f"\n📁 工作目录: {BACKEND_DIR}")
    print(f"📦 npm 路径: {NPM}")
    
    # 1. 设置镜像
    print("\n[1/5] 正在配置 npm 镜像...")
    if not run(f'"{NPM}" config set registry https://registry.npmmirror.com'):
        return False
    print("✅ 镜像已配置")
    
    # 2. 清理旧文件
    print("\n[2/5] 正在清理旧文件...")
    for item in ["node_modules", "package-lock.json", "academy.db"]:
        path = os.path.join(BACKEND_DIR, item)
        if os.path.exists(path):
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            else:
                os.remove(path)
            print(f"   - 已删除 {item}")
    print("✅ 清理完成")
    
    # 3. 安装依赖
    print("\n[3/5] 正在安装依赖（请等待 1-3 分钟）...")
    if not run(f'"{NPM}" install', timeout=300):
        return False
    print("✅ 依赖安装完成")
    
    # 4. 生成 Prisma Client
    print("\n[4/5] 正在生成 Prisma 客户端...")
    if not run(f'"{NPM}" run prisma:generate', timeout=120):
        return False
    print("✅ Prisma 客户端生成完成")
    
    # 5. 初始化数据库
    print("\n[5/5] 正在初始化数据库...")
    # 先创建 .env 文件
    env_path = os.path.join(BACKEND_DIR, ".env")
    with open(env_path, "w", encoding="utf-8") as f:
        f.write('DATABASE_URL="file:./dev.db"\n')
        f.write('JWT_SECRET="quyingwen-academy-secret-key-2024"\n')
        f.write('PORT=3001\n')
    print("   - 已创建 .env 配置文件")
    
    if not run(f'"{NPX}" prisma migrate dev --name init --accept-data-loss', timeout=120):
        return False
    print("✅ 数据库初始化完成")
    
    print("\n" + "=" * 50)
    print("  ✅ 后端安装完成！")
    print("=" * 50)
    print("\n现在可以启动后端了：")
    print(f"   双击 {os.path.join(BACKEND_DIR, 'start.bat')}")
    print("   或运行 npm start")
    return True

def frontend_install():
    """安装前端"""
    os.chdir(FRONTEND_DIR)
    print("\n" + "=" * 50)
    print("  趣英文学院 - 前端安装")
    print("=" * 50)
    print(f"\n📁 工作目录: {FRONTEND_DIR}")
    
    # 1. 设置镜像
    print("\n[1/2] 正在配置 npm 镜像...")
    if not run(f'"{NPM}" config set registry https://registry.npmmirror.com', cwd=FRONTEND_DIR):
        return False
    print("✅ 镜像已配置")
    
    # 2. 清理并安装
    print("\n[2/2] 正在安装依赖（请等待 1-3 分钟）...")
    for item in ["node_modules", "package-lock.json"]:
        path = os.path.join(FRONTEND_DIR, item)
        if os.path.exists(path):
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            else:
                os.remove(path)
            print(f"   - 已删除 {item}")
    
    if not run(f'"{NPM}" install', cwd=FRONTEND_DIR, timeout=300):
        return False
    print("✅ 依赖安装完成")
    
    print("\n" + "=" * 50)
    print("  ✅ 前端安装完成！")
    print("=" * 50)
    print("\n现在可以启动前端了：")
    print(f"   双击 {os.path.join(FRONTEND_DIR, 'start.bat')}")
    print("   或运行 npm run dev")
    return True

def start_backend():
    """启动后端"""
    print("\n🚀 正在启动后端服务器...")
    print("访问地址: http://localhost:3001")
    print("按 Ctrl+C 关闭服务器\n")
    os.chdir(BACKEND_DIR)
    try:
        subprocess.call(f'"{NPM}" start', shell=True)
    except KeyboardInterrupt:
        print("\n\n服务器已关闭。")

def start_frontend():
    """启动前端"""
    print("\n🚀 正在启动前端开发服务器...")
    print("访问地址: http://localhost:5173")
    print("按 Ctrl+C 关闭服务器\n")
    os.chdir(FRONTEND_DIR)
    try:
        subprocess.call(f'"{NPM}" run dev', shell=True)
    except KeyboardInterrupt:
        print("\n\n服务器已关闭。")

def main():
    """主菜单"""
    print("\n" + "=" * 50)
    print("  趣英文学院 - 一键安装工具")
    print("=" * 50)
    print("\n请选择操作：")
    print("  1. 安装后端（backend）")
    print("  2. 安装前端（frontend）")
    print("  3. 安装后端 + 前端（全部）")
    print("  4. 启动后端服务器")
    print("  5. 启动前端服务器")
    print("  6. 退出")
    
    choice = input("\n请输入数字 (1-6): ").strip()
    
    if choice == "1":
        backend_install()
    elif choice == "2":
        frontend_install()
    elif choice == "3":
        if backend_install():
            frontend_install()
    elif choice == "4":
        start_backend()
    elif choice == "5":
        start_frontend()
    elif choice == "6":
        print("\n再见！")
        return
    else:
        print("\n❌ 无效选择，请重新运行。")
    
    input("\n按回车键退出...")

if __name__ == "__main__":
    main()
