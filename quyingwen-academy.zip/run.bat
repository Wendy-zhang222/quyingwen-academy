@echo off
chcp 65001
python install.py
if errorlevel 1 (
    echo.
    echo Python 未安装，请安装 Python 后重试。
    pause
)
