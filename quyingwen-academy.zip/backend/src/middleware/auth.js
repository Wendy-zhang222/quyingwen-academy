const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET || 'quyingwen-academy-secret-key-2024'

function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: '未登录' })
  try {
    req.user = jwt.verify(token, JWT_SECRET)
    next()
  } catch {
    res.status(401).json({ error: '登录已过期' })
  }
}

function teacherOnly(req, res, next) {
  if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
    return res.status(403).json({ error: '无权限' })
  }
  next()
}

module.exports = { auth, teacherOnly }
