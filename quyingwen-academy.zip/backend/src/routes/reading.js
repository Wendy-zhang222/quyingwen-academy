const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth, teacherOnly } = require('../middleware/auth')

router.get('/', async (req, res) => {
  const articles = await prisma.readingArticle.findMany({
    orderBy: { createdAt: 'desc' }
  })
  res.json(articles)
})

router.get('/:id', async (req, res) => {
  const article = await prisma.readingArticle.findUnique({
    where: { id: parseInt(req.params.id) },
    include: { notes: { where: { userId: req.user?.id } } }
  })
  if (!article) return res.status(404).json({ error: '文章不存在' })
  res.json(article)
})

router.post('/', auth, teacherOnly, async (req, res) => {
  const { title, content, author, difficulty } = req.body
  const wordCount = content?.split(/\s+/).length || 0
  const article = await prisma.readingArticle.create({
    data: { title, content, author, difficulty: difficulty || 'beginner', wordCount, createdBy: req.user.id }
  })
  res.json({ success: true, id: article.id })
})

router.delete('/:id', auth, teacherOnly, async (req, res) => {
  const id = parseInt(req.params.id)
  await prisma.readingNote.deleteMany({ where: { articleId: id } })
  await prisma.readingArticle.delete({ where: { id } })
  res.json({ success: true })
})

module.exports = router
