const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth } = require('../middleware/auth')
const { checkAchievements } = require('../utils/achievements')

router.post('/:id/submit', auth, async (req, res) => {
  try {
    const { score, answers, time_spent } = req.body
    const userId = req.user.id
    const gameId = parseInt(req.params.id)

    await prisma.gameResult.create({
      data: {
        userId,
        gameId,
        score,
        answers: JSON.stringify(answers),
        timeSpent: time_spent || 0
      }
    })

    const game = await prisma.game.findUnique({ where: { id: gameId } })
    if (!game) return res.json({ success: true, score })

    // Recalc unit progress
    const results = await prisma.gameResult.findMany({
      where: { userId, game: { unitId: game.unitId } }
    })
    const totalScore = results.reduce((s, r) => s + (r.score || 0), 0)
    const maxScore = results.length * 100
    const pct = maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0
    const stars = pct >= 90 ? 3 : pct >= 70 ? 2 : pct >= 50 ? 1 : 0
    const status = pct >= 60 ? 'completed' : 'in_progress'

    await prisma.progress.upsert({
      where: { userId_unitId: { userId, unitId: game.unitId } },
      create: { userId, unitId: game.unitId, status, score: pct, stars, completedAt: status === 'completed' ? new Date() : null },
      update: { status, score: pct, stars, completedAt: status === 'completed' ? new Date() : null }
    })

    // Unlock next unit
    if (status === 'completed') {
      const unit = await prisma.unit.findUnique({ where: { id: game.unitId } })
      const nextUnit = await prisma.unit.findFirst({
        where: { courseId: unit.courseId, unitOrder: { gt: unit.unitOrder } },
        orderBy: { unitOrder: 'asc' }
      })
      if (nextUnit) {
        await prisma.progress.upsert({
          where: { userId_unitId: { userId, unitId: nextUnit.id } },
          create: { userId, unitId: nextUnit.id, status: 'unlocked' },
          update: { status: 'unlocked' }
        })
      }
    }

    const earnedBadges = await checkAchievements(userId)
    res.json({ success: true, score, earnedBadges })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

module.exports = router
