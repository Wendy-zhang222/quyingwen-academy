const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth } = require('../middleware/auth')

router.get('/', auth, async (req, res) => {
  const userId = req.user.id
  const homeworks = await prisma.homework.findMany({
    where: { status: 'published' },
    include: { unit: { select: { name: true } } },
    orderBy: { createdAt: 'desc' }
  })

  const submissions = await prisma.homeworkSubmission.findMany({
    where: { userId, homeworkId: { in: homeworks.map(h => h.id) } },
    select: { homeworkId: true, score: true, status: true, submittedAt: true }
  })
  const subMap = {}
  submissions.forEach(s => { subMap[s.homeworkId] = s })

  const now = new Date().toISOString()
  const result = homeworks.map(h => {
    const sub = subMap[h.id]
    let status = 'pending'
    if (sub) status = 'submitted'
    else if (h.dueDate && h.dueDate < now) status = 'overdue'
    return { ...h, studentStatus: status, score: sub?.score || null, submittedAt: sub?.submittedAt || null }
  })
  res.json(result)
})

router.get('/:id', auth, async (req, res) => {
  const userId = req.user.id
  const hwId = parseInt(req.params.id)
  const hw = await prisma.homework.findFirst({
    where: { id: hwId, status: 'published' },
    include: { unit: { select: { name: true } } }
  })
  if (!hw) return res.status(404).json({ error: '作业不存在' })

  const questions = await prisma.homeworkQuestion.findMany({
    where: { homeworkId: hwId },
    orderBy: { questionOrder: 'asc' }
  })
  const sub = await prisma.homeworkSubmission.findUnique({
    where: { userId_homeworkId: { userId, homeworkId: hwId } }
  })

  res.json({
    ...hw,
    questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) })),
    submission: sub ? { ...sub, answers: JSON.parse(sub.answers) } : null
  })
})

function autoGrade(question, userAnswer) {
  if (question.type === 'multiple_choice' || question.type === 'true_false') {
    return userAnswer === question.answer ? question.points : 0
  }
  if (question.type === 'multiple_answer') {
    const correct = question.answer.split(',').sort().join(',')
    const given = userAnswer.split(',').sort().join(',')
    return correct === given ? question.points : 0
  }
  if (question.type === 'fill_blank') {
    return userAnswer.trim().toLowerCase() === question.answer.trim().toLowerCase() ? question.points : 0
  }
  return null
}

router.post('/:id/submit', auth, async (req, res) => {
  try {
    const userId = req.user.id
    const hwId = parseInt(req.params.id)
    const { answers } = req.body
    if (!answers || typeof answers !== 'object') return res.status(400).json({ error: '缺少答案' })

    const existing = await prisma.homeworkSubmission.findUnique({
      where: { userId_homeworkId: { userId, homeworkId: hwId } }
    })
    if (existing) return res.status(400).json({ error: '已提交过此作业' })

    const questions = await prisma.homeworkQuestion.findMany({ where: { homeworkId: hwId } })
    let totalScore = 0
    let totalPoints = 0
    const gradedAnswers = {}
    const errors = []

    for (const q of questions) {
      const userAns = answers[q.id] || ''
      const score = autoGrade(q, userAns)
      totalPoints += q.points || 10
      if (score !== null) {
        totalScore += score
        gradedAnswers[q.id] = { answer: userAns, score, correct: score === q.points }
        if (score === 0) {
          errors.push({
            userId,
            questionId: q.id,
            homeworkId: hwId,
            questionData: q.data,
            userAnswer: userAns,
            correctAnswer: q.answer,
            explanation: q.explanation
          })
        }
      } else {
        gradedAnswers[q.id] = { answer: userAns, score: null, correct: null }
      }
    }

    const scorePct = totalPoints > 0 ? Math.round((totalScore / totalPoints) * 100) : 0

    await prisma.homeworkSubmission.create({
      data: {
        homeworkId: hwId,
        userId,
        score: scorePct,
        totalPoints,
        answers: JSON.stringify(gradedAnswers)
      }
    })

    for (const err of errors) {
      await prisma.errorBook.upsert({
        where: { userId_questionId: { userId: err.userId, questionId: err.questionId } },
        create: {
          userId: err.userId,
          questionId: err.questionId,
          homeworkId: err.homeworkId,
          questionData: err.questionData,
          userAnswer: err.userAnswer,
          correctAnswer: err.correctAnswer,
          explanation: err.explanation,
          timesWrong: 1
        },
        update: {
          timesWrong: { increment: 1 },
          lastWrongAt: new Date(),
          userAnswer: err.userAnswer,
          status: 'active'
        }
      })
    }

    const { checkAchievements } = require('../utils/achievements')
    const earnedBadges = await checkAchievements(userId)
    res.json({ success: true, score: scorePct, totalPoints, gradedAnswers, earnedBadges })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

router.get('/:id/result', auth, async (req, res) => {
  const userId = req.user.id
  const hwId = parseInt(req.params.id)
  const sub = await prisma.homeworkSubmission.findUnique({
    where: { userId_homeworkId: { userId, homeworkId: hwId } }
  })
  if (!sub) return res.status(404).json({ error: '未找到提交记录' })
  const questions = await prisma.homeworkQuestion.findMany({
    where: { homeworkId: hwId },
    orderBy: { questionOrder: 'asc' }
  })
  res.json({
    submission: { ...sub, answers: JSON.parse(sub.answers) },
    questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) }))
  })
})

module.exports = router
