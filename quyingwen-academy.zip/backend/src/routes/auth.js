const prisma = require('../prisma/client')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET || 'quyingwen-academy-secret-key-2024'

const express = require('express')
const router = express.Router()

router.post('/register', async (req, res) => {
  try {
    const { email, password, name, role = 'student' } = req.body
    if (!email || !password || !name) return res.status(400).json({ error: '缺少字段' })
    const hash = await bcrypt.hash(password, 10)
    const user = await prisma.user.create({
      data: { email, password: hash, name, role }
    })
    const token = jwt.sign({ id: user.id, email, role }, JWT_SECRET, { expiresIn: '7d' })
    res.json({ token, user: { id: user.id, email, name, role, avatar: user.avatar } })
  } catch (e) {
    res.status(400).json({ error: '邮箱已注册' })
  }
})

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body
    const user = await prisma.user.findUnique({ where: { email } })
    if (!user) return res.status(401).json({ error: '邮箱或密码错误' })
    const ok = await bcrypt.compare(password, user.password)
    if (!ok) return res.status(401).json({ error: '邮箱或密码错误' })
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' })
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role, avatar: user.avatar } })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

module.exports = router
