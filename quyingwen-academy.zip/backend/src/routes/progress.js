const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth } = require('../middleware/auth')

router.get('/', auth, async (req, res) => {
  const userId = req.user.id
  const progress = await prisma.progress.findMany({ where: { userId } })
  const results = await prisma.gameResult.findMany({ where: { userId } })
  const totalXP = results.reduce((s, r) => s + (r.score || 0) * 10, 0)
  const level = Math.floor(totalXP / 500) + 1
  res.json({ progress, totalXP, level })
})

router.get('/leaderboard', async (req, res) => {
  const rows = await prisma.user.findMany({
    where: { role: 'student' },
    include: { gameResults: { select: { score: true } } },
    take: 20
  })
  const result = rows.map(u => ({
    id: u.id,
    name: u.name,
    avatar: u.avatar,
    xp: u.gameResults.reduce((s, r) => s + (r.score || 0) * 10, 0)
  })).sort((a, b) => b.xp - a.xp)
  res.json(result)
})

module.exports = router
