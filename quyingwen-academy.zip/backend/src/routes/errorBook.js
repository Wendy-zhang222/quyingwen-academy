const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth } = require('../middleware/auth')

router.get('/', auth, async (req, res) => {
  const userId = req.user.id
  const rows = await prisma.errorBook.findMany({
    where: { userId, status: 'active' },
    orderBy: { lastWrongAt: 'desc' }
  })
  res.json(rows.map(r => ({ ...r, data: JSON.parse(r.questionData) })))
})

router.get('/stats', auth, async (req, res) => {
  const userId = req.user.id
  const total = await prisma.errorBook.count({ where: { userId } })
  const mastered = await prisma.errorBook.count({ where: { userId, status: 'mastered' } })
  const active = await prisma.errorBook.count({ where: { userId, status: 'active' } })
  res.json({ total, mastered, active })
})

router.post('/:id/master', auth, async (req, res) => {
  const userId = req.user.id
  const errorId = parseInt(req.params.id)
  await prisma.errorBook.updateMany({
    where: { id: errorId, userId },
    data: { status: 'mastered' }
  })
  res.json({ success: true })
})

module.exports = router
