const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth, teacherOnly } = require('../middleware/auth')

router.get('/books', async (req, res) => {
  const books = await prisma.vocabBook.findMany({
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { units: true } } }
  })
  res.json(books.map(b => ({ ...b, unit_count: b._count.units })))
})

router.get('/books/:id', async (req, res) => {
  const book = await prisma.vocabBook.findUnique({
    where: { id: parseInt(req.params.id) },
    include: {
      units: {
        orderBy: { unitOrder: 'asc' },
        include: { _count: { select: { words: true } } }
      }
    }
  })
  if (!book) return res.status(404).json({ error: '词书不存在' })
  res.json({ ...book, units: book.units.map(u => ({ ...u, word_count: u._count.words })) })
})

router.get('/units/:id/words', async (req, res) => {
  const words = await prisma.vocabWord.findMany({
    where: { unitId: parseInt(req.params.id) },
    orderBy: { createdAt: 'asc' }
  })
  res.json(words)
})

router.get('/my-entries', auth, async (req, res) => {
  const userId = req.user.id
  const entries = await prisma.vocabEntry.findMany({
    where: { userId },
    include: { word: true },
    orderBy: { nextReview: 'asc' }
  })
  res.json(entries)
})

router.get('/today-review', auth, async (req, res) => {
  const userId = req.user.id
  const now = new Date()
  const entries = await prisma.vocabEntry.findMany({
    where: { userId, nextReview: { lte: now } },
    include: { word: true },
    orderBy: { nextReview: 'asc' }
  })
  res.json(entries)
})

router.post('/books', auth, teacherOnly, async (req, res) => {
  const { title, description } = req.body
  const book = await prisma.vocabBook.create({
    data: { title, description, createdBy: req.user.id }
  })
  res.json({ success: true, id: book.id })
})

router.post('/books/:id/units', auth, teacherOnly, async (req, res) => {
  const { name, unitOrder } = req.body
  const unit = await prisma.vocabUnit.create({
    data: { bookId: parseInt(req.params.id), name, unitOrder: unitOrder || 0 }
  })
  res.json({ success: true, id: unit.id })
})

router.post('/units/:id/words', auth, teacherOnly, async (req, res) => {
  const { words } = req.body
  const created = await prisma.vocabWord.createMany({
    data: words.map(w => ({
      unitId: parseInt(req.params.id),
      word: w.word,
      phonetic: w.phonetic || null,
      meaning: w.meaning,
      example: w.example || null
    }))
  })
  res.json({ success: true, count: created.count })
})

module.exports = router
