const prisma = require('../prisma/client')
const express = require('express')
const { auth, teacherOnly } = require('../middleware/auth')
const router = express.Router()

function generateClassCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return code
}

router.get('/students', auth, teacherOnly, async (req, res) => {
  const students = await prisma.user.findMany({
    where: { role: 'student' },
    select: { id: true, name: true, email: true, avatar: true, classId: true }
  })
  res.json(students)
})

router.get('/student/:id/progress', auth, teacherOnly, async (req, res) => {
  const rows = await prisma.progress.findMany({
    where: { userId: parseInt(req.params.id) },
    include: { unit: { include: { course: { select: { name: true } } } } }
  })
  res.json(rows.map(r => ({
    ...r,
    unit_name: r.unit.name,
    course_name: r.unit.course.name
  })))
})

router.get('/stats', auth, teacherOnly, async (req, res) => {
  const totalStudents = await prisma.user.count({ where: { role: 'student' } })
  const totalCourses = await prisma.course.count()
  const totalCompleted = await prisma.progress.count({ where: { status: 'completed' } })
  res.json({ totalStudents, totalCourses, totalCompleted })
})

router.post('/unlock', auth, teacherOnly, async (req, res) => {
  const { studentId, unitId } = req.body
  await prisma.progress.upsert({
    where: { userId_unitId: { userId: studentId, unitId } },
    create: { userId: studentId, unitId, status: 'unlocked' },
    update: { status: 'unlocked' }
  })
  res.json({ success: true })
})

router.post('/classes', auth, teacherOnly, async (req, res) => {
  const { name } = req.body
  if (!name) return res.status(400).json({ error: '班级名称不能为空' })
  const code = generateClassCode()
  const cls = await prisma.class.create({
    data: { name, code, teacherId: req.user.id }
  })
  res.json({ success: true, id: cls.id, name, code })
})

router.get('/classes', auth, teacherOnly, async (req, res) => {
  const classes = await prisma.class.findMany({
    where: { teacherId: req.user.id },
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { students: true } } }
  })
  res.json(classes.map(c => ({ ...c, student_count: c._count.students })))
})

router.get('/classes/:id/students', auth, teacherOnly, async (req, res) => {
  const classId = parseInt(req.params.id)
  const cls = await prisma.class.findFirst({
    where: { id: classId, teacherId: req.user.id }
  })
  if (!cls) return res.status(403).json({ error: '无权访问此班级' })
  const students = await prisma.user.findMany({
    where: { classId, role: 'student' },
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, email: true, avatar: true, createdAt: true }
  })
  res.json({ class: cls, students })
})

router.post('/homeworks', auth, teacherOnly, async (req, res) => {
  const { title, description, unitId, dueDate } = req.body
  if (!title) return res.status(400).json({ error: '标题不能为空' })
  const hw = await prisma.homework.create({
    data: { title, description, unitId: unitId || null, dueDate: dueDate || null, createdBy: req.user.id }
  })
  res.json({ success: true, id: hw.id })
})

router.get('/homeworks', auth, teacherOnly, async (req, res) => {
  const homeworks = await prisma.homework.findMany({
    where: { createdBy: req.user.id },
    include: { unit: { select: { name: true } } },
    orderBy: { createdAt: 'desc' }
  })
  res.json(homeworks)
})

router.get('/homeworks/:id', auth, teacherOnly, async (req, res) => {
  const hwId = parseInt(req.params.id)
  const hw = await prisma.homework.findFirst({
    where: { id: hwId, createdBy: req.user.id },
    include: { unit: { select: { name: true } } }
  })
  if (!hw) return res.status(404).json({ error: '作业不存在' })
  const questions = await prisma.homeworkQuestion.findMany({
    where: { homeworkId: hwId },
    orderBy: { questionOrder: 'asc' }
  })
  const submissions = await prisma.homeworkSubmission.findMany({
    where: { homeworkId: hwId },
    include: { user: { select: { name: true, avatar: true } } },
    orderBy: { submittedAt: 'desc' }
  })
  res.json({ ...hw, questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) })), submissions })
})

router.post('/homeworks/:id/questions', auth, teacherOnly, async (req, res) => {
  const hwId = parseInt(req.params.id)
  const { type, data, answer, explanation, points, questionOrder } = req.body
  if (!type || !data) return res.status(400).json({ error: '缺少题目类型或内容' })
  const q = await prisma.homeworkQuestion.create({
    data: { homeworkId: hwId, type, data: JSON.stringify(data), answer: answer || null, explanation: explanation || null, points: points || 10, questionOrder: questionOrder || 0 }
  })
  res.json({ success: true, id: q.id })
})

router.patch('/homeworks/:id/status', auth, teacherOnly, async (req, res) => {
  const { status } = req.body
  await prisma.homework.updateMany({
    where: { id: parseInt(req.params.id), createdBy: req.user.id },
    data: { status }
  })
  res.json({ success: true })
})

router.delete('/homeworks/:id', auth, teacherOnly, async (req, res) => {
  const hwId = parseInt(req.params.id)
  await prisma.homeworkSubmission.deleteMany({ where: { homeworkId: hwId } })
  await prisma.homeworkQuestion.deleteMany({ where: { homeworkId: hwId } })
  await prisma.homework.deleteMany({ where: { id: hwId, createdBy: req.user.id } })
  res.json({ success: true })
})

module.exports = router
