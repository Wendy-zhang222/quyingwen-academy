const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth, teacherOnly } = require('../middleware/auth')

router.get('/', async (req, res) => {
  const materials = await prisma.listeningMaterial.findMany({
    orderBy: { createdAt: 'desc' }
  })
  res.json(materials)
})

router.get('/:id', async (req, res) => {
  const material = await prisma.listeningMaterial.findUnique({
    where: { id: parseInt(req.params.id) },
    include: {
      vocab: true,
      questions: { orderBy: { qOrder: 'asc' } }
    }
  })
  if (!material) return res.status(404).json({ error: '听力材料不存在' })
  res.json({
    ...material,
    questions: material.questions.map(q => ({ ...q, data: JSON.parse(q.data) }))
  })
})

router.post('/', auth, teacherOnly, async (req, res) => {
  const { title, description, audioUrl, transcript, difficulty } = req.body
  const material = await prisma.listeningMaterial.create({
    data: { title, description, audioUrl, transcript, difficulty: difficulty || 'beginner', createdBy: req.user.id }
  })
  res.json({ success: true, id: material.id })
})

router.delete('/:id', auth, teacherOnly, async (req, res) => {
  const id = parseInt(req.params.id)
  await prisma.listeningQuestion.deleteMany({ where: { materialId: id } })
  await prisma.listeningVocab.deleteMany({ where: { materialId: id } })
  await prisma.listeningSubmission.deleteMany({ where: { materialId: id } })
  await prisma.listeningMaterial.delete({ where: { id } })
  res.json({ success: true })
})

module.exports = router
