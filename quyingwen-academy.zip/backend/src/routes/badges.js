const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth } = require('../middleware/auth')

router.get('/', auth, async (req, res) => {
  const userId = req.user.id
  const rows = await prisma.badge.findMany({
    where: { userId },
    orderBy: { earnedAt: 'desc' }
  })
  res.json(rows)
})

router.get('/all', auth, async (req, res) => {
  const userId = req.user.id
  const allBadgeTypes = [
    { type: 'first_step', title: '迈出第一步', icon: '🚶', description: '完成了第一个单元', condition: '完成1个单元' },
    { type: 'explorer', title: '小小探险家', icon: '🔍', description: '完成了3个单元', condition: '完成3个单元' },
    { type: 'champion', title: '学习冠军', icon: '🏆', description: '完成了5个单元', condition: '完成5个单元' },
    { type: 'homework_first', title: '作业达人', icon: '✏️', description: '完成了第一份作业', condition: '完成1份作业' },
    { type: 'xp_1000', title: '千分达人', icon: '💎', description: '累计获得1000 XP', condition: '获得1000 XP' },
    { type: 'perfect_score', title: '满分王者', icon: '⭐', description: '作业获得满分', condition: '作业100分' },
    { type: 'error_master', title: '错题征服者', icon: '✅', description: '掌握10道错题', condition: '掌握10道错题' },
  ]
  const earned = await prisma.badge.findMany({
    where: { userId },
    select: { type: true }
  })
  const earnedSet = new Set(earned.map(e => e.type))
  res.json(allBadgeTypes.map(b => ({ ...b, earned: earnedSet.has(b.type) })))
})

module.exports = router
