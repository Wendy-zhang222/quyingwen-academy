const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()

router.get('/', async (req, res) => {
  const courses = await prisma.course.findMany({ orderBy: { courseOrder: 'asc' } })
  res.json(courses)
})

router.get('/:id/units', async (req, res) => {
  const units = await prisma.unit.findMany({
    where: { courseId: parseInt(req.params.id) },
    orderBy: { unitOrder: 'asc' }
  })
  res.json(units)
})

router.get('/units/:id', async (req, res) => {
  const unit = await prisma.unit.findUnique({ where: { id: parseInt(req.params.id) } })
  if (!unit) return res.status(404).json({ error: '单元不存在' })
  res.json(unit)
})

router.get('/units/:id/games', async (req, res) => {
  const games = await prisma.game.findMany({
    where: { unitId: parseInt(req.params.id) },
    orderBy: { gameOrder: 'asc' }
  })
  res.json(games.map(g => ({ ...g, data: JSON.parse(g.data) })))
})

module.exports = router
