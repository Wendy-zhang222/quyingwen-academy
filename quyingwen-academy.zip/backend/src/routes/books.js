const prisma = require('../prisma/client')
const express = require('express')
const router = express.Router()
const { auth, teacherOnly } = require('../middleware/auth')

router.get('/', async (req, res) => {
  const unitId = req.query.unitId ? parseInt(req.query.unitId) : undefined
  const books = await prisma.book.findMany({
    where: unitId ? { unitId } : {},
    include: {
      _count: { select: { pages: true, audios: true } }
    },
    orderBy: { createdAt: 'desc' }
  })
  res.json(books.map(b => ({ ...b, page_count: b._count.pages, audio_count: b._count.audios })))
})

router.get('/:id', async (req, res) => {
  const bookId = parseInt(req.params.id)
  const book = await prisma.book.findUnique({ where: { id: bookId } })
  if (!book) return res.status(404).json({ error: 'Book not found' })
  const pages = await prisma.bookPage.findMany({
    where: { bookId },
    orderBy: { pageNumber: 'asc' }
  })
  const audios = await prisma.bookAudio.findMany({
    where: { bookId },
    orderBy: { pageNumber: 'asc' }
  })
  res.json({ ...book, pages, audios })
})

router.post('/', auth, teacherOnly, async (req, res) => {
  const { title, description, unitId } = req.body
  const book = await prisma.book.create({
    data: { title, description, unitId: unitId || null, createdBy: req.user.id }
  })
  res.json({ success: true, id: book.id })
})

router.delete('/:id', auth, teacherOnly, async (req, res) => {
  const bookId = parseInt(req.params.id)
  await prisma.bookAudio.deleteMany({ where: { bookId } })
  await prisma.bookPage.deleteMany({ where: { bookId } })
  await prisma.book.delete({ where: { id: bookId } })
  res.json({ success: true })
})

module.exports = router
