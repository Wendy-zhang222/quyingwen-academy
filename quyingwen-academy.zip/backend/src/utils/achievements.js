function checkAchievements(userId) {
  return new Promise((resolve) => {
    const prisma = require('../prisma/client')
    const earnedBadges = []
    
    prisma.progress.count({
      where: { userId, status: 'completed' }
    }).then(async completed => {
      if (completed >= 1) {
        const has = await prisma.badge.findFirst({ where: { userId, type: 'first_step' } })
        if (!has) {
          await prisma.badge.create({
            data: { userId, type: 'first_step', title: '迈出第一步', icon: '🚶', description: '完成了第一个单元' }
          })
          earnedBadges.push({ type: 'first_step', title: '迈出第一步', icon: '🚶' })
        }
      }
      if (completed >= 3) {
        const has = await prisma.badge.findFirst({ where: { userId, type: 'explorer' } })
        if (!has) {
          await prisma.badge.create({
            data: { userId, type: 'explorer', title: '小小探险家', icon: '🔍', description: '完成了3个单元' }
          })
          earnedBadges.push({ type: 'explorer', title: '小小探险家', icon: '🔍' })
        }
      }
      if (completed >= 5) {
        const has = await prisma.badge.findFirst({ where: { userId, type: 'champion' } })
        if (!has) {
          await prisma.badge.create({
            data: { userId, type: 'champion', title: '学习冠军', icon: '🏆', description: '完成了5个单元' }
          })
          earnedBadges.push({ type: 'champion', title: '学习冠军', icon: '🏆' })
        }
      }
      
      const hwCount = await prisma.homeworkSubmission.count({ where: { userId } })
      if (hwCount >= 1) {
        const has = await prisma.badge.findFirst({ where: { userId, type: 'homework_first' } })
        if (!has) {
          await prisma.badge.create({
            data: { userId, type: 'homework_first', title: '作业达人', icon: '✏️', description: '完成了第一份作业' }
          })
          earnedBadges.push({ type: 'homework_first', title: '作业达人', icon: '✏️' })
        }
      }
      
      const totalXP = await prisma.gameResult.aggregate({
        where: { userId },
        _sum: { score: true }
      })
      if ((totalXP._sum.score || 0) * 10 >= 1000) {
        const has = await prisma.badge.findFirst({ where: { userId, type: 'xp_1000' } })
        if (!has) {
          await prisma.badge.create({
            data: { userId, type: 'xp_1000', title: '千分达人', icon: '💎', description: '累计获得1000 XP' }
          })
          earnedBadges.push({ type: 'xp_1000', title: '千分达人', icon: '💎' })
        }
      }
      
      resolve(earnedBadges)
    })
  })
}

module.exports = { checkAchievements }
