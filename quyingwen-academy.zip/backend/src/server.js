const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ── Multer File Upload ────────────────────────────────────
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const sub = path.join(uploadDir, file.fieldname === 'audio' ? 'audios' : 'images');
    if (!fs.existsSync(sub)) fs.mkdirSync(sub, { recursive: true });
    cb(null, sub);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + ext);
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

app.use('/uploads', express.static(uploadDir));

// ── Routes ───────────────────────────────────────────────
app.use('/api/auth', require('./routes/auth'))
app.use('/api/courses', require('./routes/courses'))
app.use('/api/games', require('./routes/games'))
app.use('/api/homeworks', require('./routes/homework'))
app.use('/api/progress', require('./routes/progress'))
app.use('/api/error-book', require('./routes/errorBook'))
app.use('/api/badges', require('./routes/badges'))
app.use('/api/books', require('./routes/books'))
app.use('/api/teacher', require('./routes/teacher'))
app.use('/api/listening', require('./routes/listening'))
app.use('/api/reading', require('./routes/reading'))
app.use('/api/vocab', require('./routes/vocab'))

// ── Additional Auth Routes (inline) ──────────────────────
const { auth, teacherOnly } = require('./middleware/auth')
const prisma = require('./prisma/client')

app.get('/api/me', auth, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: { id: true, email: true, name: true, role: true, avatar: true, classId: true }
  })
  if (!user) return res.status(404).json({ error: '用户不存在' })
  res.json(user)
})

app.post('/api/join-class', auth, async (req, res) => {
  const { code } = req.body
  if (!code) return res.status(400).json({ error: '班级码不能为空' })
  const cls = await prisma.class.findUnique({ where: { code: code.toUpperCase() } })
  if (!cls) return res.status(404).json({ error: '班级码不存在' })
  await prisma.user.update({ where: { id: req.user.id }, data: { classId: cls.id } })
  res.json({ success: true, classId: cls.id, className: cls.name })
})

app.get('/api/my-class', auth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id }, include: { class: true } })
  res.json(user.class || null)
})

// ── Book Upload Routes (with multer) ──────────────────────
app.post('/api/teacher/books/:id/pages', auth, teacherOnly, upload.array('pages', 50), async (req, res) => {
  const bookId = parseInt(req.params.id)
  const files = req.files
  if (!files || files.length === 0) return res.status(400).json({ error: 'No files uploaded' })
  const data = files.map((file, i) => ({
    bookId,
    pageNumber: i + 1,
    imagePath: '/uploads/images/' + path.basename(file.path)
  }))
  await prisma.bookPage.createMany({ data })
  res.json({ success: true, inserted: data.length })
})

app.post('/api/teacher/books/:id/audio', auth, teacherOnly, upload.single('audio'), async (req, res) => {
  const bookId = parseInt(req.params.id)
  const { pageNumber, startTime, endTime } = req.body
  if (!req.file) return res.status(400).json({ error: 'No audio uploaded' })
  const audioPath = '/uploads/audios/' + path.basename(req.file.path)
  const audio = await prisma.bookAudio.create({
    data: { bookId, pageNumber: parseInt(pageNumber) || 1, audioPath, startTime: parseFloat(startTime) || 0, endTime: parseFloat(endTime) || 0 }
  })
  res.json({ success: true, id: audio.id, path: audioPath })
})

// ── Seed Data ───────────────────────────────────────────
async function seedData() {
  const existing = await prisma.course.count()
  if (existing > 0) {
    console.log('✅ Data already exists, skipping seed.')
    return
  }
  console.log('🌱 Seeding data...')
  const bcrypt = require('bcryptjs')

  await prisma.course.createMany({
    data: [
      { name: '字母探险', level: 1, courseOrder: 1, description: 'Phonics 启蒙，从 A-Z 开始', icon: '🔤', color: '#EF4444', xpRequired: 0 },
      { name: '短词王国', level: 2, courseOrder: 2, description: 'CVC 词汇，简单发音规则', icon: '🏰', color: '#F59E0B', xpRequired: 500 },
      { name: '句子城堡', level: 3, courseOrder: 3, description: '简单句型与日常对话', icon: '🏛️', color: '#10B981', xpRequired: 1500 },
      { name: '故事森林', level: 4, courseOrder: 4, description: '分级阅读初阶', icon: '🌲', color: '#3B82F6', xpRequired: 3000 },
      { name: '章节海洋', level: 5, courseOrder: 5, description: '初章书阅读与理解', icon: '🌊', color: '#8B5CF6', xpRequired: 5000 },
      { name: '自由天空', level: 6, courseOrder: 6, description: '自主阅读与深度思考', icon: '☁️', color: '#EC4899', xpRequired: 8000 }
    ]
  })

  const units1 = [
    { name: 'A-M 字母家族', unitOrder: 1, introVideo: 'https://example.com/video/alphabet-am.mp4', explainVideo: 'https://example.com/video/explain-am.mp4', content: '学习 A 到 M 的字母名称和发音', courseId: 1 },
    { name: 'N-Z 字母家族', unitOrder: 2, introVideo: 'https://example.com/video/alphabet-nz.mp4', explainVideo: 'https://example.com/video/explain-nz.mp4', content: '学习 N 到 Z 的字母名称和发音', courseId: 1 },
    { name: '字母大冒险', unitOrder: 3, introVideo: 'https://example.com/video/alphabet-adventure.mp4', explainVideo: 'https://example.com/video/explain-adventure.mp4', content: '综合复习所有字母', courseId: 1 }
  ]
  for (const u of units1) await prisma.unit.create({ data: u })

  const units2 = [
    { name: 'Cat 家族: -at', unitOrder: 1, introVideo: 'https://example.com/video/cvc-at.mp4', explainVideo: 'https://example.com/video/explain-cvc-at.mp4', content: 'cat, bat, hat, rat, sat', courseId: 2 },
    { name: 'Dog 家族: -og', unitOrder: 2, introVideo: 'https://example.com/video/cvc-og.mp4', explainVideo: 'https://example.com/video/explain-cvc-og.mp4', content: 'dog, log, fog, hog, jog', courseId: 2 },
    { name: 'Sun 家族: -un', unitOrder: 3, introVideo: 'https://example.com/video/cvc-un.mp4', explainVideo: 'https://example.com/video/explain-cvc-un.mp4', content: 'sun, bun, run, fun, nun', courseId: 2 },
    { name: 'CVC 混合挑战', unitOrder: 4, introVideo: 'https://example.com/video/cvc-mix.mp4', explainVideo: 'https://example.com/video/explain-cvc-mix.mp4', content: '综合 CVC 词汇练习', courseId: 2 }
  ]
  for (const u of units2) await prisma.unit.create({ data: u })

  const games11 = [
    { type: 'listen_choose', title: '听音选字母', unitId: 1, data: JSON.stringify({ audio: 'a.mp3', options: ['A', 'B', 'C', 'D'], correct: 'A' }), points: 10, gameOrder: 1 },
    { type: 'word_match', title: '字母配对', unitId: 1, data: JSON.stringify({ pairs: [['A', 'Apple'], ['B', 'Ball'], ['C', 'Cat'], ['D', 'Dog']] }), points: 15, gameOrder: 2 },
    { type: 'letter_spell', title: '拼写大挑战', unitId: 1, data: JSON.stringify({ words: ['APPLE', 'BALL', 'CAT', 'DOG', 'EGG'], hints: ['A_P_E', 'B_L_', 'C_T', 'D_G', '_GG'] }), points: 20, gameOrder: 3 },
    { type: 'picture_sort', title: '字母顺序排排乐', unitId: 1, data: JSON.stringify({ items: ['A', 'C', 'B', 'E', 'D'], correct: ['A', 'B', 'C', 'D', 'E'] }), points: 15, gameOrder: 4 }
  ]
  for (const g of games11) await prisma.game.create({ data: g })

  const games21 = [
    { type: 'listen_choose', title: '听音选单词', unitId: 4, data: JSON.stringify({ audio: 'cat.mp3', options: ['cat', 'dog', 'bat', 'rat'], correct: 'cat' }), points: 10, gameOrder: 1 },
    { type: 'word_match', title: '图文配对', unitId: 4, data: JSON.stringify({ pairs: [['cat', '猫'], ['bat', '蝙蝠'], ['hat', '帽子'], ['rat', '老鼠']] }), points: 15, gameOrder: 2 },
    { type: 'letter_spell', title: '填空拼词', unitId: 4, data: JSON.stringify({ words: ['CAT', 'BAT', 'HAT', 'RAT', 'SAT'], hints: ['C_T', 'B_T', 'H_T', 'R_T', 'S_T'] }), points: 20, gameOrder: 3 },
    { type: 'true_false', title: '判断对错', unitId: 4, data: JSON.stringify({ questions: [{ q: 'cat 和 hat 有相同的结尾', a: true }, { q: 'bat 是水果', a: false }] }), points: 15, gameOrder: 4 },
    { type: 'word_puzzle', title: '单词拼图', unitId: 4, data: JSON.stringify({ words: ['CAT', 'HAT', 'RAT', 'BAT', 'SAT'] }), points: 20, gameOrder: 5 }
  ]
  for (const g of games21) await prisma.game.create({ data: g })

  const teacherHash = await bcrypt.hash('teacher123', 10)
  const studentHash = await bcrypt.hash('demo123', 10)
  await prisma.user.create({ data: { email: 'teacher@quyingwen.top', password: teacherHash, name: '曲老师', role: 'teacher' } })
  await prisma.user.create({ data: { email: 'student@demo.com', password: studentHash, name: '小明同学', role: 'student' } })

  await prisma.book.create({ data: { id: 1, title: '字母探险绘本', description: 'A-M 字母家族有声绘本，配合音频学习字母发音', unitId: 1, createdBy: 1 } })

  await prisma.homework.create({ data: { id: 1, title: '字母测验：A-M', description: '测试学生对 A-M 字母的掌握情况', unitId: 1, status: 'published', createdBy: 1 } })
  const sampleQuestions = [
    { type: 'multiple_choice', data: JSON.stringify({ question: '字母 "A" 的英文名称是？', options: ['A', 'B', 'C', 'D'] }), answer: 'A', explanation: 'A 的名称就是 "A"，发音 /eɪ/。', points: 10, questionOrder: 1, homeworkId: 1 },
    { type: 'multiple_choice', data: JSON.stringify({ question: '字母 "C" 在单词 "Cat" 中发什么音？', options: ['/k/', '/s/', '/tʃ/', '/ʃ/'] }), answer: '/k/', explanation: 'C 在 a, o, u 前通常发 /k/。', points: 10, questionOrder: 2, homeworkId: 1 },
    { type: 'fill_blank', data: JSON.stringify({ question: 'B __ ll （球）', hint: 'A-M 之间' }), answer: 'A', explanation: 'Ball 是球，B 后面是 A。', points: 15, questionOrder: 3, homeworkId: 1 },
    { type: 'true_false', data: JSON.stringify({ question: '字母 "E" 的名称是 /iː/。' }), answer: 'true', explanation: 'E 的名称就是 /iː/，正确。', points: 10, questionOrder: 4, homeworkId: 1 }
  ]
  for (const q of sampleQuestions) await prisma.homeworkQuestion.create({ data: q })

  console.log('✅ Seed completed.')
}

// ── Static File Serving (Frontend) ───────────────────────
const distDir = path.join(__dirname, '..', 'dist');
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(distDir, 'index.html'));
    }
  });
}

// ── Start Server ────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`)
  seedData()
})
