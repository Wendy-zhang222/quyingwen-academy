' 趣英文学院 - 后端安装脚本
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

NODE_PATH = "C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
NPM = NODE_PATH & "\npm.cmd"
NPX = NODE_PATH & "\npx.cmd"
BACKEND_DIR = fso.GetParentFolderName(WScript.ScriptFullName)

WshShell.CurrentDirectory = BACKEND_DIR

MsgBox "Backend installation will start. Click OK to continue.", 64, "Quyingwen Academy"

' Step 1: Set registry
result = WshShell.Run("""" & NPM & """ config set registry https://registry.npmmirror.com", 1, True)

' Step 2: Clean
If fso.FolderExists(BACKEND_DIR & "\node_modules") Then
    fso.DeleteFolder BACKEND_DIR & "\node_modules", True
End If
If fso.FileExists(BACKEND_DIR & "\package-lock.json") Then
    fso.DeleteFile BACKEND_DIR & "\package-lock.json", True
End If
If fso.FileExists(BACKEND_DIR & "\academy.db") Then
    fso.DeleteFile BACKEND_DIR & "\academy.db", True
End If

' Step 3: Install
MsgBox "Installing dependencies... Please wait 2-3 minutes.", 64, "Step 3/5"
result = WshShell.Run("""" & NPM & """ install", 1, True)
If result <> 0 Then
    MsgBox "npm install failed. Check your network.", 16, "Error"
    WScript.Quit
End If

' Step 4: Generate Prisma
MsgBox "Generating Prisma client...", 64, "Step 4/5"
result = WshShell.Run("""" & NPM & """ run prisma:generate", 1, True)
If result <> 0 Then
    MsgBox "Prisma generate failed.", 16, "Error"
    WScript.Quit
End If

' Step 5: Migrate
MsgBox "Initializing database...", 64, "Step 5/5"
result = WshShell.Run("""" & NPX & """ prisma migrate dev --name init --accept-data-loss", 1, True)
If result <> 0 Then
    MsgBox "Database migration failed.", 16, "Error"
    WScript.Quit
End If

MsgBox "Backend installed successfully!" & vbCrLf & vbCrLf & "Start backend by double-clicking start.bat", 64, "Done"
