@echo off
chcp 65001 >nul
cls
echo ======================================
echo  趣英文学院 - 后端启动脚本
echo ======================================
echo.

set "NODE_PATH=C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
set "PATH=%PATH%;%NODE_PATH%"
set "NPM=%NODE_PATH%\npm.cmd"

echo 正在启动后端服务器...
echo 访问地址：http://localhost:3001
echo 按 Ctrl+C 关闭服务器
echo.

"%NPM%" start

echo.
echo 服务器已关闭。
pause
