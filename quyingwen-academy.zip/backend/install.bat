@echo off

set "NODE_PATH=C:\Users\yuwen\AppData\Local\Programs\kimi-desktop\resources\resources\runtime"
set "PATH=%PATH%;%NODE_PATH%"
set "NPM=%NODE_PATH%\npm.cmd"
set "NPX=%NODE_PATH%\npx.cmd"

echo [1/5] Setting npm registry...
"%NPM%" config set registry https://registry.npmmirror.com

echo [2/5] Cleaning old files...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del package-lock.json
if exist academy.db del academy.db

echo [3/5] Installing dependencies...
"%NPM%" install
if errorlevel 1 (
    echo ERROR: npm install failed
    pause
    exit /b 1
)

echo [4/5] Generating Prisma client...
"%NPM%" run prisma:generate
if errorlevel 1 (
    echo ERROR: prisma generate failed
    pause
    exit /b 1
)

echo [5/5] Initializing database...
"%NPX%" prisma migrate dev --name init --accept-data-loss
if errorlevel 1 (
    echo ERROR: prisma migrate failed
    pause
    exit /b 1
)

echo.
echo ======================================
echo Backend installed successfully!
echo ======================================
echo.
echo Start backend:
echo   double-click start.bat
echo.
pause
