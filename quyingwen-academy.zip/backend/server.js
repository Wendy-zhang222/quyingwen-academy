const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'quyingwen-academy-secret-key-2024';

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ── Multer File Upload ────────────────────────────────────
const multer = require('multer');
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const sub = path.join(uploadDir, file.fieldname === 'audio' ? 'audios' : 'images');
    if (!fs.existsSync(sub)) fs.mkdirSync(sub, { recursive: true });
    cb(null, sub);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + ext);
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// Static file serving for uploads
app.use('/uploads', express.static(uploadDir));

// ── Database ──────────────────────────────────────────────
const DB_PATH = path.join(__dirname, 'academy.db');
const db = new sqlite3.Database(DB_PATH);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'student',
    avatar TEXT DEFAULT '🎓',
    class_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    teacher_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    level INTEGER NOT NULL,
    course_order INTEGER NOT NULL,
    description TEXT,
    icon TEXT DEFAULT '📚',
    color TEXT DEFAULT '#3B82F6',
    xp_required INTEGER DEFAULT 0
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    unit_order INTEGER NOT NULL,
    intro_video TEXT,
    explain_video TEXT,
    content TEXT,
    unlock_requirement TEXT DEFAULT 'prev_completed'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unit_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    data TEXT NOT NULL,
    points INTEGER DEFAULT 10,
    game_order INTEGER NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    unit_id INTEGER NOT NULL,
    status TEXT DEFAULT 'locked',
    score INTEGER DEFAULT 0,
    stars INTEGER DEFAULT 0,
    completed_at DATETIME,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, unit_id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS game_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    game_id INTEGER NOT NULL,
    score INTEGER DEFAULT 0,
    answers TEXT,
    time_spent INTEGER DEFAULT 0,
    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    earned_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // ── Books / Picture Book tables ─────────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    cover TEXT,
    unit_id INTEGER,
    created_by INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS book_pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    page_number INTEGER NOT NULL,
    image_path TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS book_audios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    page_number INTEGER NOT NULL,
    audio_path TEXT NOT NULL,
    start_time REAL DEFAULT 0,
    end_time REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // ── Homework / Assignment System ───────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS homeworks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    unit_id INTEGER,
    due_date DATETIME,
    created_by INTEGER,
    status TEXT DEFAULT 'draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS homework_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    homework_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    data TEXT NOT NULL,
    answer TEXT,
    explanation TEXT,
    points INTEGER DEFAULT 10,
    question_order INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS homework_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    homework_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    score INTEGER DEFAULT 0,
    total_points INTEGER DEFAULT 0,
    status TEXT DEFAULT 'submitted',
    answers TEXT NOT NULL,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS error_books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    homework_id INTEGER,
    question_data TEXT,
    user_answer TEXT,
    correct_answer TEXT,
    explanation TEXT,
    times_wrong INTEGER DEFAULT 1,
    last_wrong_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'active',
    UNIQUE(user_id, question_id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS badges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    icon TEXT DEFAULT '🏅',
    description TEXT,
    earned_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// ── Auth Middleware ─────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: '未登录' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: '登录已过期' });
  }
}

function teacherOnly(req, res, next) {
  if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
    return res.status(403).json({ error: '无权限' });
  }
  next();
}

// ── Auth Routes ────────────────────────────────────────────
app.post('/api/register', async (req, res) => {
  const { email, password, name, role = 'student' } = req.body;
  if (!email || !password || !name) return res.status(400).json({ error: '缺少字段' });
  const hash = await bcrypt.hash(password, 10);
  db.run('INSERT INTO users (email, password, name, role) VALUES (?,?,?,?)',
    [email, hash, name, role], function(err) {
      if (err) return res.status(400).json({ error: '邮箱已注册' });
      const token = jwt.sign({ id: this.lastID, email, role }, JWT_SECRET, { expiresIn: '7d' });
      res.json({ token, user: { id: this.lastID, email, name, role, avatar: '🎓' } });
    });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err || !user) return res.status(401).json({ error: '邮箱或密码错误' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ error: '邮箱或密码错误' });
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role, avatar: user.avatar } });
  });
});

app.get('/api/me', auth, (req, res) => {
  db.get('SELECT id, email, name, role, avatar, class_id FROM users WHERE id = ?', [req.user.id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: '用户不存在' });
    res.json(row);
  });
});

// ── Course & Unit Routes ───────────────────────────────────
app.get('/api/courses', (req, res) => {
  db.all('SELECT * FROM courses ORDER BY course_order', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/courses/:id/units', (req, res) => {
  db.all('SELECT * FROM units WHERE course_id = ? ORDER BY unit_order', [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/units/:id', (req, res) => {
  db.get('SELECT * FROM units WHERE id = ?', [req.params.id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: '单元不存在' });
    res.json(row);
  });
});

app.get('/api/units/:id/games', (req, res) => {
  db.all('SELECT * FROM games WHERE unit_id = ? ORDER BY game_order', [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows.map(r => ({ ...r, data: JSON.parse(r.data) })));
  });
});

// ── Game Submission ───────────────────────────────────────
app.post('/api/games/:id/submit', auth, (req, res) => {
  const { score, answers, time_spent } = req.body;
  const userId = req.user.id;
  const gameId = req.params.id;

  db.run('INSERT INTO game_results (user_id, game_id, score, answers, time_spent) VALUES (?,?,?,?,?)',
    [userId, gameId, score, JSON.stringify(answers), time_spent], function(err) {
      if (err) return res.status(500).json({ error: err.message });

      // Update progress
      db.get('SELECT unit_id FROM games WHERE id = ?', [gameId], (err, game) => {
        if (!game) return res.json({ success: true });
        recalcUnitProgress(userId, game.unit_id, () => res.json({ success: true, score }));
      });
    });
});

function recalcUnitProgress(userId, unitId, cb) {
  db.all('SELECT score FROM game_results WHERE user_id = ? AND game_id IN (SELECT id FROM games WHERE unit_id = ?)', [userId, unitId], (err, results) => {
    if (err) return cb();
    const totalScore = results.reduce((s, r) => s + (r.score || 0), 0);
    const maxScore = results.length * 100;
    const pct = maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0;
    const stars = pct >= 90 ? 3 : pct >= 70 ? 2 : pct >= 50 ? 1 : 0;
    const status = pct >= 60 ? 'completed' : 'in_progress';

    db.run(`INSERT INTO progress (user_id, unit_id, status, score, stars, completed_at)
      VALUES (?,?,?,?,?,?)
      ON CONFLICT(user_id, unit_id) DO UPDATE SET
      status=excluded.status, score=excluded.score, stars=excluded.stars,
      completed_at=excluded.completed_at, updated_at=CURRENT_TIMESTAMP`,
      [userId, unitId, status, pct, stars, status === 'completed' ? new Date().toISOString() : null],
      () => {
        // Unlock next unit
        if (status === 'completed') unlockNextUnit(userId, unitId, cb);
        else cb();
      });
  });
}

function unlockNextUnit(userId, unitId, cb) {
  db.get('SELECT course_id, unit_order FROM units WHERE id = ?', [unitId], (err, unit) => {
    if (!unit) return cb();
    db.get('SELECT id FROM units WHERE course_id = ? AND unit_order > ? ORDER BY unit_order LIMIT 1', [unit.course_id, unit.unit_order], (err, next) => {
      if (!next) return cb();
      db.run(`INSERT INTO progress (user_id, unit_id, status) VALUES (?,?,?)
        ON CONFLICT(user_id, unit_id) DO UPDATE SET status='unlocked'`,
        [userId, next.id, 'unlocked'], () => cb());
    });
  });
}

// ── Progress Routes ───────────────────────────────────────
app.get('/api/progress', auth, (req, res) => {
  const userId = req.user.id;
  db.all('SELECT * FROM progress WHERE user_id = ?', [userId], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });

    // Calculate total XP
    db.all('SELECT score FROM game_results WHERE user_id = ?', [userId], (err2, results) => {
      const totalXP = results.reduce((s, r) => s + (r.score || 0) * 10, 0);
      const level = Math.floor(totalXP / 500) + 1;
      res.json({ progress: rows, totalXP, level });
    });
  });
});

app.get('/api/leaderboard', (req, res) => {
  db.all(`SELECT u.id, u.name, u.avatar, SUM(gr.score) * 10 as xp
    FROM users u JOIN game_results gr ON u.id = gr.user_id
    WHERE u.role = 'student'
    GROUP BY u.id ORDER BY xp DESC LIMIT 20`, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// ── Teacher Routes ──────────────────────────────────────────
app.get('/api/teacher/students', auth, teacherOnly, (req, res) => {
  db.all('SELECT id, name, email, avatar, class_id FROM users WHERE role = ?', ['student'], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/teacher/student/:id/progress', auth, teacherOnly, (req, res) => {
  const studentId = req.params.id;
  db.all('SELECT p.*, u.name as unit_name, c.name as course_name FROM progress p JOIN units u ON p.unit_id = u.id JOIN courses c ON u.course_id = c.id WHERE p.user_id = ?', [studentId], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/teacher/stats', auth, teacherOnly, (req, res) => {
  db.get('SELECT COUNT(*) as total_students FROM users WHERE role = "student"', (err, students) => {
    db.get('SELECT COUNT(*) as total_courses FROM courses', (err2, courses) => {
      db.get('SELECT COUNT(*) as total_completed FROM progress WHERE status = "completed"', (err3, completed) => {
        res.json({
          totalStudents: students?.total_students || 0,
          totalCourses: courses?.total_courses || 0,
          totalCompleted: completed?.total_completed || 0
        });
      });
    });
  });
});

app.post('/api/teacher/unlock', auth, teacherOnly, (req, res) => {
  const { studentId, unitId } = req.body;
  db.run(`INSERT INTO progress (user_id, unit_id, status) VALUES (?,?,?)
    ON CONFLICT(user_id, unit_id) DO UPDATE SET status='unlocked'`,
    [studentId, unitId, 'unlocked'], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
    });
});

// ── Class Management Routes ────────────────────────────────
function generateClassCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

app.post('/api/teacher/classes', auth, teacherOnly, (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: '班级名称不能为空' });
  const code = generateClassCode();
  db.run('INSERT INTO classes (name, code, teacher_id) VALUES (?,?,?)',
    [name, code, req.user.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID, name, code });
    });
});

app.get('/api/teacher/classes', auth, teacherOnly, (req, res) => {
  db.all('SELECT c.*, (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = "student") as student_count FROM classes c WHERE c.teacher_id = ? ORDER BY c.created_at DESC',
    [req.user.id], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
});

app.get('/api/teacher/classes/:id/students', auth, teacherOnly, (req, res) => {
  const classId = req.params.id;
  db.get('SELECT * FROM classes WHERE id = ? AND teacher_id = ?', [classId, req.user.id], (err, cls) => {
    if (err || !cls) return res.status(403).json({ error: '无权访问此班级' });
    db.all('SELECT id, name, email, avatar, created_at FROM users WHERE class_id = ? AND role = "student" ORDER BY created_at DESC',
      [classId], (err2, rows) => {
        if (err2) return res.status(500).json({ error: err2.message });
        res.json({ class: cls, students: rows });
      });
  });
});

app.post('/api/join-class', auth, (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: '班级码不能为空' });
  db.get('SELECT id, name FROM classes WHERE code = ?', [code.toUpperCase()], (err, cls) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!cls) return res.status(404).json({ error: '班级码不存在' });
    db.run('UPDATE users SET class_id = ? WHERE id = ?', [cls.id, req.user.id], (err2) => {
      if (err2) return res.status(500).json({ error: err2.message });
      res.json({ success: true, classId: cls.id, className: cls.name });
    });
  });
});

app.get('/api/my-class', auth, (req, res) => {
  db.get('SELECT c.* FROM classes c JOIN users u ON c.id = u.class_id WHERE u.id = ?', [req.user.id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(row || null);
  });
});

// ── Book / Picture Book Routes ─────────────────────────────
app.post('/api/teacher/books/:id/pages', auth, teacherOnly, upload.array('pages', 50), (req, res) => {
  const bookId = req.params.id;
  const files = req.files;
  if (!files || files.length === 0) return res.status(400).json({ error: 'No files uploaded' });

  let inserted = 0;
  files.forEach((file, i) => {
    const pagePath = '/uploads/images/' + path.basename(file.path);
    db.run('INSERT INTO book_pages (book_id, page_number, image_path) VALUES (?,?,?)',
      [bookId, i + 1, pagePath], (err) => {
        if (!err) inserted++;
        if (i === files.length - 1) res.json({ success: true, inserted });
      });
  });
});

app.post('/api/teacher/books/:id/audio', auth, teacherOnly, upload.single('audio'), (req, res) => {
  const bookId = req.params.id;
  const { pageNumber, startTime, endTime } = req.body;
  if (!req.file) return res.status(400).json({ error: 'No audio uploaded' });

  const audioPath = '/uploads/audios/' + path.basename(req.file.path);
  db.run('INSERT INTO book_audios (book_id, page_number, audio_path, start_time, end_time) VALUES (?,?,?,?,?)',
    [bookId, pageNumber || 1, audioPath, startTime || 0, endTime || 0], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID, path: audioPath });
    });
});

app.post('/api/teacher/books', auth, teacherOnly, (req, res) => {
  const { title, description, unitId } = req.body;
  db.run('INSERT INTO books (title, description, unit_id, created_by) VALUES (?,?,?,?)',
    [title, description, unitId || null, req.user.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID });
    });
});

app.get('/api/books', (req, res) => {
  const unitId = req.query.unitId;
  let sql = `SELECT b.*,
    (SELECT COUNT(*) FROM book_pages WHERE book_id = b.id) as page_count,
    (SELECT COUNT(*) FROM book_audios WHERE book_id = b.id) as audio_count
    FROM books b`;
  let params = [];
  if (unitId) {
    sql += ' WHERE b.unit_id = ?';
    params.push(unitId);
  }
  sql += ' ORDER BY b.created_at DESC';
  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/books/:id', (req, res) => {
  const bookId = req.params.id;
  db.get('SELECT * FROM books WHERE id = ?', [bookId], (err, book) => {
    if (err || !book) return res.status(404).json({ error: 'Book not found' });
    db.all('SELECT * FROM book_pages WHERE book_id = ? ORDER BY page_number', [bookId], (err2, pages) => {
      db.all('SELECT * FROM book_audios WHERE book_id = ? ORDER BY page_number', [bookId], (err3, audios) => {
        res.json({ ...book, pages, audios });
      });
    });
  });
});

app.delete('/api/teacher/books/:id', auth, teacherOnly, (req, res) => {
  const bookId = req.params.id;
  db.run('DELETE FROM book_audios WHERE book_id = ?', [bookId], () => {
    db.run('DELETE FROM book_pages WHERE book_id = ?', [bookId], () => {
      db.run('DELETE FROM books WHERE id = ?', [bookId], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
      });
    });
  });
});

// ════════════════════════════════════════════════════════════
//  EXTENSIONS: Homework, Error Book, Badges
// ════════════════════════════════════════════════════════════

// ── Homework Management (Teacher) ─────────────────────────
app.post('/api/teacher/homeworks', auth, teacherOnly, (req, res) => {
  const { title, description, unitId, dueDate } = req.body;
  if (!title) return res.status(400).json({ error: '标题不能为空' });
  db.run('INSERT INTO homeworks (title, description, unit_id, due_date, created_by) VALUES (?,?,?,?,?)',
    [title, description, unitId || null, dueDate || null, req.user.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID });
    });
});

app.get('/api/teacher/homeworks', auth, teacherOnly, (req, res) => {
  db.all('SELECT h.*, u.name as unit_name FROM homeworks h LEFT JOIN units u ON h.unit_id = u.id WHERE h.created_by = ? ORDER BY h.created_at DESC',
    [req.user.id], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
});

app.get('/api/teacher/homeworks/:id', auth, teacherOnly, (req, res) => {
  const hwId = req.params.id;
  db.get('SELECT h.*, u.name as unit_name FROM homeworks h LEFT JOIN units u ON h.unit_id = u.id WHERE h.id = ? AND h.created_by = ?',
    [hwId, req.user.id], (err, hw) => {
      if (err || !hw) return res.status(404).json({ error: '作业不存在' });
      db.all('SELECT * FROM homework_questions WHERE homework_id = ? ORDER BY question_order', [hwId], (err2, questions) => {
        db.all('SELECT s.*, u.name as student_name, u.avatar FROM homework_submissions s JOIN users u ON s.user_id = u.id WHERE s.homework_id = ? ORDER BY s.submitted_at DESC', [hwId], (err3, submissions) => {
          res.json({ ...hw, questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) })), submissions });
        });
      });
    });
});

app.post('/api/teacher/homeworks/:id/questions', auth, teacherOnly, (req, res) => {
  const hwId = req.params.id;
  const { type, data, answer, explanation, points, questionOrder } = req.body;
  if (!type || !data) return res.status(400).json({ error: '缺少题目类型或内容' });
  db.run('INSERT INTO homework_questions (homework_id, type, data, answer, explanation, points, question_order) VALUES (?,?,?,?,?,?,?)',
    [hwId, type, JSON.stringify(data), answer || null, explanation || null, points || 10, questionOrder || 0], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID });
    });
});

app.patch('/api/teacher/homeworks/:id/status', auth, teacherOnly, (req, res) => {
  const { status } = req.body;
  db.run('UPDATE homeworks SET status = ? WHERE id = ? AND created_by = ?', [status, req.params.id, req.user.id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.delete('/api/teacher/homeworks/:id', auth, teacherOnly, (req, res) => {
  const hwId = req.params.id;
  db.run('DELETE FROM homework_submissions WHERE homework_id = ?', [hwId], () => {
    db.run('DELETE FROM homework_questions WHERE homework_id = ?', [hwId], () => {
      db.run('DELETE FROM homeworks WHERE id = ? AND created_by = ?', [hwId, req.user.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
      });
    });
  });
});

// ── Homework Submission (Student) ───────────────────────────
function autoGrade(question, userAnswer) {
  if (question.type === 'multiple_choice' || question.type === 'true_false') {
    return userAnswer === question.answer ? question.points : 0;
  }
  if (question.type === 'multiple_answer') {
    const correct = question.answer.split(',').sort().join(',');
    const given = userAnswer.split(',').sort().join(',');
    return correct === given ? question.points : 0;
  }
  if (question.type === 'fill_blank') {
    return userAnswer.trim().toLowerCase() === question.answer.trim().toLowerCase() ? question.points : 0;
  }
  // short_answer requires manual grading
  return null;
}

function checkAchievements(userId, cb) {
  const earnedBadges = [];
  
  // Check completed units count
  db.get('SELECT COUNT(*) as count FROM progress WHERE user_id = ? AND status = "completed"', [userId], (err, row) => {
    const completed = row?.count || 0;
    
    // Badge: First Step (1 unit)
    if (completed >= 1) {
      db.get('SELECT id FROM badges WHERE user_id = ? AND type = "first_step"', [userId], (err2, has) => {
        if (!has) {
          db.run('INSERT INTO badges (user_id, type, title, icon, description) VALUES (?,?,?,?,?)',
            [userId, 'first_step', '迈出第一步', '🚶', '完成了第一个单元']);
          earnedBadges.push({ type: 'first_step', title: '迈出第一步', icon: '🚶' });
        }
      });
    }
    
    // Badge: Explorer (3 units)
    if (completed >= 3) {
      db.get('SELECT id FROM badges WHERE user_id = ? AND type = "explorer"', [userId], (err2, has) => {
        if (!has) {
          db.run('INSERT INTO badges (user_id, type, title, icon, description) VALUES (?,?,?,?,?)',
            [userId, 'explorer', '小小探险家', '🔍', '完成了3个单元']);
          earnedBadges.push({ type: 'explorer', title: '小小探险家', icon: '🔍' });
        }
      });
    }
    
    // Badge: Champion (5 units)
    if (completed >= 5) {
      db.get('SELECT id FROM badges WHERE user_id = ? AND type = "champion"', [userId], (err2, has) => {
        if (!has) {
          db.run('INSERT INTO badges (user_id, type, title, icon, description) VALUES (?,?,?,?,?)',
            [userId, 'champion', '学习冠军', '🏆', '完成了5个单元']);
          earnedBadges.push({ type: 'champion', title: '学习冠军', icon: '🏆' });
        }
      });
    }
    
    // Check homework submissions
    db.get('SELECT COUNT(*) as count FROM homework_submissions WHERE user_id = ?', [userId], (err3, hwRow) => {
      const hwCount = hwRow?.count || 0;
      if (hwCount >= 1) {
        db.get('SELECT id FROM badges WHERE user_id = ? AND type = "homework_first"', [userId], (err4, has) => {
          if (!has) {
            db.run('INSERT INTO badges (user_id, type, title, icon, description) VALUES (?,?,?,?,?)',
              [userId, 'homework_first', '作业达人', '✏️', '完成了第一份作业']);
            earnedBadges.push({ type: 'homework_first', title: '作业达人', icon: '✏️' });
          }
        });
      }
      
      // Check total XP
      db.get('SELECT SUM(score) * 10 as total FROM game_results WHERE user_id = ?', [userId], (err4, xpRow) => {
        const totalXP = xpRow?.total || 0;
        if (totalXP >= 1000) {
          db.get('SELECT id FROM badges WHERE user_id = ? AND type = "xp_1000"', [userId], (err5, has) => {
            if (!has) {
              db.run('INSERT INTO badges (user_id, type, title, icon, description) VALUES (?,?,?,?,?)',
                [userId, 'xp_1000', '千分达人', '💎', '累计获得1000 XP']);
              earnedBadges.push({ type: 'xp_1000', title: '千分达人', icon: '💎' });
            }
          });
        }
        
        setTimeout(() => cb(earnedBadges), 100);
      });
    });
  });
}

app.get('/api/homeworks', auth, (req, res) => {
  const userId = req.user.id;
  db.all('SELECT h.*, u.name as unit_name FROM homeworks h LEFT JOIN units u ON h.unit_id = u.id WHERE h.status = "published" ORDER BY h.created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    
    // Check which ones this student has submitted
    const homeworkIds = rows.map(r => r.id);
    if (homeworkIds.length === 0) return res.json([]);
    
    const placeholders = homeworkIds.map(() => '?').join(',');
    db.all(`SELECT homework_id, score, status, submitted_at FROM homework_submissions WHERE user_id = ? AND homework_id IN (${placeholders})`,
      [userId, ...homeworkIds], (err2, subs) => {
        const subMap = {};
        subs.forEach(s => { subMap[s.homework_id] = s; });
        
        const now = new Date().toISOString();
        const result = rows.map(h => {
          const sub = subMap[h.id];
          let status = 'pending';
          if (sub) status = 'submitted';
          else if (h.due_date && h.due_date < now) status = 'overdue';
          
          return { ...h, studentStatus: status, score: sub?.score || null, submittedAt: sub?.submitted_at || null };
        });
        res.json(result);
      });
  });
});

app.get('/api/homeworks/:id', auth, (req, res) => {
  const userId = req.user.id;
  const hwId = req.params.id;
  db.get('SELECT h.*, u.name as unit_name FROM homeworks h LEFT JOIN units u ON h.unit_id = u.id WHERE h.id = ? AND h.status = "published"', [hwId], (err, hw) => {
    if (err || !hw) return res.status(404).json({ error: '作业不存在' });
    db.all('SELECT * FROM homework_questions WHERE homework_id = ? ORDER BY question_order', [hwId], (err2, questions) => {
      db.get('SELECT * FROM homework_submissions WHERE homework_id = ? AND user_id = ?', [hwId, userId], (err3, sub) => {
        res.json({
          ...hw,
          questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) })),
          submission: sub ? { ...sub, answers: JSON.parse(sub.answers) } : null
        });
      });
    });
  });
});

app.post('/api/homeworks/:id/submit', auth, (req, res) => {
  const userId = req.user.id;
  const hwId = req.params.id;
  const { answers } = req.body; // { questionId: answer }
  
  if (!answers || typeof answers !== 'object') return res.status(400).json({ error: '缺少答案' });
  
  // Check if already submitted
  db.get('SELECT id FROM homework_submissions WHERE homework_id = ? AND user_id = ?', [hwId, userId], (err, existing) => {
    if (existing) return res.status(400).json({ error: '已提交过此作业' });
    
    db.all('SELECT * FROM homework_questions WHERE homework_id = ?', [hwId], (err2, questions) => {
      if (err2) return res.status(500).json({ error: err2.message });
      
      let totalScore = 0;
      let totalPoints = 0;
      const gradedAnswers = {};
      const errors = [];
      
      questions.forEach(q => {
        const userAns = answers[q.id] || '';
        const score = autoGrade(q, userAns);
        totalPoints += q.points || 10;
        
        if (score !== null) {
          totalScore += score;
          gradedAnswers[q.id] = { answer: userAns, score, correct: score === q.points };
          
          if (score === 0) {
            errors.push({
              userId,
              questionId: q.id,
              homeworkId: hwId,
              questionData: q.data,
              userAnswer: userAns,
              correctAnswer: q.answer,
              explanation: q.explanation
            });
          }
        } else {
          // short_answer needs manual grading
          gradedAnswers[q.id] = { answer: userAns, score: null, correct: null };
        }
      });
      
      const scorePct = totalPoints > 0 ? Math.round((totalScore / totalPoints) * 100) : 0;
      
      db.run('INSERT INTO homework_submissions (homework_id, user_id, score, total_points, answers) VALUES (?,?,?,?,?)',
        [hwId, userId, scorePct, totalPoints, JSON.stringify(gradedAnswers)], function(err3) {
          if (err3) return res.status(500).json({ error: err3.message });
          
          // Save errors to error book
          errors.forEach(err => {
            db.run(`INSERT INTO error_books (user_id, question_id, homework_id, question_data, user_answer, correct_answer, explanation, times_wrong, last_wrong_at)
              VALUES (?,?,?,?,?,?,?,1,datetime('now'))
              ON CONFLICT(user_id, question_id) DO UPDATE SET
              times_wrong = times_wrong + 1,
              last_wrong_at = datetime('now'),
              user_answer = excluded.user_answer,
              status = 'active'`,
              [err.userId, err.questionId, err.homeworkId, err.questionData, err.userAnswer, err.correctAnswer, err.explanation]);
          });
          
          // Check achievements
          checkAchievements(userId, (earnedBadges) => {
            res.json({ success: true, score: scorePct, totalPoints, gradedAnswers, earnedBadges });
          });
        });
    });
  });
});

app.get('/api/homeworks/:id/result', auth, (req, res) => {
  const userId = req.user.id;
  const hwId = req.params.id;
  db.get('SELECT * FROM homework_submissions WHERE homework_id = ? AND user_id = ?', [hwId, userId], (err, sub) => {
    if (err || !sub) return res.status(404).json({ error: '未找到提交记录' });
    db.all('SELECT * FROM homework_questions WHERE homework_id = ? ORDER BY question_order', [hwId], (err2, questions) => {
      res.json({
        submission: { ...sub, answers: JSON.parse(sub.answers) },
        questions: questions.map(q => ({ ...q, data: JSON.parse(q.data) }))
      });
    });
  });
});

// ── Error Book ────────────────────────────────────────────
app.get('/api/error-book', auth, (req, res) => {
  const userId = req.user.id;
  db.all('SELECT * FROM error_books WHERE user_id = ? AND status = "active" ORDER BY last_wrong_at DESC', [userId], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows.map(r => ({ ...r, data: JSON.parse(r.question_data) })));
  });
});

app.get('/api/error-book/stats', auth, (req, res) => {
  const userId = req.user.id;
  db.get('SELECT COUNT(*) as total FROM error_books WHERE user_id = ?', [userId], (err, total) => {
    db.get('SELECT COUNT(*) as mastered FROM error_books WHERE user_id = ? AND status = "mastered"', [userId], (err2, mastered) => {
      db.get('SELECT COUNT(*) as active FROM error_books WHERE user_id = ? AND status = "active"', [userId], (err3, active) => {
        res.json({
          total: total?.total || 0,
          mastered: mastered?.mastered || 0,
          active: active?.active || 0
        });
      });
    });
  });
});

app.post('/api/error-book/:id/master', auth, (req, res) => {
  const userId = req.user.id;
  const errorId = req.params.id;
  db.run('UPDATE error_books SET status = "mastered" WHERE id = ? AND user_id = ?', [errorId, userId], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

// ── Badges / Achievements ─────────────────────────────────
app.get('/api/badges', auth, (req, res) => {
  const userId = req.user.id;
  db.all('SELECT * FROM badges WHERE user_id = ? ORDER BY earned_at DESC', [userId], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/badges/all', auth, (req, res) => {
  const userId = req.user.id;
  const allBadgeTypes = [
    { type: 'first_step', title: '迈出第一步', icon: '🚶', description: '完成了第一个单元', condition: '完成1个单元' },
    { type: 'explorer', title: '小小探险家', icon: '🔍', description: '完成了3个单元', condition: '完成3个单元' },
    { type: 'champion', title: '学习冠军', icon: '🏆', description: '完成了5个单元', condition: '完成5个单元' },
    { type: 'homework_first', title: '作业达人', icon: '✏️', description: '完成了第一份作业', condition: '完成1份作业' },
    { type: 'xp_1000', title: '千分达人', icon: '💎', description: '累计获得1000 XP', condition: '获得1000 XP' },
    { type: 'perfect_score', title: '满分王者', icon: '⭐', description: '作业获得满分', condition: '作业100分' },
    { type: 'error_master', title: '错题征服者', icon: '✅', description: '掌握10道错题', condition: '掌握10道错题' },
  ];
  
  db.all('SELECT type FROM badges WHERE user_id = ?', [userId], (err, earned) => {
    if (err) return res.status(500).json({ error: err.message });
    const earnedSet = new Set(earned.map(e => e.type));
    res.json(allBadgeTypes.map(b => ({ ...b, earned: earnedSet.has(b.type) })));
  });
});

// ── Seed Data ───────────────────────────────────────────────
function seedData() {
  db.get('SELECT COUNT(*) as count FROM courses', (err, row) => {
    if (err) {
      console.error('DB error:', err)
      return
    }
    if (row && row.count > 0) {
      console.log('✅ Data already exists, skipping seed.')
      return
    }

    console.log('🌱 Seeding data...')

    const courses = [
      { name: '字母探险', level: 1, order: 1, desc: 'Phonics 启蒙，从 A-Z 开始', icon: '🔤', color: '#EF4444', xp: 0 },
      { name: '短词王国', level: 2, order: 2, desc: 'CVC 词汇，简单发音规则', icon: '🏰', color: '#F59E0B', xp: 500 },
      { name: '句子城堡', level: 3, order: 3, desc: '简单句型与日常对话', icon: '🏛️', color: '#10B981', xp: 1500 },
      { name: '故事森林', level: 4, order: 4, desc: '分级阅读初阶', icon: '🌲', color: '#3B82F6', xp: 3000 },
      { name: '章节海洋', level: 5, order: 5, desc: '初章书阅读与理解', icon: '🌊', color: '#8B5CF6', xp: 5000 },
      { name: '自由天空', level: 6, order: 6, desc: '自主阅读与深度思考', icon: '☁️', color: '#EC4899', xp: 8000 }
    ]

    courses.forEach(c => {
      db.run('INSERT OR IGNORE INTO courses (name, level, course_order, description, icon, color, xp_required) VALUES (?,?,?,?,?,?,?)',
        [c.name, c.level, c.order, c.desc, c.icon, c.color, c.xp])
    })

    const units1 = [
      { name: 'A-M 字母家族', order: 1, intro: 'https://example.com/video/alphabet-am.mp4', explain: 'https://example.com/video/explain-am.mp4', content: '学习 A 到 M 的字母名称和发音' },
      { name: 'N-Z 字母家族', order: 2, intro: 'https://example.com/video/alphabet-nz.mp4', explain: 'https://example.com/video/explain-nz.mp4', content: '学习 N 到 Z 的字母名称和发音' },
      { name: '字母大冒险', order: 3, intro: 'https://example.com/video/alphabet-adventure.mp4', explain: 'https://example.com/video/explain-adventure.mp4', content: '综合复习所有字母' }
    ]

    units1.forEach((u) => {
      db.run('INSERT OR IGNORE INTO units (course_id, name, unit_order, intro_video, explain_video, content) VALUES (?,?,?,?,?,?)',
        [1, u.name, u.order, u.intro, u.explain, u.content])
    })

    const units2 = [
      { name: 'Cat 家族: -at', order: 1, intro: 'https://example.com/video/cvc-at.mp4', explain: 'https://example.com/video/explain-cvc-at.mp4', content: 'cat, bat, hat, rat, sat' },
      { name: 'Dog 家族: -og', order: 2, intro: 'https://example.com/video/cvc-og.mp4', explain: 'https://example.com/video/explain-cvc-og.mp4', content: 'dog, log, fog, hog, jog' },
      { name: 'Sun 家族: -un', order: 3, intro: 'https://example.com/video/cvc-un.mp4', explain: 'https://example.com/video/explain-cvc-un.mp4', content: 'sun, bun, run, fun, nun' },
      { name: 'CVC 混合挑战', order: 4, intro: 'https://example.com/video/cvc-mix.mp4', explain: 'https://example.com/video/explain-cvc-mix.mp4', content: '综合 CVC 词汇练习' }
    ]

    units2.forEach((u) => {
      db.run('INSERT OR IGNORE INTO units (course_id, name, unit_order, intro_video, explain_video, content) VALUES (?,?,?,?,?,?)',
        [2, u.name, u.order, u.intro, u.explain, u.content])
    })

    const games11 = [
      { type: 'listen_choose', title: '听音选字母', order: 1, data: { audio: 'a.mp3', options: ['A', 'B', 'C', 'D'], correct: 'A' }, points: 10 },
      { type: 'word_match', title: '字母配对', order: 2, data: { pairs: [['A', 'Apple'], ['B', 'Ball'], ['C', 'Cat'], ['D', 'Dog']] }, points: 15 },
      { type: 'letter_spell', title: '拼写大挑战', order: 3, data: { words: ['APPLE', 'BALL', 'CAT', 'DOG', 'EGG'], hints: ['A_P_E', 'B_L_', 'C_T', 'D_G', '_GG'] }, points: 20 },
      { type: 'picture_sort', title: '字母顺序排排乐', order: 4, data: { items: ['A', 'C', 'B', 'E', 'D'], correct: ['A', 'B', 'C', 'D', 'E'] }, points: 15 }
    ]

    games11.forEach((g) => {
      db.run('INSERT OR IGNORE INTO games (unit_id, type, title, data, points, game_order) VALUES (?,?,?,?,?,?)',
        [1, g.type, g.title, JSON.stringify(g.data), g.points, g.order])
    })

    const games21 = [
      { type: 'listen_choose', title: '听音选单词', order: 1, data: { audio: 'cat.mp3', options: ['cat', 'dog', 'bat', 'rat'], correct: 'cat' }, points: 10 },
      { type: 'word_match', title: '图文配对', order: 2, data: { pairs: [['cat', '猫'], ['bat', '蝙蝠'], ['hat', '帽子'], ['rat', '老鼠']] }, points: 15 },
      { type: 'letter_spell', title: '填空拼词', order: 3, data: { words: ['CAT', 'BAT', 'HAT', 'RAT', 'SAT'], hints: ['C_T', 'B_T', 'H_T', 'R_T', 'S_T'] }, points: 20 },
      { type: 'true_false', title: '判断对错', order: 4, data: { questions: [{ q: 'cat 和 hat 有相同的结尾', a: true }, { q: 'bat 是水果', a: false }] }, points: 15 },
      { type: 'word_puzzle', title: '单词拼图', order: 5, data: { words: ['CAT', 'HAT', 'RAT', 'BAT', 'SAT'] }, points: 20 }
    ]

    games21.forEach((g) => {
      db.run('INSERT OR IGNORE INTO games (unit_id, type, title, data, points, game_order) VALUES (?,?,?,?,?,?)',
        [4, g.type, g.title, JSON.stringify(g.data), g.points, g.order])
    })

    // Create default teacher and demo student accounts
    bcrypt.hash('teacher123', 10).then(hash => {
      db.run('INSERT OR IGNORE INTO users (email, password, name, role) VALUES (?,?,?,?)',
        ['teacher@quyingwen.top', hash, '曲老师', 'teacher'])
    })
    bcrypt.hash('demo123', 10).then(hash => {
      db.run('INSERT OR IGNORE INTO users (email, password, name, role) VALUES (?,?,?,?)',
        ['student@demo.com', hash, '小明同学', 'student'])
    })

    // Create a sample book for unit 1
    db.run('INSERT OR IGNORE INTO books (id, title, description, unit_id, created_by) VALUES (?,?,?,?,?)',
      [1, '字母探险绘本', 'A-M 字母家族有声绘本，配合音频学习字母发音', 1, 1])

    // Create a sample homework for unit 1
    db.run('INSERT OR IGNORE INTO homeworks (id, title, description, unit_id, status, created_by) VALUES (?,?,?,?,?,?)',
      [1, '字母测验：A-M', '测试学生对 A-M 字母的掌握情况', 1, 'published', 1])
    
    const sampleQuestions = [
      { type: 'multiple_choice', data: { question: '字母 "A" 的英文名称是？', options: ['A', 'B', 'C', 'D'] }, answer: 'A', explanation: 'A 的名称就是 "A"，发音 /eɪ/。', points: 10, order: 1 },
      { type: 'multiple_choice', data: { question: '字母 "C" 在单词 "Cat" 中发什么音？', options: ['/k/', '/s/', '/tʃ/', '/ʃ/'] }, answer: '/k/', explanation: 'C 在 a, o, u 前通常发 /k/。', points: 10, order: 2 },
      { type: 'fill_blank', data: { question: 'B __ ll （球）', hint: 'A-M 之间' }, answer: 'A', explanation: 'Ball 是球，B 后面是 A。', points: 15, order: 3 },
      { type: 'true_false', data: { question: '字母 "E" 的名称是 /iː/。' }, answer: 'true', explanation: 'E 的名称就是 /iː/，正确。', points: 10, order: 4 },
    ]

    sampleQuestions.forEach(q => {
      db.run('INSERT OR IGNORE INTO homework_questions (homework_id, type, data, answer, explanation, points, question_order) VALUES (?,?,?,?,?,?,?)',
        [1, q.type, JSON.stringify(q.data), q.answer, q.explanation, q.points, q.order])
    })

    console.log('✅ Seed complete!')
  })
}

// ── Start Server ────────────────────────────────────────────
if (process.argv.includes('--seed')) {
  seedData();
  setTimeout(() => process.exit(0), 1000);
} else {
  seedData();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
}
